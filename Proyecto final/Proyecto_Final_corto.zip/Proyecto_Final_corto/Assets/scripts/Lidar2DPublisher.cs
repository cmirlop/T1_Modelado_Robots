﻿using System;
using System.Collections.Generic;
using Unity.Collections;
using Unity.Jobs;
using UnityEngine;

using Unity.Robotics.ROSTCPConnector;
using RosMessageTypes.Sensor;
using RosMessageTypes.Std;

[DisallowMultipleComponent]
[RequireComponent(typeof(Transform))]
public class Lidar2DPublisher : MonoBehaviour
{
    [Header("Scan geometry (2D planar)")]
    public int pointsPerRevolution = 720;
    public float maxRange = 30f;
    public float minRange = 0.05f;

    [Header("Timing")]
    public float scansPerSecond = 10f;

    [Header("Noise & layers")]
    public float rangeNoiseStd = 0.0f;
    public LayerMask hittableLayers = ~0;

    [Header("ROS")]
    public string topic = "/lidar";
    public string frameId = "lidar_link";

    [Header("Viz (Scene & Game)")]
    public bool drawGizmos = true;          // Scene view
    public bool drawInGame = true;          // Game view (Play/Build)
    [Tooltip("Tamaño de cada punto (m)")]
    public float pointSize = 0.05f;
    [Tooltip("Material para dibujar los puntos en GameView")]
    public Material pointMaterial;
    [Tooltip("Malla a instanciar (si se deja vacío, se usa esfera por defecto)")]
    public Mesh pointMesh;                   // opcional (esfera/cubo/lo que quieras)

    ROSConnection _ros;

    NativeArray<RaycastCommand> _commands;
    NativeArray<RaycastHit> _results;
    float[] _ranges;
    System.Random _rng;
    float _scanTimer;

    // buffers de visualización
    readonly List<Matrix4x4> _matrices = new List<Matrix4x4>(1023);
    readonly List<Vector3> _hitPoints = new List<Vector3>(2048); // para gizmos

    // cache interno
    static readonly int _batchLimit = 1023; // límite por DrawMeshInstanced

    void OnEnable()
    {
        if (pointsPerRevolution < 3) pointsPerRevolution = 3;

        _ros = ROSConnection.instance;
        _ros.RegisterPublisher<LaserScanMsg>(topic);

        _commands = new NativeArray<RaycastCommand>(pointsPerRevolution, Allocator.Persistent);
        _results = new NativeArray<RaycastHit>(pointsPerRevolution, Allocator.Persistent);
        _ranges = new float[pointsPerRevolution];

        _rng = new System.Random(1234);

        EnsurePointMeshAndMaterial();
    }

    void OnDisable()
    {
        if (_commands.IsCreated) _commands.Dispose();
        if (_results.IsCreated) _results.Dispose();
    }

    void Update()
    {
        _scanTimer += Time.deltaTime;
        float period = 1f / Mathf.Max(1e-3f, scansPerSecond);

        while (_scanTimer >= period)
        {
            DoScanAndPublish(period);
            _scanTimer -= period;
        }

        if (drawInGame)
            DrawInstancedPoints(); // dibuja en GameView
    }

    void DoScanAndPublish(float scanPeriod)
    {
        float angleMin = -Mathf.PI;
        float angleMax = Mathf.PI;
        float angleInc = (angleMax - angleMin) / pointsPerRevolution;

        Vector3 origin = transform.position;
        Quaternion rot = transform.rotation;

        for (int i = 0; i < pointsPerRevolution; i++)
        {
            float a = angleMin + i * angleInc;
            Vector3 dirLocal = new Vector3(Mathf.Cos(a), 0f, Mathf.Sin(a)); // plano XZ
            Vector3 dirWorld = rot * dirLocal;

            _commands[i] = new RaycastCommand(origin, dirWorld, maxRange, hittableLayers, 1);
        }

        var handle = RaycastCommand.ScheduleBatch(_commands, _results, 64);
        handle.Complete();

        _hitPoints.Clear();
        _matrices.Clear();

        for (int i = 0; i < pointsPerRevolution; i++)
        {
            float d;
            if (_results[i].collider != null)
            {
                d = _results[i].distance;
                if (rangeNoiseStd > 0f)
                    d = Mathf.Clamp(d + Gaussian(0f, rangeNoiseStd), 0f, maxRange);

                // punto de impacto (world)
                Vector3 p = _results[i].point;

                // Guarda para gizmos
                _hitPoints.Add(p);

                // Prepara matriz para instancing (GameView)
                if (drawInGame)
                {
                    var trs = Matrix4x4.TRS(p, Quaternion.identity, Vector3.one * pointSize);
                    _matrices.Add(trs);
                }
            }
            else
            {
                d = float.PositiveInfinity; // sin retorno
            }

            if (d < minRange) d = minRange;
            _ranges[i] = d;
        }

        // No ponemos 'stamp' para evitar dependencia de TimeMsg; quedará en 0.
        var header = new HeaderMsg
        {
            frame_id = frameId
        };

        float scanTime = scanPeriod;
        float timeIncrement = scanTime / pointsPerRevolution;

        var msg = new LaserScanMsg
        {
            header = header,
            angle_min = angleMin,
            angle_max = angleMax,
            angle_increment = angleInc,
            time_increment = timeIncrement,
            scan_time = scanTime,
            range_min = minRange,
            range_max = maxRange,
            ranges = _ranges,
            intensities = Array.Empty<float>()
        };

        _ros.Publish(topic, msg);
    }

    void DrawInstancedPoints()
    {
        if (_matrices.Count == 0 || pointMesh == null || pointMaterial == null)
            return;

        // Dibuja por lotes (hasta 1023 por llamada)
        int count = _matrices.Count;
        int offset = 0;
        while (offset < count)
        {
            int batch = Mathf.Min(_batchLimit, count - offset);
            // Graphics.DrawMeshInstanced dibuja en el mundo (no requiere GameObjects por punto)
            Graphics.DrawMeshInstanced(pointMesh, 0, pointMaterial, _matrices.GetRange(offset, batch));
            offset += batch;
        }
    }

    void EnsurePointMeshAndMaterial()
    {
        // Material por defecto si no se asigna
        if (pointMaterial == null)
        {
            // Unlit blanco simple: usa un material por defecto (puedes cambiarlo en el Inspector)
            Shader unlit = Shader.Find("Unlit/Color");
            pointMaterial = new Material(unlit);
            pointMaterial.color = Color.cyan;
        }

        // Malla por defecto: esfera pequeña
        if (pointMesh == null)
        {
            // Crea una esfera temporal para extraer su mesh
            var temp = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            pointMesh = temp.GetComponent<MeshFilter>().sharedMesh;
#if UNITY_EDITOR
            DestroyImmediate(temp);
#else
            Destroy(temp);
#endif
        }
    }

    float Gaussian(float mean, float stdDev)
    {
        double u1 = 1.0 - _rng.NextDouble();
        double u2 = 1.0 - _rng.NextDouble();
        double z = Math.Sqrt(-2.0 * Math.Log(u1)) * Math.Sin(2.0 * Math.PI * u2);
        return (float)(mean + stdDev * z);
    }

    // --- Gizmos (solo Scene view) ---
    void OnDrawGizmosSelected()
    {
        if (!drawGizmos) return;
        if (_hitPoints == null || _hitPoints.Count == 0) return;

        Gizmos.color = Color.cyan;
        float r = Mathf.Max(0.005f, pointSize * 0.75f);
        foreach (var p in _hitPoints)
            Gizmos.DrawSphere(p, r);
    }
}
