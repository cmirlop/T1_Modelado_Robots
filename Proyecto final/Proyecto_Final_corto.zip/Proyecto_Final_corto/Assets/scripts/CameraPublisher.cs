using UnityEngine;
using Unity.Robotics.ROSTCPConnector;
using RosMessageTypes.Sensor;
using RosMessageTypes.Std;

public class CameraPublisher : MonoBehaviour
{
    [Tooltip("Topic to publish compressed images on")]
    public string topicName = "/unity_camera/compressed";
    [Tooltip("Camera to capture from (if empty, will use Camera on same GameObject)")]
    public Camera unityCamera;

    private ROSConnection ros;
    private RenderTexture renderTexture;
    private Texture2D texture2D;

    void Start()
    {
        if (unityCamera == null)
        {
            unityCamera = GetComponent<Camera>();
            if (unityCamera == null)
            {
                Debug.LogError("CameraPublisher: No Camera assigned or attached to this GameObject.");
                enabled = false;
                return;
            }
        }

        ros = ROSConnection.GetOrCreateInstance();
        ros.RegisterPublisher<CompressedImageMsg>(topicName);

        renderTexture = new RenderTexture(unityCamera.pixelWidth, unityCamera.pixelHeight, 24);
        texture2D = new Texture2D(renderTexture.width, renderTexture.height, TextureFormat.RGB24, false);
    }

    void OnDestroy()
    {
        if (renderTexture != null) renderTexture.Release();
    }

    // LateUpdate so camera has rendered
    void LateUpdate()
    {
        // render to texture
        RenderTexture currentRT = RenderTexture.active;
        unityCamera.targetTexture = renderTexture;
        unityCamera.Render();

        RenderTexture.active = renderTexture;
        texture2D.ReadPixels(new Rect(0, 0, renderTexture.width, renderTexture.height), 0, 0);
        texture2D.Apply();

        unityCamera.targetTexture = null;
        RenderTexture.active = currentRT;

        // compress and publish as sensor_msgs/CompressedImage
        byte[] jpg = texture2D.EncodeToJPG(75); // quality 0-100

        var msg = new CompressedImageMsg
        {
            header = new HeaderMsg(),  // fill header if you need frame/time
            format = "jpeg",
            data = jpg
        };

        ros.Publish(topicName, msg);
    }
}
