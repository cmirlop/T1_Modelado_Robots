﻿using UnityEngine;
using Unity.Robotics.ROSTCPConnector;
using RosMessageTypes.Geometry;

public class TwistListener1 : MonoBehaviour
{
    ROSConnection ros;
    public string topicName = "/cmd_vel";
    private float linearX = 0f;
    private float angularZ = 0f;
    Rigidbody rb;

    void Start()
    {
        ros = ROSConnection.GetOrCreateInstance();
        ros.Subscribe<TwistMsg>(topicName, ReceiveTwist);

        //Debug.Log($"[TwistListener] Subscribed to {topicName}");
        rb = GetComponent<Rigidbody>();
    }

    void ReceiveTwist(TwistMsg msg)
    {
        // Solo tomamos los ejes relevantes
        linearX = (float)msg.linear.x;   // adelante/atrás
        angularZ = (float)msg.angular.z; // giro sobre eje vertical

        Debug.Log($"[TwistListener] Received Twist → linear.x={linearX:F2}, angular.z={angularZ:F2}");
    }

    void FixedUpdate()
    {
        // Movimiento usando física
        rb.MovePosition(rb.position + transform.right * linearX * Time.fixedDeltaTime);

        // Rotación usando física
        Quaternion deltaRot = Quaternion.Euler(0f, angularZ * Mathf.Rad2Deg * Time.fixedDeltaTime, 0f);
        rb.MoveRotation(rb.rotation * deltaRot);
    }
}
