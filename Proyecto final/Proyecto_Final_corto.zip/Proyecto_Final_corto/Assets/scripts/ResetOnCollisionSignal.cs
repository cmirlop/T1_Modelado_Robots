using UnityEngine;
using Unity.Robotics.ROSTCPConnector;
using RosMessageTypes.Std; // StringMsg

public class ResetOnCollisionSignal : MonoBehaviour
{
    [Header("ROS")]
    [SerializeField] string topicName = "/aviso_colision";

    [Header("Reset")]
    [Tooltip("Si se asigna, el reset usa esta transform como spawn; si no, usa la pose inicial del objeto.")]
    public Transform spawnPoint;

    [Tooltip("Poner a cero velocidades del Rigidbody al resetear.")]
    public bool zeroRigidBody = true;

    Vector3 _initPos;
    Quaternion _initRot;
    Rigidbody _rb;
    ROSConnection _ros;

    void Awake()
    {
        // Guardar pose inicial
        _initPos = transform.position;
        _initRot = transform.rotation;

        _rb = GetComponent<Rigidbody>();
        _ros = ROSConnection.GetOrCreateInstance();

        // Suscribirse al topic std_msgs/String
        _ros.Subscribe<StringMsg>(topicName, OnCollisionSignal);
        Debug.Log($"[ResetOnCollisionSignal] Subscrito a {topicName}");
    }

    void OnDestroy()
    {
        if (_ros != null)
        {
            _ros.Unsubscribe(topicName);
        }
    }

    void OnCollisionSignal(StringMsg msg)
    {
        if (msg == null || string.IsNullOrEmpty(msg.data)) return;

        // Comparaci�n case-insensitive y tolerante a espacios
        var txt = msg.data.Trim().ToLowerInvariant();

        if (txt == "colision" || txt == "collision")
        {
            DoReset();
        }
    }

    public void DoReset()
    {
        // Elegir destino
        Vector3 pos = spawnPoint ? spawnPoint.position : _initPos;
        Quaternion rot = spawnPoint ? spawnPoint.rotation : _initRot;

        // Teletransporte
        if (_rb && zeroRigidBody)
        {
            // Evitar artefactos de f�sica
            _rb.velocity = Vector3.zero;
            _rb.angularVelocity = Vector3.zero;
            _rb.position = pos;
            _rb.rotation = rot;
            _rb.MovePosition(pos);  // por si hay contactos
            _rb.MoveRotation(rot);
        }
        else
        {
            transform.SetPositionAndRotation(pos, rot);
        }

        Debug.Log("[ResetOnCollisionSignal] Reset ejecutado.");
    }
}
