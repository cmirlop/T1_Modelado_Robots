﻿using UnityEngine;
using Unity.Robotics.ROSTCPConnector;
using RosMessageTypes.Geometry;   // Para PointMsg

public class PublicarPosicionRobot : MonoBehaviour
{
    [Header("Objeto cuya posición quieres publicar")]
    public Transform target;  // El objeto del que quieres la posición relativa

    [Header("Configuración ROS")]
    public string topicName = "/posiconrobot";
    public float publishRate = 0.05f; // Segundos entre publicaciones (0.05 ≈ 20 Hz)

    private ROSConnection ros;
    private float timeElapsed = 0f;

    void Start()
    {
        // Obtener o crear la instancia de ROSConnection
        ros = ROSConnection.GetOrCreateInstance();

        // Registrar el publisher del tipo PointMsg en el topic /posiconrobot
        ros.RegisterPublisher<PointMsg>(topicName);
    }

    void Update()
    {
        if (target == null)
            return;

        timeElapsed += Time.deltaTime;

        if (timeElapsed >= publishRate)
        {
            timeElapsed = 0f;

            // Posición del target en el sistema de coordenadas del GameObject donde está este script
            Vector3 localPos = transform.InverseTransformPoint(target.position);

            // Crear el mensaje ROS
            PointMsg msg = new PointMsg(
                localPos.x,
                localPos.y,
                localPos.z
            );

            // Publicar
            ros.Publish(topicName, msg);
        }
    }
}
