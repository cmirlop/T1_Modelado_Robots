﻿using UnityEngine;
using Unity.Robotics.ROSTCPConnector;
using RosMessageTypes.Geometry;

public class TwistListener : MonoBehaviour
{
    ROSConnection ros;
    public string topicName = "/cmd_vel";
    private float linearX = 0f;
    private float angularZ = 0f;

    void Start()
    {
        ros = ROSConnection.GetOrCreateInstance();
        ros.Subscribe<TwistMsg>(topicName, ReceiveTwist);

        Debug.Log($"[TwistListener] Subscribed to {topicName}");
    }

    void ReceiveTwist(TwistMsg msg)
    {
        // Solo tomamos los ejes relevantes
        linearX = (float)msg.linear.x;   // adelante/atrás
        angularZ = (float)msg.angular.z; // giro sobre eje vertical

        Debug.Log($"[TwistListener] Received Twist → linear.x={linearX:F2}, angular.z={angularZ:F2}");
    }

    void Update()
    {
        // Avance en el eje Z de Unity
        transform.Translate(Vector3.right * linearX * Time.deltaTime);

        // Rotación en el eje Y de Unity (arriba)
        transform.Rotate(Vector3.up, angularZ * Mathf.Rad2Deg * Time.deltaTime);

        Debug.Log($"[TwistListener] Updated Pose → Position: {transform.position}, Rotation: {transform.rotation.eulerAngles}");
    }
}
