#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
import numpy as np
import time

import reinforce_learning as rl  # importa tu fichero original

class RLRedTargetExecutor(rl.RLRedTargetAgent):
    def __init__(self, modelo_path, agent_id="0"):
        # Configuramos el sufijo de tópicos en el módulo original
        rl.num_ag = agent_id

        # Inicializamos el agente normal
        super(RLRedTargetExecutor, self).__init__()

        # Forzamos política puramente greed (sin exploración)
        self.epsilon = 0.0

        # Cargamos la Q-table desde fichero
        self.cargar_modelo(modelo_path)
        print("He cargado la Q con", len(self.Q), "estados")

        # Durante la ejecución:
        s, _, _, _ = self.obtener_estado()
        print("Estado:", s)
        print("Q[s]:", self.Q[s])


    def entrenar(self):
        """
        Desactivamos el método entrenar de la clase base por seguridad.
        """
        raise RuntimeError("Este nodo es solo para ejecutar el modelo ya entrenado.")

    def ejecutar(self):
        rate = rospy.Rate(rl.HZ_CONTROL)
        rospy.sleep(rl.ESPERA_INICIO)
        rospy.loginfo("Ejecutando modelo Q (sin aprendizaje)…")

        paso = 0
        while not rospy.is_shutdown():
            paso += 1

            # Observamos el estado actual
            s, mins, (found, bearing, area), front_now = self.obtener_estado()
            if s is None:
                self.stop()
                rate.sleep()
                continue

            # Acción greedy según la Q-table cargada
            s, _, _, _ = self.obtener_estado()
            qvals = self.Q[s]
            a = self.elegir_accion(s)
            
            print(f"Paso {paso}: estado={s}, Q={qvals}, accion={a}")

            self.publicar_accion(a)

            rate.sleep()

            # Nueva observación para comprobar éxito o colisión
            s_next, mins_next, (found2, bearing2, area2), front_next = self.obtener_estado()
            collided = self.colision(front_next)
            success = self.exito(found2, bearing2, area2)

            if collided:
                rospy.loginfo("Colisión durante ejecución en paso %d. Parando.", paso)
                self.stop()
                rospy.sleep(1.0)
                break

            if success:
                rospy.loginfo("Objetivo alcanzado por el modelo en paso %d.", paso)
                self.stop()
                rospy.sleep(1.0)
                break


if __name__ == "__main__":
    rospy.init_node("rl_red_target_executor", anonymous=False)

    # Parámetros configurables desde un .launch o línea de comandos
    modelo_path = rospy.get_param("~modelo_path", "qtable_agent_1.pkl")
    agent_id    = rospy.get_param("~agent_id", "0")

    np.random.seed(int(time.time()) % (2**32 - 1))

    executor = RLRedTargetExecutor(modelo_path, agent_id=agent_id)
    try:
        executor.ejecutar()
    except rospy.ROSInterruptException:
        pass
    finally:
        executor.stop()
