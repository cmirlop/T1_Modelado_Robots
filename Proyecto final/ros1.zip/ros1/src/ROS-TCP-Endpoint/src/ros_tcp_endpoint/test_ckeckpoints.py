#!/usr/bin/env python3
import sys
import os
import time

import rospy
import numpy as np
from stable_baselines3 import PPO
import multiprocessing as mp
from reinforce_Keras_4 import RobotMazeEnvPPO


def main(id):
    rospy.init_node("ppo_checkpoint_eval_agent"+id, anonymous=False)

    # Ruta del checkpoint: la pasamos como argumento o usamos una por defecto
    if len(sys.argv) > 1:
        checkpoint_path = sys.argv[1]
    else:
        # CAMBIA esto por el checkpoint que quieras probar
        checkpoint_path = "./checkpoints/ppo_robot_maze_24000_steps.zip"
        #checkpoint_path = "ppo_robot_maze_8envs.zip"

    if not os.path.isfile(checkpoint_path):
        print(f"[ERROR] No se encuentra el checkpoint: {checkpoint_path}")
        sys.exit(1)

    print(f"[INFO] Cargando modelo desde: {checkpoint_path}")
    model = PPO.load(checkpoint_path)

    # Entorno para el agente 8
    # Asegúrate de que en tu simulación existe el robot con sufijo "8"
    env = RobotMazeEnvPPO(agent_id=id)

    obs = env.reset()
    episode_idx = 0
    episode_reward = 0.0

    print("[INFO] Empezando evaluación en el agente 8 (Ctrl+C para parar)")

    try:
        while not rospy.is_shutdown():
            # predict devuelve una acción (int en tu caso) y estado de la RNN (None si no hay)
            action, _ = model.predict(obs, deterministic=True)

            obs, reward, done, info = env.step(action)
            episode_reward += float(reward)

            # Log mínimo por paso
            rospy.loginfo(
                f"[Agente "+id+"] step={info.get('step', -1)} "
                f"reward_step={reward:.3f} "
                f"reward_ep={episode_reward:.3f} "
                f"done_reason={info.get('done_reason', '')}"
            )

            if done:
                rospy.loginfo(
                    f"=== FIN EPISODIO {episode_idx} "
                    f"(reward total = {episode_reward:.3f}, "
                    f"reason={info.get('done_reason', '')}) ==="
                )
                episode_idx += 1
                episode_reward = 0.0
                obs = env.reset()

            # Pequeño sleep para no saturar la terminal (opcional)
            time.sleep(0.01)

    except KeyboardInterrupt:
        print("\n[INFO] Evaluación interrumpida por el usuario.")

    finally:
        # Por si quieres limpiar algo al final
        env._stop()
        print("[INFO] Script de evaluación terminado.")


if __name__ == "__main__":
    
    # Lista de agentes que quieres lanzar en paralelo
    AGENT_IDS = ["4", "5", "6", "7"]

    # Opcional: en algunos casos va mejor spawn que fork
    # mp.set_start_method("spawn")

    procesos = []

    for aid in AGENT_IDS:
        p = mp.Process(target=main, args=(aid,))
        p.start()
        procesos.append(p)

    # Esperar a que terminen (normalmente ROS se quedará corriendo hasta Ctrl+C)
    for p in procesos:
        p.join()
    main()
