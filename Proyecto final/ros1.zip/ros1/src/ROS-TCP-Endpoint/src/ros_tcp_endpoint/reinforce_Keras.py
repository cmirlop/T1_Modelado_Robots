#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Versión del agente RL para el objetivo rojo usando Keras-RL + TensorFlow (DQN)
con soporte multi-agente (4 robots).

- Cada robot es un entorno RLRedTargetEnv con su propio agent_id ("0","1","2","3").
- MultiAgentRLRedTargetEnv agrupa varios RLRedTargetEnv y va alternando
  el robot activo por episodio (round-robin), compartiendo el mismo DQN.
"""

import rospy
import numpy as np
import threading
import time
from collections import deque
import os

import cv2

from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan, CompressedImage
from std_srvs.srv import Empty
from std_msgs.msg import String

# === Keras / TensorFlow / Keras-RL ===
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten
from tensorflow.keras.optimizers import Adam

import gym
from gym import spaces

from rl.agents.dqn import DQNAgent
from rl.memory import SequentialMemory
from rl.policy import EpsGreedyQPolicy,LinearAnnealedPolicy

# ==========================
# Tópicos ROS (prefijo; luego se añade agent_id)
# ==========================
LIDAR_TOPIC = "/lidar"
CAM_TOPIC   = "/camara_robot"   # sensor_msgs/CompressedImage
CMD_TOPIC   = "/cmd_vel"
COLISION_TOPIC = "/aviso_colision"

# ==========================
# LiDAR (discretización)
# ==========================
NUM_SECTORES = 7
BINS_DIST = [6, 10, 30]        # cerca / medio / lejos (m)
CLIP_DIST = 30
COLLISION_DIST = 5

OPEN_PROBE_THRESH = 20.0
GUIDE_PROB = 0.8
ANGLE_WINDOW_DEG = 8.0

# ==========================
# Cámara / visión del objetivo rojo
# ==========================
IMG_RESIZE_W = 320
AREA_MIN = 50
AREA_GOAL = 3000
CENTER_THRESH = 0.12

LOW1  = (0,   90,  80)
HIGH1 = (10,  255, 255)
LOW2  = (170, 90,  80)
HIGH2 = (180, 255, 255)

# ==========================
# Acciones (v,w)
# ==========================
ACCIONES = [
    ("forward",  3.00,  0.0),
    ("left",     0.00, -1.0),
    ("right",    0.00,  1.0),
    ("slow",     1.00,  0.0),
    ("stop",     0.00,  0.0),
]

# ==========================
# Hiperparámetros RL
# ==========================
GAMMA = 0.95

PASOS_MAX_EPISODIO =900
MAX_EPISODIOS = 100             # episodios por agente (aprox.)
ESPERA_INICIO = 1.0
HZ_CONTROL = 10
COOLDOWN_COLISION = 1.0
RESET_SERVICE = "/reset_world"

# IDs de los agentes (4 robots)
AGENT_IDS = ["0", "1", "2", "3","4","5"]

# =====================================
# Funciones auxiliares de LiDAR / visión
# =====================================

def min_range_at_angle(scan_msg, angle_rad, window_deg=8.0, fallback=np.inf):
    ranges = np.asarray(scan_msg.ranges, dtype=np.float32)
    n = ranges.size
    if n == 0:
        return fallback

    angle_min = scan_msg.angle_min
    inc = scan_msg.angle_increment
    rng_max = scan_msg.range_max if np.isfinite(scan_msg.range_max) and scan_msg.range_max > 0 else CLIP_DIST

    idx_center = int(round((angle_rad - angle_min) / inc))
    half_w = max(1, int(round(np.deg2rad(window_deg) / abs(inc))))

    i0 = max(0, idx_center - half_w)
    i1 = min(n, idx_center + half_w + 1)

    seg = ranges[i0:i1]
    seg = seg[np.isfinite(seg)]
    if seg.size == 0:
        return fallback

    val = float(np.clip(np.min(seg), 0.0, rng_max))
    return val


def discretiza_dist(d):
    if d < BINS_DIST[0]:
        return 0
    if d < BINS_DIST[1]:
        return 1
    return 2


def sectoriza(scan_msg, num_sectores):
    ranges = np.array(scan_msg.ranges, dtype=np.float32)
    ranges[~np.isfinite(ranges)] = CLIP_DIST

    angle_min = scan_msg.angle_min
    angle_inc = scan_msg.angle_increment
    n = ranges.shape[0]

    zero_idx = int(round((0.0 - angle_min) / angle_inc))
    zero_idx = np.clip(zero_idx, 0, n - 1)

    rotated = np.roll(ranges, -(zero_idx - n // 2))

    step = max(1, n // num_sectores)
    mins = []
    for i in range(num_sectores):
        seg = rotated[i * step:(i + 1) * step] if (i + 1) * step <= n else rotated[i * step:]
        if seg.size == 0:
            mins.append(CLIP_DIST)
        else:
            mins.append(float(np.clip(np.min(seg), 0.0, CLIP_DIST)))

    return np.array(mins, dtype=np.float32)


def bins_lidar(mins):
    return [discretiza_dist(d) for d in mins]


def discretiza_bearing(bearing_norm):
    if bearing_norm < -0.12:
        return 0  # izquierda
    if bearing_norm > 0.12:
        return 2  # derecha
    return 1      # centrado


def discretiza_area(area):
    if area < 100:
        return 0
    if area < 2000:
        return 1
    return 2


def extrae_objetivo_rojo(cv_bgr):
    """
    Devuelve: found(bool), bearing_norm(-1..1), area(int), bbox(x,y,w,h)
    """
    if cv_bgr is None:
        return False, None, 0, None

    h, w = cv_bgr.shape[:2]
    scale = float(IMG_RESIZE_W) / float(w)
    cv_small = cv2.resize(cv_bgr, (IMG_RESIZE_W, int(h * scale))) if w > IMG_RESIZE_W else cv_bgr
    H, W = cv_small.shape[:2]

    hsv = cv2.cvtColor(cv_small, cv2.COLOR_BGR2HSV)
    mask1 = cv2.inRange(hsv, np.array(LOW1), np.array(HIGH1))
    mask2 = cv2.inRange(hsv, np.array(LOW2), np.array(HIGH2))
    mask = cv2.bitwise_or(mask1, mask2)

    kernel = np.ones((3, 3), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return False, None, 0, None

    c = max(contours, key=cv2.contourArea)
    area = int(cv2.contourArea(c))
    print("area:   ",area)
    if area < AREA_MIN:
        return False, None, area, None

    x, y, wc, hc = cv2.boundingRect(c)
    cx = x + wc / 2.0
    bearing_norm = (cx - (W / 2.0)) / (W / 2.0)

    return True, float(bearing_norm), int(area), (x, y, wc, hc)


def observa_estado(lidar_mins, bearing_norm, area):
    lidar_bins = bins_lidar(lidar_mins)
    bearing_bin = 3  # 3 => “no visto”
    area_bin = 0
    if bearing_norm is not None:
        bearing_bin = discretiza_bearing(bearing_norm)
        area_bin = discretiza_area(area)
    front_blocked = 1 if lidar_mins[len(lidar_mins) // 2] < BINS_DIST[0] else 0
    return tuple(lidar_bins + [bearing_bin, area_bin, front_blocked])


# ==========================
# Entorno Gym + ROS (un solo robot)
# ==========================

class RLRedTargetEnv(gym.Env):
    """
    Entorno Gym que encapsula la lógica ROS del robot persiguiendo el objetivo rojo.
    Un agent_id => un robot (topics sufijados con ese id).
    """

    metadata = {'render.modes': []}

    def __init__(self, agent_id="0"):
        super(RLRedTargetEnv, self).__init__()

        self.agent_id = str(agent_id)
        self.lock = threading.Lock()

        # Publishers / Subscribers
        self.twist_pub = rospy.Publisher(CMD_TOPIC + self.agent_id, Twist, queue_size=1)
        self.col_pub = rospy.Publisher(COLISION_TOPIC + self.agent_id, String, queue_size=1)
        self.lidar_sub = rospy.Subscriber(LIDAR_TOPIC + self.agent_id, LaserScan, self.cb_lidar, queue_size=1)
        self.img_sub = rospy.Subscriber(CAM_TOPIC + self.agent_id, CompressedImage, self.cb_img, queue_size=1)

        rospy.loginfo("Agente %s usando topics: %s, %s, %s, %s",
                      self.agent_id,
                      CMD_TOPIC + self.agent_id,
                      COLISION_TOPIC + self.agent_id,
                      LIDAR_TOPIC + self.agent_id,
                      CAM_TOPIC + self.agent_id)

        # Estado de sensores
        self.last_lidar = None
        self.lidar_ok = False

        self.last_bgr = None
        self.image_ok = False

        # Variables de visión
        self.last_found = False
        self.last_bearing = None
        self.last_area = 0

        # Contadores para shaping de reward
        self.cont_gir = 0
        self.ant_name = None
        self.cont_Rec = 0
        self.cont_giros = 0

        # Historial de visión previa
        self.prev_vision = (False, None, 0)

        # Servicio reset
        self.reset_srv = None
        try:
            rospy.wait_for_service(RESET_SERVICE, timeout=2.0)
            self.reset_srv = rospy.ServiceProxy(RESET_SERVICE, Empty)
            rospy.loginfo("Servicio de reset disponible: %s", RESET_SERVICE)
        except rospy.ROSException:
            rospy.logwarn("No se encontró servicio %s. Seguimos sin reset mundo.", RESET_SERVICE)

        # Espacios Gym
        self.state_dim = NUM_SECTORES + 3
        self.action_space = spaces.Discrete(len(ACCIONES))
        self.observation_space = spaces.Box(
            low=0.0,
            high=3.0,
            shape=(self.state_dim,),
            dtype=np.float32
        )

        self.step_count = 0
        self.episodio = 0

    # ---------- Callbacks ROS ----------

    def cb_lidar(self, msg):
        with self.lock:
            self.last_lidar = msg
            self.lidar_ok = True

    def cb_img(self, msg):
        np_arr = np.frombuffer(msg.data, np.uint8)
        bgr = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        with self.lock:
            self.last_bgr = bgr
            self.image_ok = True

    # ---------- Utilidades internas ----------

    def _publicar_twist(self, v, w):
        t = Twist()
        t.linear.x = v
        t.angular.z = w
        self.twist_pub.publish(t)

    def _stop(self):
        self._publicar_twist(0.0, 0.0)

    def _obtener_estado(self):
        if not self.lidar_ok or self.last_lidar is None:
            return None, None, (False, None, 0), None

        mins = sectoriza(self.last_lidar, NUM_SECTORES)

        found, bearing, area = False, None, 0
        if self.image_ok and self.last_bgr is not None:
            found, bearing, area, _ = extrae_objetivo_rojo(self.last_bgr)

        s_tuple = observa_estado(mins, bearing, area)
        state_vec = np.array(s_tuple, dtype=np.float32)
        front = mins[NUM_SECTORES // 2]

        return state_vec, mins, (found, bearing, area), front

    # ---------- Lógica de colisión, éxito, recompensa ----------
    """
    def colision(self, front_now):
        return front_now is not None and front_now < COLLISION_DIST
    """

    def colision(self, mins_now):
        if mins_now is None:
            return False

        # Solo consideramos los 3 sectores frontales (izq-frontal, frontal, dcha-frontal)
        center = len(mins_now) // 2
        front_zone = mins_now[center-1:center+2]  # para 7 sectores: índices 2,3,4

        # Colisión si alguno de esos sectores está por debajo del umbral
        return np.any(front_zone < COLLISION_DIST)

    def exito(self, found, bearing, area):
        if not found or bearing is None:
            return False
        centered = abs(bearing) < CENTER_THRESH
        big = area >= AREA_GOAL
        return centered and big

    def recompensa(self, a_idx, obs_prev, obs_now, collided, success, front_next):
        r = -0.02  # coste por paso

        if success:
            r += 8.0
            return r

        if collided:
            r -= 2.0
            return r

        name, v, w = ACCIONES[a_idx]

        (found_prev, bearing_prev, area_prev) = obs_prev
        (found_now, bearing_now, area_now) = obs_now

        # Si antes lo veía y ahora no => mala señal
        if found_prev and not found_now:
            r -= 0.5

        if self.ant_name is None:
            self.ant_name = name

        if name in ("left", "right") and self.ant_name == name:
            self.cont_gir += 1
        if name in ("left", "right") and self.ant_name in ("left", "right"):
            self.cont_giros += 1
        if name != self.ant_name:
            self.cont_gir = 0
        if name in ("forward", "slow"):
            self.cont_gir = 0
            self.cont_Rec += 1
            self.cont_giros = 0

        self.ant_name = name

        # Si no lo veo aún, shaping con LiDAR
        if not found_now:
            if name in ("forward", "slow") and self.cont_Rec < 15:
                r += 0.04
            if name in ("forward", "slow") and self.cont_Rec >= 15:
                r += 0.01
            if name in ("left", "right") and self.cont_gir <= 3:
                self.cont_Rec = 0
                r += 0.03
            if name in ("left", "right") and self.cont_gir > 3:
                r -= 0.06
            if name in ("stop"):
                r -= 0.04
            if front_next is not None and front_next < 10.0:
                r -= 0.04
            if name in ("left", "right") and self.cont_giros >= 5:
                r -= 0.06
            if front_next is not None and front_next > 20.0 and name in ("forward", "slow"):
                r += 0.02
            return r

        # Lo veo: premiar acercamiento y centrado
        if bearing_prev is not None and bearing_now is not None:
            delta_b = abs(bearing_prev) - abs(bearing_now)
            r += np.clip(delta_b * 1.2, -0.3, 0.3)

        if area_prev is not None:
            delta_a = (area_now - area_prev) / float(max(area_prev, 1))
            r += np.clip(delta_a * 0.6, -0.4, 0.6)

        if bearing_now is not None and name in ("forward", "slow") and abs(bearing_now) < 0.2:
            r += 0.08 if name == "forward" else 0.04

        return r

    # ---------- Métodos Gym: reset, step, close ----------

    def reset(self):
        self.episodio += 1
        self.step_count = 0

        rospy.loginfo("== Episodio %d (agente %s) ==", self.episodio, self.agent_id)

        self.cont_gir = 0
        self.ant_name = None
        self.cont_Rec = 0
        self.cont_giros = 0
        self.prev_vision = (False, None, 0)

        if self.reset_srv is not None:
            try:
                self.reset_srv()
                rospy.loginfo("Reset del mundo solicitado (agente %s).", self.agent_id)
            except rospy.ServiceException as e:
                rospy.logwarn("Fallo reset mundo: %s", e)

        self._stop()
        rospy.sleep(ESPERA_INICIO)

        rate = rospy.Rate(HZ_CONTROL)
        for _ in range(int(HZ_CONTROL * 2)):
            state, mins, vision, front = self._obtener_estado()
            if state is not None:
                self.prev_vision = vision
                return state
            rate.sleep()

        rospy.logwarn("No se obtuvo observación inicial (agente %s), devolviendo estado cero.", self.agent_id)
        return np.zeros(self.observation_space.shape, dtype=np.float32)

    def step(self, action):
        name, v, w = ACCIONES[int(action)]
        self._publicar_twist(v, w)
        self.step_count += 1

        rospy.sleep(1.0 / HZ_CONTROL)

        state, mins_next, vision_now, front_next = self._obtener_estado()
        if state is None:
            r = -0.1
            done = False
            info = {"no_observation": True, "agent_id": self.agent_id}
            return (np.zeros(self.observation_space.shape, dtype=np.float32), r, done, info)

        found2, bearing2, area2 = vision_now
        collided = self.colision(mins_next)
        #print(self.agent_id,"     ",front_next)
        success = self.exito(found2, bearing2, area2)

        r = self.recompensa(action, self.prev_vision, vision_now, collided, success, front_next)

        done = False
        if collided:
            rospy.loginfo("Colisión en paso %d (agente %s).", self.step_count, self.agent_id)
            self._stop()
            rospy.sleep(COOLDOWN_COLISION)
            done = True
        elif success:
            rospy.loginfo("¡Objetivo rojo alcanzado! Paso %d (agente %s).", self.step_count, self.agent_id)
            self._stop()
            rospy.sleep(0.7)
            done = True
        elif self.step_count >= PASOS_MAX_EPISODIO:
            rospy.loginfo("Paso máximo %d alcanzado (agente %s).", PASOS_MAX_EPISODIO, self.agent_id)
            self._stop()
            done = True

        if done:
            self.col_pub.publish(String(data="colision"))

        self.prev_vision = vision_now

        info = {
            "collided": collided,
            "success": success,
            "front_dist": front_next,
            "step": self.step_count,
            "agent_id": self.agent_id,
        }

        return state, r, done, info

    def close(self):
        self._stop()
        rospy.loginfo("Cerrando entorno RLRedTargetEnv (agente %s).", self.agent_id)


# ==========================
# Entorno multi-agente (4 robots compartiendo DQN)
# ==========================

class MultiAgentRLRedTargetEnv(gym.Env):
    """
    Env Gym que agrupa varios RLRedTargetEnv (uno por robot).
    Cada reset() pasa al siguiente robot en round-robin, de forma que
    el DQN ve episodios de todos los agentes, pero con una única política compartida.
    """

    metadata = {'render.modes': []}

    def __init__(self, agent_ids):
        super(MultiAgentRLRedTargetEnv, self).__init__()

        self.envs = [RLRedTargetEnv(agent_id=aid) for aid in agent_ids]
        self.n_envs = len(self.envs)
        self.current_idx = -1   # se incrementa en reset()

        # Asumimos que todos tienen mismos espacios
        self.action_space = self.envs[0].action_space
        self.observation_space = self.envs[0].observation_space

    def reset(self):
        # Cambiamos de robot en cada nuevo episodio
        self.current_idx = (self.current_idx + 1) % self.n_envs
        rospy.loginfo("=== Reset Multi-Agent: usando robot con agent_id=%s ===",
                      self.envs[self.current_idx].agent_id)
        return self.envs[self.current_idx].reset()

    def step(self, action):
        # Delegar en el env del robot activo
        return self.envs[self.current_idx].step(action)

    def close(self):
        for e in self.envs:
            e.close()
        rospy.loginfo("Cerrando MultiAgentRLRedTargetEnv con %d robots.", self.n_envs)


# ==========================
# Construcción del modelo DQN
# ==========================

def build_model(state_shape, nb_actions):
    model = Sequential()
    model.add(Flatten(input_shape=(1,) + state_shape))
    model.add(Dense(128, activation="relu"))
    model.add(Dense(64, activation="relu"))
    model.add(Dense(nb_actions, activation="linear"))
    return model


# ==========================
# Main
# ==========================

if __name__ == "__main__":
    rospy.init_node("rl_red_target_dqn_multi_agent", anonymous=False)

    # Semillas
    np.random.seed(int(time.time()) % (2 ** 32 - 1))
    tf.random.set_seed(int(time.time()) % (2 ** 32 - 1))

    # Creamos un entorno RLRedTargetEnv por cada robot
    envs = [RLRedTargetEnv(agent_id=aid) for aid in AGENT_IDS]
    n_envs = len(envs)

    # Todos comparten mismo espacio de acciones / observaciones
    nb_actions = envs[0].action_space.n
    state_shape = envs[0].observation_space.shape

    # ==== UN MODELO / UN AGENTE POR ROBOT ====
    agents = []
    for i, env in enumerate(envs):
        # Modelo independiente para este robot
        model = build_model(state_shape, nb_actions)

        memory = SequentialMemory(limit=50000, window_length=1)

        policy = LinearAnnealedPolicy(
            EpsGreedyQPolicy(),
            attr='eps',
            value_max=1.0,
            value_min=0.05,
            value_test=0.01,
            nb_steps=200000
        )

        dqn = DQNAgent(
            model=model,
            nb_actions=nb_actions,
            memory=memory,
            nb_steps_warmup=5000,
            target_model_update=1e-2,
            policy=policy,
            gamma=GAMMA,
            train_interval=4,          # nuevo
            batch_size=64
        )

        dqn.compile(Adam(learning_rate=5e-4), metrics=["mae"])

        # Dejamos el agente en modo entrenamiento
        dqn.training = True
        dqn.step = 0
        dqn.reset_states()

        agents.append(dqn)

    # --- Entrenamiento manual multi-robot (cada uno con su DQN) ---

    # Episodios completados por cada robot
    episodios_por_robot = [0] * n_envs

    # Estado actual de cada robot
    estados = []

    # Reset inicial de todos los robots
    for i, env in enumerate(envs):
        s0 = env.reset()
        estados.append(s0)
        rospy.loginfo("Robot %s listo, episodio inicial 0", env.agent_id)

    rospy.loginfo("Comienza entrenamiento multi-robot (modelos independientes): %d robots, %d episodios cada uno",
                  n_envs, MAX_EPISODIOS)

    # Bucle principal: seguimos mientras haya algún robot con episodios < MAX_EPISODIOS
    while (not rospy.is_shutdown()
           and any(ep < MAX_EPISODIOS for ep in episodios_por_robot)):

        # Recorremos TODOS los robots en cada iteración
        for i, env in enumerate(envs):
            # Si este robot ya ha terminado sus episodios, lo saltamos
            if episodios_por_robot[i] >= MAX_EPISODIOS:
                continue

            dqn = agents[i]
            obs = estados[i]

            # Elegimos acción con la política epsilon-greedy de SU DQN
            action = dqn.forward(obs)

            # Paso en el entorno de ESTE robot
            next_obs, reward, done, info = env.step(action)

            # Aprendizaje con esta transición (para su propio agente)
            dqn.backward(reward, terminal=done)

            if done:
                episodios_por_robot[i] += 1
                rospy.loginfo("Robot %s terminó episodio %d",
                              env.agent_id, episodios_por_robot[i])

                if episodios_por_robot[i] < MAX_EPISODIOS:
                    # Nuevo episodio solo para este robot
                    estados[i] = env.reset()
                else:
                    # Ha acabado su cupo de episodios
                    env._stop()
                    estados[i] = np.zeros_like(next_obs, dtype=np.float32)
            else:
                # Continuamos el mismo episodio
                estados[i] = next_obs

    rospy.loginfo("Entrenamiento terminado: todos los robots han completado %d episodios",
                  MAX_EPISODIOS)

    # Guardamos pesos de CADA robot por separado
    for env, dqn in zip(envs, agents):
        weights_path = os.path.join(
            os.getcwd(),
            f"dqn_red_target_agent_{env.agent_id}_weights.h5"
        )
        dqn.save_weights(weights_path, overwrite=True)
        rospy.loginfo("Pesos DQN del robot %s guardados en %s",
                      env.agent_id, weights_path)

    # Cerramos todos los entornos
    for env in envs:
        env.close()
