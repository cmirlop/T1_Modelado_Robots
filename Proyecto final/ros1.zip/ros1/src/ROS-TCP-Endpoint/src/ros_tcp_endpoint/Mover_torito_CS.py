#!/usr/bin/env python3
import rospy
import cv2
import json
import math
import numpy as np
from sensor_msgs.msg import CompressedImage
from cv_bridge import CvBridge
from geometry_msgs.msg import Twist
from std_msgs.msg import String
import BP_algoritmo_mov_HVL as bpa
import time

"""Quitar el if del  control, pero el resto funcionaaa"""

bridge = CvBridge()
cmd_pub = None
prev_dist = None

state = "zone1"
zone1, zone2 = None, None

img_obt_hsv,img_obt_bgr, img_obt_gray= None,None,None
img_save = False


Destinos = None

# ----------------------- Configuración -----------------------
objetivo = None   # coordenadas X,Y del objetivo
size_roi = None          # tamaño del ROI alrededor del robot
angular_speed = 0.3      # velocidad angular (rad/s)
linear_speed_f = 0.5       # velocidad lineal (m/s)
linear_speed_m = 0.3
linear_speed_s = 0.1
dt = 0.1                 # tiempo entre iteraciones

bridge = CvBridge()
twist = Twist()
centro_robot = None
vector_dir = None
roi_global = None

def cargar_zonas(filename="zonas.json"):
    """Cargar las zonas desde un JSON"""
    with open(filename, "r") as f:
        data = json.load(f)
    return tuple(data["zone1"]), tuple(data["zone2"]),tuple(data["robot1"])

def get_centroid(mask):
    M = cv2.moments(mask)
    if M["m00"] > 0:
        cx = int(M["m10"]/M["m00"])
        cy = int(M["m01"]/M["m00"])
        return (cx, cy)
    return None

def buscar_robot(img):
    
    # --- Verde ---
    lower_green = np.array([40, 50, 50])
    upper_green = np.array([80, 255, 255])
    mask_green = cv2.inRange(img, lower_green, upper_green)

    # --- Rojo ---
    lower_red1 = np.array([0, 100, 100])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([160, 100, 100])
    upper_red2 = np.array([179, 255, 255])
    mask_red = cv2.inRange(img, lower_red1, upper_red1) | cv2.inRange(img, lower_red2, upper_red2)

    #Obtener el rojo y el verde
    green_centroid = get_centroid(mask_green)
    red_centroid   = get_centroid(mask_red)

    #Obtener el vector Rojo --> Verde
    dir_vec = (green_centroid[0] - red_centroid[0],
                green_centroid[1] - red_centroid[1])
    

    #Centro del robot
    cent = (int((green_centroid[0]+red_centroid[0])/2),int((green_centroid[1]+red_centroid[1])/2))
    
    return red_centroid,green_centroid,dir_vec,cent

def nothing(x):
    pass

def gris(img):
    image_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.namedWindow("Escala de Grises")
    cv2.createTrackbar("Threshold", "Escala de Grises", 0, 255, nothing)
    while True:
        if image_gray is not None:
            thresh_val = cv2.getTrackbarPos("Threshold", "Escala de Grises")
            _, thresh_img = cv2.threshold(image_gray, 0, thresh_val, cv2.THRESH_BINARY)
            cv2.imshow("Escala de Grises", thresh_img)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

"""
def callback(msg):
    global cmd_pub, prev_dist, state, zone1, zone2
    frame = bridge.compressed_imgmsg_to_cv2(msg, desired_encoding="bgr8")
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # --- Verde ---
    lower_green = np.array([40, 50, 50])
    upper_green = np.array([80, 255, 255])
    mask_green = cv2.inRange(hsv, lower_green, upper_green)

    # --- Rojo ---
    lower_red1 = np.array([0, 100, 100])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([160, 100, 100])
    upper_red2 = np.array([179, 255, 255])
    mask_red = cv2.inRange(hsv, lower_red1, upper_red1) | cv2.inRange(hsv, lower_red2, upper_red2)

    green_centroid = get_centroid(mask_green)
    red_centroid   = get_centroid(mask_red)

    twist = Twist()

    if green_centroid and red_centroid:
        # Dibujar orientación (rojo -> verde)
        cv2.arrowedLine(frame, red_centroid, green_centroid, (255, 0, 0), 3, tipLength=0.3)

        # Selección de target
        if state == "zone1":
            target = zone1
            cv2.circle(frame, target, 6, (255, 0, 0), -1)
        elif state == "zone2":
            target = zone2
            cv2.circle(frame, target, 6, (0, 255, 255), -1)
        else:
            target = None

        if target:
            # Vector orientación (rojo → verde)
            dir_vec = (green_centroid[0] - red_centroid[0],
                       green_centroid[1] - red_centroid[1])
            # Vector hacia objetivo
            goal_vec = (target[0] - red_centroid[0],
                        target[1] - red_centroid[1])

            dot = dir_vec[0]*goal_vec[0] + dir_vec[1]*goal_vec[1]
            norm_dir = math.sqrt(dir_vec[0]**2 + dir_vec[1]**2)
            norm_goal = math.sqrt(goal_vec[0]**2 + goal_vec[1]**2)
            dist = norm_goal

            if norm_dir > 0 and norm_goal > 0:
                cos_angle = dot / (norm_dir * norm_goal)
                cos_angle = max(-1.0, min(1.0, cos_angle))
                angle = math.acos(cos_angle)
                cross = dir_vec[0]*goal_vec[1] - dir_vec[1]*goal_vec[0]

                if abs(angle) < 0.2:  # alineado
                    if prev_dist is not None and dist > prev_dist:
                        twist.linear.x = -0.2
                    else:
                        twist.linear.x = 0.2
                else:
                    twist.angular.z = 0.3 if cross > 0 else -0.3

            prev_dist = dist

            # Llegada
            if dist < 50:
                if state == "zone1":
                    rospy.loginfo("✅ Llegamos a ZONA 1, yendo a ZONA 2")
                    state = "zone2"
                    prev_dist = None
                elif state == "zone2":
                    rospy.loginfo("🏁 Llegamos a ZONA 2, misión completada")
                    state = "done"

    if state == "done":
        twist = Twist()

    cmd_pub.publish(twist)
    cv2.imshow("Torito con zonas", frame)
    cv2.waitKey(1)

"""


"""def extraer_roi(img, centro, objetivo, size):
    
    Extrae un ROI desde el centro del robot hasta el objetivo,
    incluyendo un margen de 15% sobre el tamaño del robot.

    :param img: imagen completa
    :param centro: (x, y) del centro del robot
    :param objetivo: (x, y) del objetivo
    :param size: (anchura, altura) del robot
    :return: ROI recortado, esquina superior izquierda (x1, y1)
    
    x_c, y_c = int(centro[0]), int(centro[1])
    x_o, y_o = int(objetivo[0]), int(objetivo[1])
    w_r, h_r = size

    # Aumentar tamaño en 15%
    w_r = int(w_r * 1.15)
    h_r = int(h_r * 1.15)

    # Determinar límites del ROI
    x1 = min(x_c, x_o) - w_r//2
    y1 = min(y_c, y_o) - h_r//2
    x2 = max(x_c, x_o) + w_r//2
    y2 = max(y_c, y_o) + h_r//2

    # Limitar a tamaño de la imagen
    x1 = max(0, x1)
    y1 = max(0, y1)
    x2 = min(img.shape[1], x2)
    y2 = min(img.shape[0], y2)
    cv2.circle(img, (x_o, y_o), 5, (0, 0, 255), -1)

    roi = img[y1:y2, x1:x2]
    return roi, (x1, y1)"""

def extraer_roi(img, centro, objetivo, size):
    """
    Extrae un ROI desde el centro del robot hasta el objetivo,
    incluyendo un margen de 15% sobre el tamaño del robot.
    Funciona para cualquier orientación (vertical, horizontal o diagonal).

    :param img: imagen completa
    :param centro: (x, y) del centro del robot
    :param objetivo: (x, y) del objetivo
    :param size: (anchura, altura) del robot
    :return: ROI recortado, esquina superior izquierda (x1, y1)
    """
    x_c, y_c = int(centro[0]), int(centro[1])
    x_o, y_o = int(objetivo[0]), int(objetivo[1])
    w_r, h_r = size

    # Aumentar tamaño en 15%
    w_r = int(w_r * 1.15)
    h_r = int(h_r * 1.15)

    # Determinar límites del ROI según dirección del objetivo
    x_min = min(x_c, x_o) - w_r // 2
    x_max = max(x_c, x_o) + w_r // 2
    y_min = min(y_c, y_o) - h_r // 2
    y_max = max(y_c, y_o) + h_r // 2

    # Limitar a tamaño de la imagen
    x_min = max(0, x_min)
    y_min = max(0, y_min)
    x_max = min(img.shape[1], x_max)
    y_max = min(img.shape[0], y_max)

    # Marcar objetivo para depuración
    cv2.circle(img, (x_o, y_o), 5, (0, 0, 255), -1)

    roi = img[y_min:y_max, x_min:x_max]
    return roi, (x_min, y_min)


def callback_ruta(msg):
    global Destinos
    try:
        Destinos = json.loads(msg.data)  # decodificar el JSON
        rospy.loginfo("Recibido: %s", Destinos)
    except json.JSONDecodeError:
        rospy.logwarn("Mensaje no es un JSON válido: %s", msg.data)


def callback(msg):
    global img_obt_hsv,img_obt_bgr,img_obt_gray, img_save
    img_obt_bgr = bridge.compressed_imgmsg_to_cv2(msg, desired_encoding="bgr8")
    #cv2.imwrite("prueba.png", img_obt_bgr)
    img_obt_hsv = cv2.cvtColor(img_obt_bgr, cv2.COLOR_BGR2HSV)
    img_save = True
    print("Imagen conseguida y guardada")

def calcular_vector_flecha(roi):
    """
    Detecta la flecha roja->verde dentro del ROI y devuelve vector unitario
    """
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)

    # máscara roja
    lower_red1 = np.array([0,70,50])
    upper_red1 = np.array([10,255,255])
    lower_red2 = np.array([170,70,50])
    upper_red2 = np.array([180,255,255])
    mask_red = cv2.inRange(hsv, lower_red1, upper_red1) + cv2.inRange(hsv, lower_red2, upper_red2)

    # máscara verde
    lower_green = np.array([40,50,50])
    upper_green = np.array([80,255,255])
    mask_green = cv2.inRange(hsv, lower_green, upper_green)

    # centros
    M_red = get_centroid(mask_red)
    M_green = get_centroid(mask_green)
 
    cx_red = int(M_red[0])
    cy_red = int(M_red[1])
    cx_green = int(M_green[0])
    cy_green = int(M_green[1])

    # vector flecha (unitario)
    vx = cx_green - cx_red
    vy = cy_green - cy_red
    norm = math.hypot(vx, vy)
    if norm == 0:
        return None

    #Centro del robot
    cent = (int((M_green[0]+M_red[0])/2),int((M_green[1]+M_red[1])/2))
    
    return (vx/norm, vy/norm),M_red,M_green,cent


def calcular_dist(robot,objetivo):
    x_r,y_r = robot
    x_o,y_o = objetivo
    dx = x_o -x_r
    dy = y_o-y_r
    dist = math.hypot(dx,dy)
    print("Distancia: ",dist)
    return dist
def calcular_signed_angle(vector, objetivo, centro):
    """
    Calcula el ángulo firmado entre la dirección del robot y el vector hacia el objetivo
    Funciona sin importar si el objetivo está arriba o abajo en la imagen.
    """
    # Vector desde el centro del robot hacia el objetivo (coordenadas de imagen)
    goal_vec = (objetivo[0] - centro[0], objetivo[1] - centro[1])

    # vector del robot (ya en coordenadas de imagen)
    vec = vector

    # Producto punto y cruz
    dot = vec[0]*goal_vec[0] + vec[1]*goal_vec[1]
    cross = vec[0]*goal_vec[1] - vec[1]*goal_vec[0]

    # Ángulo firmado en radianes [-pi, pi]
    angle = math.atan2(cross, dot)
    return angle


"""def calcular_signed_angle(vector, objetivo, centro):

    goal_vec_img = (objetivo[0] - centro[0], objetivo[1] - centro[1])
    # invertir Y si origen de imagen es esquina superior
    goal_vec = (goal_vec_img[0], -goal_vec_img[1])
    vec = (vector[0], -vector[1])

    dot = vec[0]*goal_vec[0] + vec[1]*goal_vec[1]
    cross = vec[0]*goal_vec[1] - vec[1]*goal_vec[0]
    return math.atan2(cross, dot)"""


def image_callback(msg):
    global centro_robot, vector_dir,size_roi,roi_global,objetivo

    img = bridge.compressed_imgmsg_to_cv2(msg, desired_encoding="bgr8")
    
    #if centro_robot is None:
        # Inicialmente, tomamos centro de la imagen como robot
    #    centro_robot = (img.shape[1]//2, img.shape[0]//2)
    #cv2.circle(img, (objetivo[0], objetivo[1]), 5, (0, 0, 255), -1)
    #print("Desglose:",centro_robot,objetivo, size_roi)
    roi, (x0, y0) = extraer_roi(img, centro_robot,objetivo, size_roi)
    
    vector,red_centroid,green_centroid,centro_local  = calcular_vector_flecha(roi)
    centro_robot = (centro_local[0] + x0, centro_local[1] + y0)
    #print("Desglose2:",vector,red_centroid,green_centroid,centro_robot)
    if vector is None:
        print("No se detecta flecha")
        return
    else:
        cv2.arrowedLine(roi, red_centroid, green_centroid, (255, 0, 0), 3, tipLength=0.3)

    vector_dir = vector
    roi_global = roi

def normalize_angle(angle):
    while angle > math.pi:
        angle -= 2*math.pi
    while angle < -math.pi:
        angle += 2*math.pi
    return angle


def calcular_ruta(ruta,paso,mask_copy,j,k,objetivo_cen,size):
    while ruta is None:
        ruta = bpa.busqueda_prioridad(mask_copy,(j,k,0,math.inf),objetivo_cen,size,paso)
        print("RUTA CALCULADA")
        print(ruta)
        if ruta is None : 
            paso -= 0.1
            if paso <= 0.0 : 
                print("Ruta no encontrada")
                break
        print("Seguimos intentando, no nos rendimos: ", paso)
        #time.sleep(1)
    return ruta

def callback_obstaculo(msg):
    global linear_speed_f,angular_speed
    if msg["data"] == "obstaculo detectado" :
        linear_speed_f = 0.0
        angular_speed = 0.0
    else:
        linear_speed_f = 0.5
        angular_speed = 0.3



def obtener_destinos():
    global Destinos
    print("Esperamos a recibir el conjunto de destinos a seguir")
    sub_ruta = rospy.Subscriber("/ruta", String, callback_ruta)
    while Destinos is None:
        time.sleep(1)
    print("Tenemos destinos", Destinos)
    sub_ruta.unregister()

def obtener_imagen_cenital():
    global img_save
    print("Obtenemos imagen de la fabrica")
    sub = rospy.Subscriber("/cenital", CompressedImage, callback)
    while img_save == False:
        time.sleep(1)
    print("Imagen guardada")
    #Cuando hemos obtenido un frame de toda la fabrica empezamos el proceso
    #1.- Nos desuscribimos de /cenital porque ya tenemos la imagen
    sub.unregister()
    print("Desubscrito")

def image_torito_callback(msg):pass

def main():
    global cmd_pub, zone1, zone2, img_save, img_obt_hsv,img_obt_bgr,img_obt_gray
    global objetivo,size_roi,roi_global,centro_robot,vector_dir,Destinos,angular_speed
    rospy.init_node("torito_zonas")
    zone1, zone2, robot1 = cargar_zonas("zonas_4_Esquinas.json")
    rospy.loginfo(f"Zonas cargadas: Z1={zone1}, Z2={zone2}")  
    cmd_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=1)
    rospy.Subscriber("/obstaculo", String, callback_obstaculo)

    obtener_destinos()

    for destino in Destinos:
        #1.- Obtenemos la imagen de la cenital, para calcular la ruta
        obtener_imagen_cenital()



        #2.- Sobre a imagen detectamos la posicion del robot que son los dos cubos rojo
        #y verde
        cen_rojo,cen_verde,vector,cen_robot = buscar_robot(img_obt_hsv.copy())
        #print(cen_rojo,cen_verde,cen_robot)
        #3.- Extraemos las posiciones centro del robot, y centro del objetivo
        (j,k) = cen_robot #centro del robot
        centro_robot = cen_robot
        #4.- Extraemos el tamaño del robot
        size = (robot1[1][0] - robot1[0][0] +15  , robot1[1][1] - robot1[0][1]+15)

        #Extraemos el punto al que debemos de alcanzar
        #print("objetivo_cen")
        #objetivo_cen = zone1[2]#objetivo_cen
        #print(objetivo_cen)
        objetivo_cen = (destino["x"],destino["y"])
        print(objetivo_cen)
 

        

        #5.- Calculamos la mascara
        #5.1.- Cogemos una copia del frame original, y con la posicon del robot
        # y su tamaño, pintamos sobre la imagen en la posicion que se encuentra

        #Creamos la copia del frame original
        copia_frame_mascara = img_obt_bgr.copy()

        #Pintamos un rectangulo sobre el robot
        rect = ((j, k), (size[0], size[1]), 0)  # (centro), (ancho, alto), ángulo
        box = cv2.boxPoints(rect)         # Obtiene las 4 esquinas
        box = np.int0(box)
        cv2.drawContours(copia_frame_mascara, [box], 0, (255, 255, 255), -1)

        copia2 = copia_frame_mascara.copy()
        copia3 = copia_frame_mascara.copy()

        #Convertimos a escala de grises
        mask_copy = cv2.cvtColor(copia2, cv2.COLOR_BGR2GRAY)

        #6.- Calculamos la ruta que tenemos que seguir - aplicamos busqueda
        #por prioridad
        print("Paso 6 --> Calcular ruta")
        paso = 1.0
        ruta = None
        ruta = calcular_ruta(ruta,paso,mask_copy,j,k,objetivo_cen,size)
        twist = Twist()

        if ruta is not None:
            print("Tenemos ruta",ruta)
            #7.- Con todos los puntos calculados, seguimos los pasos:
            #7.1.- Pintamos los puntos en la imagen
            for punto in ruta:
                x, y,ang,dis = punto
                cv2.circle(copia3, (x, y), 5, (0, 0, 255), -1)
            #7.2.- Pintamos un cuadrado que represente el robot
            #Pintamos un rectangulo sobre el robot
            rect = ((j, k), (size[0], size[1]), 0)  # (centro), (ancho, alto), ángulo
            box = cv2.boxPoints(rect)         # Obtiene las 4 esquinas
            box = np.int0(box)
            cv2.drawContours(copia3, [box], 0, (255, 0, 0), 2)
            
            cv2.imshow("Ruta", copia3)
            cv2.waitKey(1)
            #cv2.destroyAllWindows() """ # círculo rojo

            #Asignamos objetivo
            n_obj = 1
            siguiente_ob = False
            objetivo = (ruta[n_obj][0],ruta[n_obj][1])
            size_roi = size

            angle_fin = calcular_signed_angle(vector_dir, objetivo_final, centro_robot)
            if abs(angle_fin) < 0.05:
                pub1 = rospy.Publisher("/aviso_control", String, queue_size=1)
                pub1.publish(String(data="Controlame,"+destino["color"]))

                sub = rospy.Subscriber("/control_camara", CompressedImage, image_torito_callback) #Control por la camara
            else : 
                sub = rospy.Subscriber("/cenital", CompressedImage, image_callback) #Control por cenital
            
            rate = rospy.Rate(10)

            while not rospy.is_shutdown():
                if cen_robot is not None and vector_dir is not None:
                    if siguiente_ob:
                        siguiente_ob=False
                        n_obj+=1
                        if n_obj == len(ruta) :
                            n_obj = 0 
                            sub.unregister()
                            break
                    objetivo = (ruta[n_obj][0],ruta[n_obj][1])
                    objetivo_final = (ruta[-1][0],ruta[-1][1])
                    angle = calcular_signed_angle(vector_dir, objetivo, centro_robot)
                    angle_fin = calcular_signed_angle(vector_dir, objetivo_final, centro_robot)

                    if abs(angle_fin) < 0.05: pass #Control por la camara
                    else : pass #Control por cenital
                    
                    angle = normalize_angle(angle)
                    print(angle)
                    # girar hasta que angle sea ~0
                    if abs(angle) > 0.05:
                        twist.linear.x = 0.0
                        twist.angular.z = angular_speed if angle > 0 else -angular_speed
                    else:
                        dista = calcular_dist((centro_robot[0],centro_robot[1]),(objetivo[0],objetivo[1]))
                        if  dista > 100.0:
                            twist.linear.x = linear_speed_f
                            twist.angular.z = 0.0
                        elif dista > 50.0:
                            twist.linear.x = linear_speed_f
                            twist.angular.z = 0.0
                        elif dista > 25.0:
                            twist.linear.x = linear_speed_f
                            twist.angular.z = 0.0
                        else:
                            twist.linear.x = 0.0
                            twist.angular.z = 0.0
                            print("Objetivo alcanzado")
                            siguiente_ob = True
                    cmd_pub.publish(twist)
                if roi_global is not None:
                    cv2.imshow("ROI Robot", roi_global)
                    cv2.waitKey(1)
                rate.sleep()
            sub.unregister()
            print("Siguiente destino")
            #time.sleep(1)
            
    #8.- Objetivo alcanzado
    print("Paso 8: OBJETIVO ALCANZADOOOOOOOOO")
    rospy.spin()
    

if __name__ == "__main__":
    main()
