#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse
import os
import time

import numpy as np
import rospy
import tensorflow as tf

from rl.agents.dqn import DQNAgent
from rl.memory import SequentialMemory
from rl.policy import LinearAnnealedPolicy, EpsGreedyQPolicy
from tensorflow.keras.optimizers import Adam

# Importamos tu entorno, modelo y acciones desde tu script
from reinforce_Keras_4 import RLRedTargetEnv, build_model, GAMMA, ACCIONES


def crear_dqn_para_prueba(env):
    """
    Crea un DQN con la MISMA arquitectura que usas en entrenamiento,
    pero lo usaremos solo en modo 'test' (sin aprender).
    """
    nb_actions = env.action_space.n
    state_shape = env.observation_space.shape

    model = build_model(state_shape, nb_actions)

    memory = SequentialMemory(limit=50000, window_length=1)
    policy = LinearAnnealedPolicy(
        EpsGreedyQPolicy(),
        attr="eps",
        value_max=0.5,
        value_min=0.05,
        value_test=0.01,
        nb_steps=1,
    )

    dqn = DQNAgent(
        model=model,
        nb_actions=nb_actions,
        memory=memory,
        nb_steps_warmup=0,      # no entrenamos
        target_model_update=1e-2,
        policy=policy,
        gamma=GAMMA,
        train_interval=1,
        batch_size=16,
    )

    dqn.compile(Adam(learning_rate=5e-4), metrics=["mae"])
    return dqn


def probar_modelo_en_agente0(weights_path):
    """
    Carga el modelo .h5 indicado y lo prueba en el agente 0.
    Cada vez que haya colisión o éxito, reinicia episodio.
    Se repite hasta que cortes con Ctrl+C.
    """
    rospy.init_node("rl_red_target_dqn_test_agent0", anonymous=False)

    # Semillas (opcional)
    np.random.seed(int(time.time()) % (2 ** 32 - 1))
    tf.random.set_seed(int(time.time()) % (2 ** 32 - 1))

    # Entorno del agente 0
    env = RLRedTargetEnv(agent_id="0")

    # Creamos el DQN y cargamos pesos
    dqn = crear_dqn_para_prueba(env)

    if not os.path.isfile(weights_path):
        rospy.logerr("No se encontró el fichero de pesos: %s", weights_path)
        return

    rospy.loginfo("Cargando pesos desde %s", weights_path)
    dqn.load_weights(weights_path)
    dqn.training = False     # importantísimo: modo test
    dqn.step = 0
    dqn.reset_states()

    try:
        episodio_global = 0
        while not rospy.is_shutdown():
            episodio_global += 1
            rospy.loginfo("=== Episodio de prueba #%d con modelo %s ===",
                          episodio_global, weights_path)

            obs = env.reset()
            dqn.reset_states()
            done = False
            steps = 0
            total_reward = 0.0

            while not done and not rospy.is_shutdown():
                # Acción elegida por el DQN
                action = dqn.forward(obs)
                action_idx = int(action)

                # Decodificar acción a (nombre, v, w)
                name, v, w = ACCIONES[action_idx]

                # Llamada a step con la firma real:
                # step(self, action, reward, pasos_acumulados, modelo_actual)
                prev_reward = 0.0       # no lo usas dentro, así que 0.0 vale
                pasos_acumulados = steps
                modelo_actual = 0.0     # solo para logs internos en tu env

                next_obs, reward, done, info = env.step(
                    action_idx,
                    pasos_acumulados,
                    0.0,0.0,0.0
                )

                total_reward += reward
                steps += 1
                obs = next_obs

                collided = info.get("collided", False)
                success = info.get("success", False)
                front = info.get("front_dist", float("nan"))
                paso_env = info.get("step", steps)

                # LOG DE LO QUE HACE EN CADA PASO
                rospy.loginfo(
                    "[EP %d | paso %d] acción=%d (%s) v=%.2f w=%.2f "
                    "reward=%.3f total=%.3f front=%.2f collided=%s success=%s",
                    episodio_global, paso_env,
                    action_idx, name, v, w,
                    reward, total_reward, front,
                    collided, success
                )

                # Si quieres ver también el vector de estado completo, cambia a loginfo
                rospy.loginfo(
                    "[EP %d | paso %d] obs=%s",
                    episodio_global, paso_env,
                    np.array2string(obs, precision=3, separator=",")
                )

                if collided:
                    rospy.loginfo(
                        "Colisión en paso %d del episodio #%d. Reiniciando episodio...",
                        steps, episodio_global
                    )
                    break  # salimos del while interno y volvemos a hacer reset()

                if success:
                    rospy.loginfo(
                        "Objetivo alcanzado en paso %d del episodio #%d. Reiniciando episodio...",
                        steps, episodio_global
                    )
                    break

                # Si quieres cortar episodios muy largos aunque no haya colisión ni éxito,
                # puedes meter un límite, ej:
                # if steps >= 3000:
                #     rospy.loginfo("Fin de episodio por límite de pasos.")
                #     break

    except (rospy.ROSInterruptException, KeyboardInterrupt):
        rospy.loginfo("Prueba interrumpida por el usuario.")

    finally:
        env.close()
        rospy.loginfo("Entorno cerrado. Fin de la prueba.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Probar un modelo DQN en el agente 0, reiniciando en cada colisión/éxito."
    )
    parser.add_argument(
        "--weights",
        "-w",
        required=True,
        help="Ruta al fichero de pesos .h5 que quieres probar",
    )
    args = parser.parse_args()

    probar_modelo_en_agente0(args.weights)
