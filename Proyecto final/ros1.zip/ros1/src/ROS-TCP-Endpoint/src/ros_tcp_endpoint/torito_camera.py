#!/usr/bin/env python3
import rospy
import cv2
import numpy as np
import json
from sensor_msgs.msg import CompressedImage

CONFIG_FILE = "line_config.json"

class LineFollowerCompressed:
    def __init__(self):
        rospy.init_node("line_follower_compressed", anonymous=True)
        rospy.Subscriber("/torito", CompressedImage, self.image_callback, queue_size=1, buff_size=2**24)

        # Cargar configuración HSV desde JSON
        try:
            with open(CONFIG_FILE, "r") as f:
                self.cfg = json.load(f)
            rospy.loginfo(f"Configuración cargada desde {CONFIG_FILE}: {self.cfg}")
        except Exception as e:
            rospy.logwarn(f"No se pudo cargar {CONFIG_FILE}, usando valores por defecto. Error: {e}")
            self.cfg = {
                "H_min": 0, "S_min": 0, "V_min": 0,
                "H_max": 179, "S_max": 255, "V_max": 80
            }

        rospy.loginfo("Nodo seguidor de líneas iniciado")
        rospy.spin()

    def image_callback(self, msg):
        # Decodificar imagen desde CompressedImage
        np_arr = np.frombuffer(msg.data, np.uint8)
        frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        if frame is None:
            return

        # Convertir a HSV
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # Rango desde config
        lower = np.array([self.cfg["H_min"], self.cfg["S_min"], self.cfg["V_min"]])
        upper = np.array([self.cfg["H_max"], self.cfg["S_max"], self.cfg["V_max"]])

        # Máscara con rango HSV
        mask = cv2.inRange(hsv, lower, upper)

        # Región de interés (parte inferior)
        h, w = mask.shape
        roi = mask[int(h/2):h, :]

        # Bordes
        edges = cv2.Canny(roi, 50, 150)

        # Hough para detectar líneas largas (solo dos líneas principales)
        lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=100, minLineLength=300, maxLineGap=50)

        if lines is not None:
            # Convertir a coordenadas globales
            lines_full = []
            for line in lines:
                x1, y1, x2, y2 = line[0]
                lines_full.append([x1, y1 + int(h/2), x2, y2 + int(h/2)])

            # Ordenar por X promedio
            lines_sorted = sorted(lines_full, key=lambda l: (l[0]+l[2])/2)
            midpoint = w / 2

            # Dividir en izquierda y derecha
            left_lines = [l for l in lines_sorted if (l[0]+l[2])/2 < midpoint]
            right_lines = [l for l in lines_sorted if (l[0]+l[2])/2 >= midpoint]

            # Función para promedio de línea
            def avg_line(lines_group):
                x1 = int(np.mean([l[0] for l in lines_group]))
                y1 = int(np.mean([l[1] for l in lines_group]))
                x2 = int(np.mean([l[2] for l in lines_group]))
                y2 = int(np.mean([l[3] for l in lines_group]))
                return [x1, y1, x2, y2]

            if left_lines and right_lines:
                left_line = avg_line(left_lines)
                right_line = avg_line(right_lines)

                # Dibujar líneas principales en rojo grueso
                cv2.line(frame, (left_line[0], left_line[1]), (left_line[2], left_line[3]), (0,0,255), 5)
                cv2.line(frame, (right_line[0], right_line[1]), (right_line[2], right_line[3]), (0,0,255), 5)

                # Dibujar área entre las dos líneas en verde
                polygon = np.array([
                    [left_line[0], left_line[1]],
                    [left_line[2], left_line[3]],
                    [right_line[2], right_line[3]],
                    [right_line[0], right_line[1]]
                ])
                cv2.fillPoly(frame, [polygon], (0,255,0))

                rospy.loginfo(f"Líneas detectadas: Izquierda ({len(left_lines)} segmentos), Derecha ({len(right_lines)} segmentos)")

        # Mostrar imágenes de depuración
        cv2.imshow("Original", frame)
        cv2.imshow("Mascara", mask)
        cv2.imshow("ROI", roi)
        cv2.waitKey(1)

if __name__ == "__main__":
    try:
        LineFollowerCompressed()
    except rospy.ROSInterruptException:
        pass
    finally:
        cv2.destroyAllWindows()
