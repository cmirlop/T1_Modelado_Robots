#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import CompressedImage
import cv2
import numpy as np

def callback(msg):
    try:
        # Convertir los bytes JPEG/PNG a una imagen OpenCV
        np_arr = np.frombuffer(msg.data, np.uint8)
        image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

        # Mostrar la imagen
        cv2.imshow("Unity Camera", image)
        cv2.waitKey(1)  # Necesario para refrescar la ventana
    except Exception as e:
        rospy.logerr(f"Error al decodificar la imagen: {e}")

def listener():
    rospy.init_node('unity_camera_viewer', anonymous=True)
    rospy.Subscriber("/cenital", CompressedImage, callback, queue_size=1)
    rospy.loginfo("Escuchando imágenes en /unity_camera/compressed ...")
    rospy.spin()

    # Al salir, cerrar ventanas
    cv2.destroyAllWindows()

if __name__ == '__main__':
    listener()
