#!/usr/bin/env python3
import rospy, cv2, numpy as np, os
from cv_bridge import CvBridge
from sensor_msgs.msg import Image, CompressedImage
from collections import deque

# ======== CONFIG por defecto ========
TOPIC_CAM1 = "/cenital_izq"              # o ".../compressed" si usas CompressedImage
TOPIC_CAM2 = "/cenital_der"
FPS_BG_BUILD = 5
N_MEDIANA   = 80
THR_FG      = 35
K_OPEN      = 3
# ====================================

bridge = CvBridge()
q1, q2 = deque(maxlen=N_MEDIANA), deque(maxlen=N_MEDIANA)

bg1 = bg2 = None
H1 = H2 = None
panorama_size = None
pub_pano = pub_pano_c = None
pub_mask = pub_mask_c = None

# ---------- utilidades ----------
def build_median(frames):
    if len(frames) < max(5, int(0.5*N_MEDIANA)): return None
    arr = np.stack(frames, axis=3)
    return np.median(arr, axis=3).astype(np.uint8)

def foreground_mask(frame, bg):
    d = cv2.absdiff(frame, bg)
    g = cv2.cvtColor(d, cv2.COLOR_BGR2GRAY)
    _, m = cv2.threshold(g, THR_FG, 255, cv2.THRESH_BINARY)
    k = np.ones((K_OPEN, K_OPEN), np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, k, iterations=1)
    m = cv2.dilate(m, np.ones((5,5),np.uint8), iterations=1)
    return m

def detect_matches(imgA, imgB, maskA=None, maskB=None):
    orb = cv2.ORB_create(4000)
    def kp_desc(gray, mask):
        kps = orb.detect(gray, None)
        if mask is not None:
            kps = [kp for kp in kps if mask[int(kp.pt[1]), int(kp.pt[0])] == 0]
        return orb.compute(gray, kps)
    gA, gB = cv2.cvtColor(imgA, cv2.COLOR_BGR2GRAY), cv2.cvtColor(imgB, cv2.COLOR_BGR2GRAY)
    kA, dA = kp_desc(gA, maskA)
    kB, dB = kp_desc(gB, maskB)
    if dA is None or dB is None: return None, None, None
    bf = cv2.BFMatcher(cv2.NORM_HAMMING)
    m = bf.knnMatch(dA, dB, k=2)
    good = []
    for a,b in m:
        if a.distance < 0.75*b.distance:
            good.append((a.queryIdx, a.trainIdx))
    if len(good) < 12: return None, None, None
    ptsA = np.float32([kA[i].pt for i,_ in good]).reshape(-1,1,2)
    ptsB = np.float32([kB[j].pt for _,j in good]).reshape(-1,1,2)
    return ptsA, ptsB, good

def compute_h12(bgA, bgB, maskA=None, maskB=None):
    ptsA, ptsB, _ = detect_matches(bgA, bgB, maskA, maskB)
    if ptsA is None: return None
    H, _ = cv2.findHomography(ptsA, ptsB, cv2.RANSAC, 4.0)
    return H

def compute_canvas_params(bg1, bg2, H12):
    h1,w1 = bg1.shape[:2]
    h2,w2 = bg2.shape[:2]
    corners2 = np.float32([[0,0],[w2,0],[w2,h2],[0,h2]]).reshape(-1,1,2)
    corners1_w = cv2.perspectiveTransform(np.float32([[0,0],[w1,0],[w1,h1],[0,h1]]).reshape(-1,1,2), H12)
    allc = np.vstack((corners2, corners1_w))
    x_min, y_min = np.floor(allc.min(axis=0)[0]).astype(int)
    x_max, y_max = np.ceil(allc.max(axis=0)[0]).astype(int)
    tx, ty = -min(0, x_min), -min(0, y_min)
    W, H = x_max + tx, y_max + ty
    T = np.array([[1,0,tx],[0,1,ty],[0,0,1]], dtype=np.float32)
    return (int(W), int(H)), T

def blend_simple(base, over):
    mask = (over.sum(axis=2) > 0)
    base[mask] = over[mask]
    return base

def save_state(path, bg1, bg2, H1, H2, pano_size):
    os.makedirs(os.path.dirname(os.path.expanduser(path)), exist_ok=True)
    np.savez_compressed(os.path.expanduser(path),
                        bg1=bg1, bg2=bg2, H1=H1, H2=H2,
                        pano_w=pano_size[0], pano_h=pano_size[1])
    rospy.loginfo("Estado guardado en %s", os.path.expanduser(path))

def load_state(path):
    p = os.path.expanduser(path)
    if not os.path.exists(p):
        rospy.logwarn("No existe el estado en %s", p); return None
    data = np.load(p, allow_pickle=True)
    return data["bg1"], data["bg2"], data["H1"], data["H2"], (int(data["pano_w"]), int(data["pano_h"]))

# ---------- IO imágenes ----------
def to_cv2(msg, compressed):
    try:
        if compressed:
            # Opción A: cv_bridge
            return bridge.compressed_imgmsg_to_cv2(msg, desired_encoding="bgr8")
            # Opción B (equivalente):
            # np_arr = np.frombuffer(msg.data, np.uint8)
            # return cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        else:
            return bridge.imgmsg_to_cv2(msg, "bgr8")
    except Exception as e:
        rospy.logwarn("Error al convertir imagen: %s", e)
        return None

def publish_img(pub_raw, pub_comp, img, compressed):
    if compressed:
        pub_comp.publish(bridge.cv2_to_compressed_imgmsg(img, dst_format="jpg"))
    else:
        pub_raw.publish(bridge.cv2_to_imgmsg(img, "bgr8"))

def publish_mask(pub_raw, pub_comp, m, compressed):
    if compressed:
        # codificamos como jpg (mono)
        pub_comp.publish(bridge.cv2_to_compressed_imgmsg(m, dst_format="jpg"))
    else:
        pub_raw.publish(bridge.cv2_to_imgmsg(m, "mono8"))

# ---------- callbacks ----------
def make_cb(queue, input_is_compressed):
    def _cb(msg):
        img = to_cv2(msg, input_is_compressed)
        if img is not None: queue.append(img)
    return _cb

def main():
    global bg1, bg2, H1, H2, panorama_size
    rospy.init_node("panorama_sin_robot")

    # Params
    #mode = rospy.get_param("~mode", "run")  # "capture" o "run"
    mode = "run"
    state_path = rospy.get_param("~state_path", os.path.expanduser("~/panorama_state.npz"))
    debug_view = True
    topic1 = TOPIC_CAM1
    topic2 = TOPIC_CAM2
    input_is_compressed  = True
    publish_compressed  =False

    # Subs y pubs según tipo
    if input_is_compressed:
        rospy.Subscriber(topic1, CompressedImage, make_cb(q1, True), queue_size=1, buff_size=2**24)
        rospy.Subscriber(topic2, CompressedImage, make_cb(q2, True), queue_size=1, buff_size=2**24)
    else:
        rospy.Subscriber(topic1, Image, make_cb(q1, False), queue_size=1)
        rospy.Subscriber(topic2, Image, make_cb(q2, False), queue_size=1)

    pub_pano_raw = rospy.Publisher("/panorama", Image, queue_size=1) if not publish_compressed else None
    pub_pano_c   = rospy.Publisher("/cenital", CompressedImage, queue_size=1) if publish_compressed else None
    pub_mask_raw = rospy.Publisher("/robot_mask", Image, queue_size=1) if not publish_compressed else None
    pub_mask_c   = rospy.Publisher("/robot_mask/compressed", CompressedImage, queue_size=1) if publish_compressed else None

    rate = rospy.Rate(FPS_BG_BUILD)

    # Cargar estado si existe (modo run)
    if mode != "capture":
        loaded = load_state(state_path)
        if loaded is not None:
            bg1, bg2, H1, H2, panorama_size = loaded
            rospy.loginfo("Estado cargado. Panorama %dx%d", panorama_size[0], panorama_size[1])

    while not rospy.is_shutdown():
        # Construcción si no hay estado
        if bg1 is None or bg2 is None:
            if len(q1)==0 or len(q2)==0:
                rospy.loginfo_throttle(2.0, "Esperando imágenes…"); rate.sleep(); continue
            bg1 = build_median(list(q1)) if bg1 is None else bg1
            bg2 = build_median(list(q2)) if bg2 is None else bg2
            if bg1 is None or bg2 is None:
                rospy.loginfo_throttle(2.0, "Construyendo fondos… mueve/quita el robot."); rate.sleep(); continue

        if H1 is None or H2 is None or panorama_size is None:
            m1 = foreground_mask(q1[-1], bg1) if len(q1)>0 else None
            m2 = foreground_mask(q2[-1], bg2) if len(q2)>0 else None
            H12 = compute_h12(bg1, bg2, m1, m2)
            if H12 is None:
                rospy.logwarn_throttle(2.0, "No se pudo estimar homografía todavía."); rate.sleep(); continue
            panorama_size, T = compute_canvas_params(bg1, bg2, H12)
            H1 = T.dot(H12)  # cam1 -> lienzo
            H2 = T           # cam2 -> lienzo
            rospy.loginfo("Homografías listas. Panorama %dx%d", panorama_size[0], panorama_size[1])

        # Si estamos capturando, guardar y salir
        if mode == "capture":
            save_state(state_path, bg1, bg2, H1, H2, panorama_size)
            rospy.loginfo("Modo capture completado. Cerrando nodo.")
            return

        # ---- ejecución en vivo ----
        pano_base = np.zeros((panorama_size[1], panorama_size[0], 3), dtype=np.uint8)
        w1 = cv2.warpPerspective(bg1, H1, panorama_size)
        w2 = cv2.warpPerspective(bg2, H2, panorama_size)
        pano_base = blend_simple(pano_base, w2)
        pano_base = blend_simple(pano_base, w1)

        if len(q1)==0 or len(q2)==0:
            rate.sleep(); continue

        f1, f2 = q1[-1], q2[-1]
        mask1 = foreground_mask(f1, bg1)
        mask2 = foreground_mask(f2, bg2)

        move1 = cv2.warpPerspective(f1, H1, panorama_size)
        move2 = cv2.warpPerspective(f2, H2, panorama_size)
        m1w   = cv2.warpPerspective(mask1, H1, panorama_size)
        m2w   = cv2.warpPerspective(mask2, H2, panorama_size)

        pano = pano_base.copy()
        pano[m2w>0] = move2[m2w>0]
        pano[m1w>0] = move1[m1w>0]
        mask_final = np.clip(m1w.astype(np.uint16) + m2w.astype(np.uint16), 0, 255).astype(np.uint8)

        # publicar
        if publish_compressed:
            publish_img(None, pub_pano_c, pano, True)
            publish_mask(None, pub_mask_c, mask_final, True)
        else:
            publish_img(pub_pano_raw, None, pano, False)
            publish_mask(pub_mask_raw, None, mask_final, False)

        if debug_view:
            cv2.imshow("Panorama", pano); cv2.imshow("Mask", mask_final)
            if cv2.waitKey(1) & 0xFF == 27: break

        rate.sleep()

if __name__ == "__main__":
    main()
