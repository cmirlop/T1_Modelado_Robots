#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import time
import math

import numpy as np
import rospy
import tensorflow as tf
from tensorflow.keras.optimizers import Adam

from reinforce_Keras_4 import (
    RLRedTargetEnv,
    build_model,
    ACCIONES,
    CLIP_DIST,
    PASOS_MAX_EPISODIO,
    extrae_objetivo_rojo,
    min_range_at_angle,
)

# --------------------------
# Parámetros del "experto" (mismo espíritu que MazeLidarRedController)
# --------------------------
DIST_AHEAD_CLEAR = 10.0
DIST_WALL_FAR    = 12.0
DIST_WALL_CLOSE  = 6.0

CENTER_THRESH = 0.17
AREA_GOAL     = 40000
AREA_SEEK     = 500


def action_idx_by_name(name):
    for i, (n, v, w) in enumerate(ACCIONES):
        if n == name:
            return i
    # fallback si no existe ese nombre
    return 0


def expert_action_idx_from_obs(front, left, right, found, bearing, area):
    """
    Experto discreto que devuelve directamente un índice de ACCIONES,
    imitando la lógica de seguir pared izquierda + parar con rojo centrado,
    pero evitando oscilar izquierda/derecha cuando está contra una pared.
    Ahora además, si ve rojo con un área mínima, va a buscarlo.
    """

    # 1) Si ve objetivo rojo MUY grande y centrado -> STOP (igual que antes)
    if found and (bearing is not None) and abs(bearing) < CENTER_THRESH and area >= AREA_GOAL:
        return action_idx_by_name("stop")

    # Normalizo distancias si vienen como None
    if front is None:
        front = CLIP_DIST
    if left is None:
        left = CLIP_DIST
    if right is None:
        right = CLIP_DIST

    # 1.b) Si ve rojo suficientemente grande -> ir a buscarlo
    #      (área >= AREA_SEEK) mientras no tengamos algo justo delante.
    if found and (bearing is not None) and area >= AREA_SEEK:
        # Si hay obstáculo muy cerca delante, primero escapar girando
        if front <= DIST_WALL_CLOSE:
            return action_idx_by_name("left")  # o "right" si prefieres

        # Objetivo casi centrado -> avanzar hacia él
        if abs(bearing) < CENTER_THRESH:
            return action_idx_by_name("forward")

        # Objetivo desviado -> girar hacia él
        if bearing > 0:
            # target a la derecha
            if any(n == "right_soft" for (n, _, _) in ACCIONES):
                return action_idx_by_name("right_soft")
            else:
                return action_idx_by_name("right")
        else:
            # target a la izquierda
            if any(n == "left_soft" for (n, _, _) in ACCIONES):
                return action_idx_by_name("left_soft")
            else:
                return action_idx_by_name("left")

    # 2) Si no estamos buscando rojo, seguimos con la política de pared izquierda

    # Delante despejado
    if front > DIST_AHEAD_CLEAR:
        # Sin pared izquierda -> buscamos pared izquierda (giro suave)
        if left > DIST_WALL_FAR:
            if any(n == "left_soft" for (n, _, _) in ACCIONES):
                return action_idx_by_name("left_soft")
            else:
                return action_idx_by_name("left")

        # Pared a distancia razonable -> avanzar recto
        elif DIST_WALL_CLOSE < left <= DIST_WALL_FAR:
            return action_idx_by_name("forward")

        # Demasiado pegado a la izquierda -> separarse (giro suave derecha)
        else:  # left <= DIST_WALL_CLOSE
            if any(n == "right_soft" for (n, _, _) in ACCIONES):
                return action_idx_by_name("right_soft")
            else:
                return action_idx_by_name("right")

    # 3) Obstáculo delante -> giro de escape SIEMPRE AL MISMO LADO
    #    Para no oscilar por ruido en left/right
    return action_idx_by_name("left")  # o "right" si lo prefieres


def collect_expert_dataset(env,
                           max_steps=20000,
                           min_wait_for_sensors=1.0):
    """
    Recorre el entorno usando SIEMPRE la política experta discreta y guarda
    (estado, acción_experta) para entrenamiento supervisado.

    Devuelve:
      X: np.array [N, state_dim]
      y: np.array [N] con índices de acción.
    """

    rospy.loginfo("Esperando %.1f s a que se estabilicen los sensores...", min_wait_for_sensors)
    rospy.sleep(min_wait_for_sensors)

    obs_list = []
    act_list = []

    total_steps = 0
    episodios = 0

    obs = env.reset()
    done = False
    ep_steps = 0

    while not rospy.is_shutdown() and total_steps < max_steps:
        # si no hay lidar, esperamos un momento
        if not env.lidar_ok or env.last_lidar is None:
            rospy.sleep(0.05)
            continue

        # Recuperamos la información tal y como la ve el entorno
        state_vec, mins, (found, bearing, area), front, dist_left, dist_right = env._obtener_estado()
        # state_vec debería coincidir con 'obs'
        obs = state_vec

        # Acción experta discreta
        a_idx = expert_action_idx_from_obs(
            front, dist_left, dist_right, found, bearing, area
        )

        # Registramos par (estado, acción)
        obs_list.append(obs.astype(np.float32))
        act_list.append(int(a_idx))

        # Ejecutamos esa acción en el entorno para avanzar
        next_obs, reward, done, info = env.step(
            a_idx,            # reward previo (no se usa)
            total_steps,    # pasos_acumulados (solo logs)
            0.0,0.0,0.0             # modelo_actual (solo logs)
        )

        obs = next_obs
        total_steps += 1
        ep_steps += 1

        if done or ep_steps >= PASOS_MAX_EPISODIO:
            episodios += 1
            rospy.loginfo("Fin de episodio experto #%d tras %d pasos (total=%d)",
                          episodios, ep_steps, total_steps)
            obs = env.reset()
            ep_steps = 0
            done = False

    X = np.array(obs_list, dtype=np.float32)
    y = np.array(act_list, dtype=np.int64)
    rospy.loginfo("Dataset experto recogido: X=%s, y=%s", X.shape, y.shape)
    return X, y


def pretrain_dqn_with_expert(env,
                             X,
                             y,
                             epochs=10,
                             batch_size=64,
                             save_path="dqn_pretrained_expert.h5"):
    """
    Entrena el modelo de build_model para imitar la política experta.
    Usa cross-entropy sobre la salida lineal (logits).
    """
    nb_actions = env.action_space.n
    state_shape = env.observation_space.shape  # (state_dim,)

    model = build_model(state_shape, nb_actions)

    loss = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True)
    model.compile(optimizer=Adam(learning_rate=5e-4),
                  loss=loss,
                  metrics=["accuracy"])

    # build_model espera input=(batch, window_length=1, state_dim)
    X_in = X.reshape((X.shape[0], 1) + state_shape)

    rospy.loginfo("Comenzando preentrenamiento supervisado: epochs=%d, batch_size=%d",
                  epochs, batch_size)
    model.fit(
        X_in, y,
        epochs=epochs,
        batch_size=batch_size,
        shuffle=True
    )

    model.save_weights(save_path)
    rospy.loginfo("Pesos preentrenados guardados en: %s", save_path)


if __name__ == "__main__":
    rospy.init_node("pretrain_dqn_with_expert", anonymous=False)

    # Semillas (opcional)
    np.random.seed(int(time.time()) % (2 ** 32 - 1))
    tf.random.set_seed(int(time.time()) % (2 ** 32 - 1))

    env = RLRedTargetEnv(agent_id="0")

    try:
        # 1) Recoger dataset del experto discreto
        X, y = collect_expert_dataset(
            env,
            max_steps=3000  # súbelo si quieres más demostraciones
        )

        # 2) Preentrenar el modelo
        pretrain_dqn_with_expert(
            env,
            X,
            y,
            epochs=10,
            batch_size=64,
            save_path="dqn_pretrained_expert.h5"
        )

    except (rospy.ROSInterruptException, KeyboardInterrupt):
        rospy.loginfo("Preentrenamiento interrumpido por el usuario.")

    finally:
        env.close()
        rospy.loginfo("Entorno cerrado. Fin del preentrenamiento.")
