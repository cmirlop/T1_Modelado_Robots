#!/usr/bin/env python3
import rospy
import cv2
import json
from sensor_msgs.msg import CompressedImage
from cv_bridge import CvBridge

bridge = CvBridge()
zonas_file = "zonas.json"
zonas_guardadas = False

def select_zones(frame):
    """Seleccionar 2 zonas con el ratón y guardarlas en JSON"""
    rospy.loginfo("Selecciona la ZONA 1 y pulsa ENTER/ESPACIO")
    r1 = cv2.selectROI("Seleccion Zonas", frame, fromCenter=False, showCrosshair=True)
    zone1 = (int(r1[0] + r1[2] / 2), int(r1[1] + r1[3] / 2))

    rospy.loginfo("Selecciona la ZONA 2 y pulsa ENTER/ESPACIO")
    r2 = cv2.selectROI("Seleccion Zonas", frame, fromCenter=False, showCrosshair=True)
    zone2 = (int(r2[0] + r2[2] / 2), int(r2[1] + r2[3] / 2))

    cv2.destroyWindow("Seleccion Zonas")

    data = {"zone1": zone1, "zone2": zone2}
    with open(zonas_file, "w") as f:
        json.dump(data, f)

    rospy.loginfo(f"Zonas guardadas en {zonas_file}: {data}")

    # 🔴 Cerrar ejecución automáticamente
    rospy.signal_shutdown("Zonas seleccionadas y guardadas")

def callback(msg):
    global zonas_guardadas
    if zonas_guardadas:
        return
    frame = bridge.compressed_imgmsg_to_cv2(msg, desired_encoding="bgr8")
    select_zones(frame)
    zonas_guardadas = True

def main():
    rospy.init_node("selector_zonas")
    rospy.Subscriber("/cenital", CompressedImage, callback)
    rospy.spin()

if __name__ == "__main__":
    main()
