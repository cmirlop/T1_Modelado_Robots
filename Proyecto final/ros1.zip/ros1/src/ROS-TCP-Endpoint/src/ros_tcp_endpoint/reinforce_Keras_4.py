#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Versión del agente RL para el objetivo rojo usando Keras-RL + TensorFlow (DQN)
con soporte multi-agente (2 robots).

En este script:
- Solo se usan los agentes "0" y "1".
- Fase 1:
    * Se lanzan 2 procesos en paralelo, uno por agente.
    * Cada proceso entrena su propio DQN durante 10 episodios.
    * Se mide la recompensa media de esos 10 episodios.
    * Se selecciona el modelo con mejor recompensa media.
- Fase 2:
    * Se vuelven a lanzar 2 procesos (agentes "0" y "1") pero ahora
      ambos parten del modelo ganador de la Fase 1.
    * De nuevo, 10 episodios por agente.
- Se genera un CSV con los resultados de todos los episodios.
"""

import rospy
import numpy as np
import threading
import multiprocessing as mp
import time
from collections import deque
import os
import csv
import math

import cv2

from geometry_msgs.msg import Twist, Point
from sensor_msgs.msg import LaserScan, CompressedImage
from std_srvs.srv import Empty
from std_msgs.msg import String

# === Keras / TensorFlow / Keras-RL ===
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten
from tensorflow.keras.optimizers import Adam

import gym
from gym import spaces

from rl.agents.dqn import DQNAgent
from rl.memory import SequentialMemory
from rl.policy import EpsGreedyQPolicy, LinearAnnealedPolicy

# ==========================
# Tópicos ROS (prefijo; luego se añade agent_id)
# ==========================
LIDAR_TOPIC = "/lidar"
CAM_TOPIC   = "/camara_robot"   # sensor_msgs/CompressedImage
CMD_TOPIC   = "/cmd_vel"
COLISION_TOPIC = "/aviso_colision"
POS_TOPIC   = "/posiconrobot"
# ==========================
# LiDAR (discretización)
# ==========================
NUM_SECTORES = 180
BINS_DIST = [6, 10, 30]        # cerca / medio / lejos (m)
CLIP_DIST = 30
COLLISION_DIST = 5

OPEN_PROBE_THRESH = 20.0
GUIDE_PROB = 0.8
ANGLE_WINDOW_DEG = 8.0

LAMBDA_EXPERTO = 0.5

# Early stopping dentro de un episodio de entrenamiento
EARLY_STOP_CHECK_EVERY = 1000   # cada cuántos pasos mirar si mejora
EARLY_STOP_PATIENCE = 3         # nº de revisiones sin mejora antes de parar
EARLY_STOP_MIN_DELTA = 0.01     # mejora mínima en la media para considerarlo "mejor"
GLOBAL_EARLY_STOP_PATIENCE = 3
# ==========================
# Cámara / visión del objetivo rojo
# ==========================
IMG_RESIZE_W = 320
AREA_MIN = 100
AREA_GOAL = 35000
CENTER_THRESH = 0.17

LOW1  = (0,   90,  80)
HIGH1 = (10,  255, 255)
LOW2  = (170, 90,  80)
HIGH2 = (180, 255, 255)

# ==========================
# Acciones (v,w)
# ==========================
ACCIONES = [
    ("forward",      3.00,  0.0),
    ("left",         0.00, -1.0),
    ("right",        0.00,  1.0),
    ("left_soft",    0.00, -0.5),   # IZQ_suave
    ("right_soft",   0.00,  0.5),   # DER_suave
    ("slow",         1.00,  0.0),
    ("back",         -0.10,  0.0),
    #("stop",         0.00,  0.0),
]

# ==========================
# Hiperparámetros RL
# ==========================
GAMMA = 0.97


PASOS_MAX_EPISODIO = 700
MAX_EPISODIOS = 100   # (no se usa directamente en este ejemplo)
EPISODIOS_POR_BLOQUE = 10  # número de episodios por agente en cada fase
PASOS_EPISODIO = 3000
ESPERA_INICIO = 0.1
HZ_CONTROL = 10
COOLDOWN_COLISION = 0.1
RESET_SERVICE = "/reset_world"

# IDs de los agentes (2 robots)
AGENT_IDS = ["0", "1","2","3","4","5","6","7"]

# =====================================
# Funciones auxiliares de LiDAR / visión
# =====================================

def min_range_at_angle(scan_msg, angle_rad, window_deg=8.0, fallback=np.inf):
    ranges = np.asarray(scan_msg.ranges, dtype=np.float32)
    n = ranges.size
    if n == 0:
        return fallback

    angle_min = scan_msg.angle_min
    inc = scan_msg.angle_increment
    rng_max = scan_msg.range_max if np.isfinite(scan_msg.range_max) and scan_msg.range_max > 0 else CLIP_DIST

    idx_center = int(round((angle_rad - angle_min) / inc))
    half_w = max(1, int(round(np.deg2rad(window_deg) / abs(inc))))

    i0 = max(0, idx_center - half_w)
    i1 = min(n, idx_center + half_w + 1)

    seg = ranges[i0:i1]
    seg = seg[np.isfinite(seg)]
    if seg.size == 0:
        return fallback

    val = float(np.clip(np.min(seg), 0.0, rng_max))
    return val

def min_range_at_angle2(scan_msg, angle_rad, window_deg=8.0, fallback=np.inf):
    """
    Devuelve la distancia mínima en torno a un ángulo concreto (en radianes),
    promediando dentro de una ventana de 'window_deg' grados.
    """
    ranges = np.asarray(scan_msg.ranges, dtype=np.float32)
    n = ranges.size
    if n == 0:
        return fallback

    angle_min = scan_msg.angle_min
    inc = scan_msg.angle_increment

    rng_max = scan_msg.range_max
    if not np.isfinite(rng_max) or rng_max <= 0:
        rng_max = CLIP_DIST

    # Índice central correspondiente al ángulo que pedimos
    idx_center = int(round((angle_rad - angle_min) / inc))

    # Ancho de la ventana en índices
    half_w = max(1, int(round(np.deg2rad(window_deg) / abs(inc))))

    i0 = max(0, idx_center - half_w)
    i1 = min(n, idx_center + half_w + 1)

    seg = ranges[i0:i1]
    seg = seg[np.isfinite(seg)]
    if seg.size == 0:
        return fallback

    val = float(np.clip(np.min(seg), 0.0, rng_max))
    return val


def discretiza_dist(d):
    if d < BINS_DIST[0]:
        return 0
    if d < BINS_DIST[1]:
        return 1
    return 2


def sectoriza(scan_msg, num_sectores):
    ranges = np.array(scan_msg.ranges, dtype=np.float32)
    ranges[~np.isfinite(ranges)] = CLIP_DIST

    angle_min = scan_msg.angle_min
    angle_inc = scan_msg.angle_increment
    n = ranges.shape[0]

    zero_idx = int(round((0.0 - angle_min) / angle_inc))
    zero_idx = np.clip(zero_idx, 0, n - 1)

    rotated = np.roll(ranges, -(zero_idx - n // 2))

    step = max(1, n // num_sectores)
    mins = []
    for i in range(num_sectores):
        seg = rotated[i * step:(i + 1) * step] if (i + 1) * step <= n else rotated[i * step:]
        if seg.size == 0:
            mins.append(CLIP_DIST)
        else:
            mins.append(float(np.clip(np.min(seg), 0.0, CLIP_DIST)))

    return np.array(mins, dtype=np.float32)


def bins_lidar(mins):
    return [discretiza_dist(d) for d in mins]


def discretiza_bearing(bearing_norm):
    if bearing_norm < -0.12:
        return 0  # izquierda
    if bearing_norm > 0.12:
        return 2  # derecha
    return 1      # centrado


def discretiza_area(area):
    if area < 100:
        return 0
    if area < 2000:
        return 1
    return 2


def extrae_objetivo_rojo(cv_bgr,id):
    """
    Devuelve: found(bool), bearing_norm(-1..1), area(int), bbox(x,y,w,h)
    """
    if cv_bgr is None:
        return False, None, 0, None

    h, w = cv_bgr.shape[:2]
    scale = float(IMG_RESIZE_W) / float(w)
    cv_small = cv2.resize(cv_bgr, (IMG_RESIZE_W, int(h * scale))) if w > IMG_RESIZE_W else cv_bgr
    H, W = cv_small.shape[:2]

    hsv = cv2.cvtColor(cv_small, cv2.COLOR_BGR2HSV)
    mask1 = cv2.inRange(hsv, np.array(LOW1), np.array(HIGH1))
    mask2 = cv2.inRange(hsv, np.array(LOW2), np.array(HIGH2))
    mask = cv2.bitwise_or(mask1, mask2)

    kernel = np.ones((3, 3), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return False, None, 0, None

    c = max(contours, key=cv2.contourArea)
    area = int(cv2.contourArea(c))
    #print("Agente: ",id, "area:   ", area)
    if area < AREA_MIN:
        return False, None, area, None

    x, y, wc, hc = cv2.boundingRect(c)
    cx = x + wc / 2.0
    bearing_norm = (cx - (W / 2.0)) / (W / 2.0)

    return True, float(bearing_norm), int(area), (x, y, wc, hc)


"""def observa_estado(lidar_mins, bearing_norm, area):
    lidar_bins = bins_lidar(lidar_mins)
    bearing_bin = 3  # 3 => “no visto”
    area_bin = 0
    if bearing_norm is not None:
        bearing_bin = discretiza_bearing(bearing_norm)
        area_bin = discretiza_area(area)
    front_blocked = 1 if lidar_mins[len(lidar_mins) // 2] < BINS_DIST[0] else 0
    return tuple(lidar_bins + [bearing_bin, area_bin, front_blocked])
"""
def observa_estado(lidar_mins, bearing_norm, area):
    # 1) LIDAR continuo, normalizado 0..1
    mins_clipped = np.clip(lidar_mins, 0.0, CLIP_DIST)
    mins_norm = mins_clipped / float(CLIP_DIST)   # 0 = muy cerca, 1 = lejos

    # 2) Visión también continua
    if bearing_norm is None:
        bearing_val = 0.0      # “no visto”, neutro
        area_val = 0.0
    else:
        bearing_val = float(np.clip(bearing_norm, -1.0, 1.0))  # ya viene -1..1
        AREA_MAX = 9000.0      # por ejemplo, según lo que observes en tu cámara
        area_val = float(np.clip(area / AREA_MAX, 0.0, 1.0))

    # 3) Flag de colisión delante (0/1)
    front_blocked = 1.0 if lidar_mins[len(lidar_mins) // 2] < COLLISION_DIST else 0.0

    # 4) Construimos estado
    return tuple(list(mins_norm) + [bearing_val, area_val, front_blocked])

def lateral_sector_indices(scan_msg, num_sectores):
    angle_min = scan_msg.angle_min
    angle_inc = scan_msg.angle_increment
    n = len(scan_msg.ranges)

    angle_max = angle_min + (n - 1) * angle_inc
    fov = angle_max - angle_min  # campo de visión total del láser (en radianes)

    sectors_per_rad = float(num_sectores) / float(fov)

    center = num_sectores // 2
    offset_90 = int(round((math.pi / 2.0) * sectors_per_rad))

    idx_left  = int(np.clip(center + offset_90, 0, num_sectores - 1))  # +90°, izquierda
    idx_right = int(np.clip(center - offset_90, 0, num_sectores - 1))  # -90°, derecha

    return idx_left, idx_right

# ==========================
# Entorno Gym + ROS (un solo robot)
# ==========================

class RLRedTargetEnv(gym.Env):
    """
    Entorno Gym que encapsula la lógica ROS del robot persiguiendo el objetivo rojo.
    Un agent_id => un robot (topics sufijados con ese id).
    """

    metadata = {'render.modes': []}

    def __init__(self, agent_id="0"):
        super(RLRedTargetEnv, self).__init__()

        self.agent_id = str(agent_id)
        self.lock = threading.Lock()

        # Publishers / Subscribers
        self.twist_pub = rospy.Publisher(CMD_TOPIC + self.agent_id, Twist, queue_size=1)
        self.col_pub = rospy.Publisher(COLISION_TOPIC + self.agent_id, String, queue_size=1)
        self.lidar_sub = rospy.Subscriber(LIDAR_TOPIC + self.agent_id, LaserScan, self.cb_lidar, queue_size=1)
        self.img_sub = rospy.Subscriber(CAM_TOPIC + self.agent_id, CompressedImage, self.cb_img, queue_size=1)
        self.pos_sub = rospy.Subscriber(POS_TOPIC + self.agent_id,
                                        Point,
                                        self.cb_pos,
                                        queue_size=1)

        rospy.loginfo("Agente %s usando topics: %s, %s, %s, %s",
                      self.agent_id,
                      CMD_TOPIC + self.agent_id,
                      COLISION_TOPIC + self.agent_id,
                      LIDAR_TOPIC + self.agent_id,
                      CAM_TOPIC + self.agent_id)

        # Estado de sensores
        self.last_lidar = None
        self.lidar_ok = False

        self.last_bgr = None
        self.image_ok = False

        # Posición del robot (x, y, z) en el frame que publiques desde Unity
        self.robot_pos = np.zeros(3, dtype=np.float32)
        self.pos_ok = False

        # Variables de visión
        self.last_found = False
        self.last_bearing = None
        self.last_area = 0

        # Contadores para shaping de reward
        self.cont_gir = 0
        self.ant_name = None
        self.cont_Rec = 0
        self.cont_giros = 0

        # Historial de visión previa
        self.prev_vision = (False, None, 0)

        # Servicio reset
        self.reset_srv = None
        try:
            rospy.wait_for_service(RESET_SERVICE, timeout=2.0)
            self.reset_srv = rospy.ServiceProxy(RESET_SERVICE, Empty)
            rospy.loginfo("Servicio de reset disponible: %s", RESET_SERVICE)
        except rospy.ROSException:
            rospy.logwarn("No se encontró servicio %s. Seguimos sin reset mundo.", RESET_SERVICE)

        # Espacios Gym
        self.state_dim = NUM_SECTORES + 5 + 3
        self.action_space = spaces.Discrete(len(ACCIONES))
        self.observation_space = spaces.Box(
            low=-500.0,
            #high=3.0,
            high=500.0,
            shape=(self.state_dim,),
            dtype=np.float32
        )

        self.step_count = 0
        self.episodio = 0

    # ---------- Callbacks ROS ----------

    def cb_lidar(self, msg):
        with self.lock:
            self.last_lidar = msg
            self.lidar_ok = True

    def cb_img(self, msg):
        np_arr = np.frombuffer(msg.data, np.uint8)
        bgr = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        with self.lock:
            self.last_bgr = bgr
            self.image_ok = True

    def cb_pos(self, msg):
        """Callback de la posición del robot (geometry_msgs/Point)."""
        with self.lock:
            self.robot_pos = np.array([msg.x, msg.y, msg.z], dtype=np.float32)
            self.pos_ok = True
    # ---------- Utilidades internas ----------

    def _publicar_twist(self, v, w):
        t = Twist()
        t.linear.x = v
        t.angular.z = w
        self.twist_pub.publish(t)

    def _stop(self):
        self._publicar_twist(0.0, 0.0)

    def _obtener_estado(self):
        if not self.lidar_ok or self.last_lidar is None:
            return None, None, (False, None, 0), None
        
        front_dist = min_range_at_angle2(self.last_lidar, 0.0,
                                        window_deg=90.0,
                                        fallback=CLIP_DIST)
        left_dist  = min_range_at_angle2(self.last_lidar,  math.pi / 2.0,
                                        window_deg=90.0,
                                        fallback=CLIP_DIST)
        right_dist = min_range_at_angle2(self.last_lidar, -math.pi / 2.0,
                                        window_deg=90.0,
                                        fallback=CLIP_DIST)

        mins = sectoriza(self.last_lidar, NUM_SECTORES)
        #idx_left, idx_right = lateral_sector_indices(self.last_lidar, NUM_SECTORES)

        #dist_left  = mins[idx_left]
        #dist_right = mins[idx_right]

        found, bearing, area = False, None, 0
        if self.image_ok and self.last_bgr is not None:
            found, bearing, area, _ = extrae_objetivo_rojo(self.last_bgr, self.agent_id)
        
        # Posición del robot
        if self.pos_ok:
            pos = self.robot_pos
        else:
            pos = np.zeros(3, dtype=np.float32)
        #if self.agent_id == "0" : print(self.robot_pos)

        s_tuple = observa_estado(mins, bearing, area)
        state_vec = np.array(s_tuple, dtype=np.float32)
        front = mins[NUM_SECTORES // 2]
        # NUEVO: flags de bloqueo lateral
        left_blocked  = 1.0 if left_dist  < COLLISION_DIST else 0.0
        right_blocked = 1.0 if right_dist < COLLISION_DIST else 0.0
        # Concatenamos
        state_vec = np.concatenate([state_vec, [left_blocked, right_blocked]]).astype(np.float32)
        state_vec = np.concatenate([state_vec, pos], axis=0)

        #if self.agent_id == 0 : print(self.agent_id,"Front:  ",front)

        return state_vec, mins, (found, bearing, area), front,left_dist,right_dist

    # ---------- Lógica de colisión, éxito, recompensa ----------

    def colision(self, mins_now):
        if mins_now is None:
            return False
        return np.any(mins_now < COLLISION_DIST)
    
    def accion_experta(self, front, izq, der, vision):
        """
        Aproximación de la política del experto (proyecto_basico.py) pero
        devolviendo un índice de ACCIONES.
        front, izq, der: distancias delante / izquierda / derecha (m)
        vision: (found, bearing, area) del objetivo rojo.
        """
        found, bearing, area = vision

        # --- 1) Si ve el objetivo rojo grande y centrado, el experto se para ---
        if found and (bearing is not None) and abs(bearing) < CENTER_THRESH and area >= AREA_GOAL:
            expert_v = 0.0
            expert_w = 0.0
        else:
            # --- 2) Reglas de seguir pared izquierda (como el controlador reactivo) ---
            dist_ahead_clear = 10.0
            dist_wall_far    = 12.0
            dist_wall_close  = 6.0

            if front > dist_ahead_clear:
                # Sin pared a la izquierda -> busca pared izquierda (giro suave a la izq)
                if izq > dist_wall_far:
                    expert_v = 3.0
                    expert_w = -0.5       # left_soft
                # Pared a distancia buena -> avanza recto
                elif dist_wall_close < izq <= dist_wall_far:
                    expert_v = 3.0
                    expert_w = 0.0        # forward
                # Demasiado pegado a la pared izq -> separarse girando a la derecha
                else:
                    expert_v = 1.0
                    expert_w = 0.5        # right_soft
            else:
                # Obstáculo delante: giro de escape hacia el lado más despejado
                expert_v = 0.0
                if izq > der:
                    expert_w = 1.0        # right
                else:
                    expert_w = -1.0       # left

        # --- 3) Mapear (v,w) del experto al índice discreto de ACCIONES ---
        best_idx = 0
        best_err = float("inf")
        for i, (_, v, w) in enumerate(ACCIONES):
            err = (v - expert_v) ** 2 + (w - expert_w) ** 2
            if err < best_err:
                best_err = err
                best_idx = i

        return best_idx


    def exito2(self, found, bearing, area, front):
        if not found or bearing is None:
            return False
        centered = abs(bearing) < CENTER_THRESH
        big = area >= AREA_GOAL
        f = front < 8.0
        return centered and big and f

    def exito(self, found, bearing, area, front):
        if not found or bearing is None or area is None:
            return False
        centered = abs(bearing) < CENTER_THRESH
        big = area >= AREA_GOAL
        return centered and big



    
    def recompensa(self, a_idx, obs_prev, obs_now, collided, success,
               front_next, izq, der, area):
        # Coste base por paso
        r = -0.01

        name, v, w = ACCIONES[a_idx]
        (found_prev, bearing_prev, area_prev) = obs_prev
        (found_now, bearing_now, area_now) = obs_now

        # Usamos área actual consistente
        area_actual = area_now if area_now is not None else area

        # Guardamos acción anterior para detectar oscilaciones
        prev_name = self.ant_name if self.ant_name is not None else name

        # ========================
        # 1. ÉXITO / COLISIONES
        # ========================
        if success:
            r += 500.0
            return r

        if collided:
            if self.step_count < 50:
                r -= 10.0
            elif self.step_count < 100:
                r -= 7.0
            elif self.step_count < 200:
                r -= 5.0
            else:
                r -= 3.0
            return r

        # ========================
        # 2. PERDER EL OBJETIVO
        # ========================
        if found_prev and not found_now:
            AREA_MAX = 8000.0
            if area_prev is None:
                area_prev = 0.0
            area_norm = min(area_prev / AREA_MAX, 1.0)
            base_penalty = 0.5
            extra_penalty = 4.0 * area_norm
            r -= (base_penalty + extra_penalty)

        # ========================
        # 3. CONTADORES GIROS / RECTAS
        # ========================
        GIROS_TODOS = ("left", "right", "left_soft", "right_soft")

        if self.ant_name is None:
            self.ant_name = name

        # cont_gir: cuántas veces llevo la MISMA acción de giro
        if name in GIROS_TODOS and prev_name == name:
            self.cont_gir += 1

        # cont_giros: cuántas acciones de giro seguidas (aunque cambie de lado)
        if name in GIROS_TODOS and prev_name in GIROS_TODOS:
            self.cont_giros += 1

        # Cambio de acción => reseteo de conteo fino
        if name != prev_name:
            self.cont_gir = 0

        # Avanzar resetea giros acumulados
        if name in ("forward", "slow"):
            self.cont_gir = 0
            #self.cont_Rec += 1
            self.cont_giros = 0
        if name in ("forward", "slow") and self.ant_name in ("forward", "slow"):
            self.cont_Rec += 1
        else:
            self.cont_Rec =0

        # Penalizar explícitamente la oscilación izquierda↔derecha
        if name in ("left", "left_soft") and prev_name in ("right", "right_soft"):
            r -= 0.3
        if name in ("right", "right_soft") and prev_name in ("left", "left_soft"):
            r -= 0.3

        # Actualizamos ant_name al final
        self.ant_name = name

        # ========================
        # 4. CUANDO SÍ VE EL OBJETIVO
        # ========================
        if found_now and not success:
            # Ver el objetivo ya es bueno
            r += 0.5

            # Bonus suave por área
            #if 200 < area_actual < 5000:
               # r += 0.5
            #elif 5000 <= area_actual < 8000:
               # r += 1.0
            if area_actual >= 8000:
                r += 1.5

            # Mejora de centrado (bearing)
            if bearing_prev is not None and bearing_now is not None:
                delta_b = abs(bearing_prev) - abs(bearing_now)
                r += np.clip(delta_b * 1.2, -0.3, 0.3) * 4.0

            # Mejora de área (acercarse)
            if area_prev is not None and area_prev > 0:
                delta_a = (area_actual - area_prev) / float(max(area_prev, 1))
                r += np.clip(delta_a * 0.6, -0.4, 0.6) * 4.0

            # Recto cuando está centrado
            if bearing_now is not None and name in ("forward", "slow") and abs(bearing_now) < 0.2:
                r += 3.0 if name == "forward" else 1.5

            # Giros correctivos cuando el objetivo es grande y descentrado
            if (
                bearing_now is not None
                and area_actual > 8000
                and name in GIROS_TODOS
                and abs(bearing_now) > 0.15
            ):
                # objetivo a la derecha + giro a la derecha
                if bearing_now > 0 and w > 0 and name in ("right", "right_soft"):
                    r += 4.0
                # objetivo a la izquierda + giro a la izquierda
                elif bearing_now < 0 and w < 0 and name in ("left", "left_soft"):
                    r += 4.0
                else:
                    # gira mal
                    r -= 4.0

        # ========================
        # 5. CUANDO NO VE EL OBJETIVO
        # ========================
        if not found_now:
            # castigo extra por seguir sin ver nada
            r -= 0.01  # neto base ≈ -0.02

            # Avanzar es claramente mejor que girar
            if name in ("forward", "slow") and self.cont_Rec < 40:
                r += 0.05        # neto ≈ +0.03
                if front_next is not None and front_next > 20.0 and izq < 8.0 and der < 8.0:
                    r += 0.04
                elif front_next > 10.0 and izq < 8.0 and der < 8.0:
                    r += 0.01
                # Obstáculo cerca delante
                if front_next is not None and front_next < 8.0:
                    r -= 0.3
            else:
                r-=1.0

            if front_next < 10.0 and izq < 6.0 and name in ("right","right_soft") : r += 0.05
            else : r-=0.1

            if front_next < 10.0 and der < 6.0 and name in ("left","left_soft") : r += 0.05
            else : r-=0.1

            if der < izq > 10.0 and name in ("left","left_soft"):
                r+= 0.06
            if izq < der > 10.0 and name in ("right","right_soft"):
                r+= 0.06

            if der < 6.0 and name in ("right","right_soft"):
                r-=0.2
            
            if izq < 6.0 and name in ("left","left_soft"):
                r-=0.2
            # Giros sin objetivo: castigo suave, y más si se pasa
            if name in GIROS_TODOS:
                r += 0.02        # neto ≈ -0.03
                if self.cont_gir > 8:
                    r -= 0.1     # demasiadas veces el mismo giro
                if self.cont_giros > 4:
                    r -= 0.2     # demasiados giros consecutivos en general

            # Pararse es mala idea
            elif name == "stop":
                r -= 0.1

            

            # Lados despejados: micro-bonus (menos malo)
            if izq > 5.5:
                r += 0.005
            if der > 5.5:
                r += 0.005

            return r

        # Si ha llegado aquí: found_now=True y ya hemos aplicado términos de visión
        return r


    
    # ---------- Métodos Gym: reset, step, close ----------

    def reset(self):
        self.col_pub.publish(String(data="colision"))
        self.episodio += 1
        self.step_count = 0

        rospy.loginfo("== Episodio %d (agente %s) ==", self.episodio, self.agent_id)

        self.cont_gir = 0
        self.ant_name = None
        self.cont_Rec = 0
        self.cont_giros = 0
        self.prev_vision = (False, None, 0)

        if self.reset_srv is not None:
            try:
                self.reset_srv()
                rospy.loginfo("Reset del mundo solicitado (agente %s).", self.agent_id)
            except rospy.ServiceException as e:
                rospy.logwarn("Fallo reset mundo: %s", e)

        self._stop()
        rospy.sleep(ESPERA_INICIO)

        rate = rospy.Rate(HZ_CONTROL)
        for _ in range(int(HZ_CONTROL * 2)):
            state, mins, vision, front,izq,der = self._obtener_estado()
            if state is not None:
                self.prev_vision = vision
                return state
            rate.sleep()

        rospy.logwarn("No se obtuvo observación inicial (agente %s), devolviendo estado cero.", self.agent_id)
        return np.zeros(self.observation_space.shape, dtype=np.float32)

    def step(self, action,pasos_acumulados,modelo_actual,total_reward, numcol):
        name, v, w = ACCIONES[int(action)]
        self._publicar_twist(v, w)
        self.step_count += 1

        rospy.sleep(1.0 / HZ_CONTROL)

        state, mins_next, vision_now, front_next,izq,der = self._obtener_estado()
        if state is None:
            r = -0.1
            done = False
            info = {"no_observation": True, "agent_id": self.agent_id}
            return (np.zeros(self.observation_space.shape, dtype=np.float32), r, done, info)

        found2, bearing2, area2 = vision_now
        dist_col = np.array([front_next, izq, der], dtype=np.float32)
        #collided = self.colision(mins_next)
        collided = self.colision(dist_col)
        success = self.exito(found2, bearing2, area2)

        r = self.recompensa(action, self.prev_vision, vision_now, collided, success, front_next,izq,der,area2)
        #r = self.recompensa(action, self.prev_vision, vision_now, collided, success, front_next,mins_next)

        expert_idx = self.accion_experta(front_next, izq, der, vision_now)

        """if expert_idx is not None and int(action) != expert_idx:
            # penalización por desviarse del experto
            r -= LAMBDA_EXPERTO
        else :
            r += LAMBDA_EXPERTO"""

        done = False
        if collided:
            rospy.loginfo(f"Colisión en paso {self.step_count} (agente {self.agent_id}),modelo del proceso {r} pasos acumualdor {pasos_acumulados}, modelo actual {modelo_actual}, total_rewar {total_reward}, colisones {numcol+1}  .")
            self._stop()
            rospy.sleep(COOLDOWN_COLISION)
            done = True
        elif success:
            rospy.loginfo("¡Objetivo rojo alcanzado! Paso %d (agente %s).", self.step_count, self.agent_id)
            self._stop()
            rospy.sleep(0.7)
            done = True
        elif self.step_count >= PASOS_MAX_EPISODIO:
            rospy.loginfo("Paso máximo %d alcanzado (agente %s).", PASOS_MAX_EPISODIO, self.agent_id)
            self._stop()
            done = True

        if done:
            self.col_pub.publish(String(data="colision"))

        self.prev_vision = vision_now

        info = {
            "collided": collided,
            "success": success,
            "front_dist": front_next,
            "step": self.step_count,
            "agent_id": self.agent_id,
        }

        return state, r, done, info

    def close(self):
        self._stop()
        rospy.loginfo("Cerrando entorno RLRedTargetEnv (agente %s).", self.agent_id)


# ==========================
# Entorno multi-agente (no se usa en este ejemplo, pero se deja por si lo necesitas)
# ==========================

#class MultiAgentRLRedTargetEnv(gym.Env):
    """
    Env Gym que agrupa varios RLRedTargetEnv (uno por robot).
    Cada reset() pasa al siguiente robot en round-robin, de forma que
    el DQN ve episodios de todos los agentes, pero con una única política compartida.
    """



class RobotMazeEnvPPO(RLRedTargetEnv):
    """
    Versión simplificada del entorno, pensada para PPO:
    - step(self, action) estándar de Gym.
    - Recompensa más simple basada en LiDAR + éxito.
    """

    def __init__(self, agent_id="0"):
        super().__init__(agent_id=agent_id)
        self.max_steps = 700  # pasos máximos por episodio (ajusta a tu gusto)

    def reset(self):
        # reutilizamos el reset original, pero reiniciamos el contador
        self.step_count = 0
        return super().reset()
    
    def recompensa_maze3(self, a_idx, mins, front, izq, der,
                    collided, success, found, bearing, area):

        # coste por paso un poco mayor para empujar a terminar
        r = -0.03

        if success:
            r += 100.0
            return r

        if collided:
            r -= 10.0
            return r

        name, v, w = ACCIONES[a_idx]

        FRONT_CLEAR  = 10.0
        FRONT_DANGER = 7.0
        BACK_DANGER  = 5.5

        # ==========================
        # SEGURIDAD / LABERINTO (siempre activa)
        # ==========================
        # evita girar hacia pared
        if izq < COLLISION_DIST + 1.0 and name in ("left", "left_soft"):
            r -= 0.2
        if der < COLLISION_DIST + 1.0 and name in ("right", "right_soft"):
            r -= 0.2

        # penaliza avanzar cuando está muy cerca
        if front < FRONT_DANGER and name in ("forward", "slow"):
            r -= 0.4

        # pequeño premio por avanzar cuando realmente hay espacio
        if front > FRONT_CLEAR and name in ("forward", "slow"):
            r += 0.08 if name == "forward" else 0.04

        # si se empieza a cerrar, girar hacia el lado más libre
        if front < FRONT_CLEAR:
            if izq - der > 1.0 and name in ("left", "left_soft"):
                r += 0.12
            if der - izq > 1.0 and name in ("right", "right_soft"):
                r += 0.12

        # back como maniobra de escape, no como fuente principal de reward
        going_back = (name == "back")
        trapped = front < BACK_DANGER and izq < BACK_DANGER and der < BACK_DANGER

        if going_back and (front < BACK_DANGER or trapped):
            r += 0.08
        elif going_back:
            r -= 0.15

        # ==========================
        # VISIÓN (progreso real)
        # ==========================
        prev = getattr(self, "prev_vision", None)

        # bonus muy pequeño por estar viendo el objetivo
        if found:
            r += 0.05

        # penaliza perderlo si lo tenías
        if prev is not None:
            prev_found, prev_bearing, prev_area = prev
            if prev_found and not found:
                r -= 0.3

        if found and bearing is not None:
            centered = abs(bearing) < CENTER_THRESH

            # premiar mejorar el centrado respecto al paso anterior
            if prev is not None:
                prev_found, prev_bearing, prev_area = prev
                if prev_found and prev_bearing is not None:
                    # mejora si |bearing| baja
                    delta_center = abs(prev_bearing) - abs(bearing)
                    r += 0.15 * max(0.0, delta_center)

            # acción coherente con centrar
            if not centered:
                if bearing > 0.0 and name in ("right", "right_soft"):
                    r += 0.10
                if bearing < 0.0 and name in ("left", "left_soft"):
                    r += 0.10
            else:
                if name in ("forward", "slow"):
                    r += 0.12
                if name in ("left", "left_soft", "right", "right_soft"):
                    r -= 0.05

            # premiar acercarse por cambio de área (potencial)
            if prev is not None:
                prev_found, prev_bearing, prev_area = prev
                if prev_found and area is not None and prev_area is not None:
                    delta_area = area - prev_area
                    # escala suave para no explotar
                    r += 0.0001 * max(0.0, delta_area)

        # guarda visión previa
        self.prev_vision = (found, bearing, area)

        return r

    def recompensa_maze(self, a_idx, mins, front, izq, der,
                    collided, success, found, bearing, area):
        """
        Recompensa pensada para:
        - Avanzar cuando el pasillo está libre (LiDAR).
        - Si delante se cierra, girar hacia el lado más despejado (LiDAR).
        - Penalizar colisión y pasar demasiado tiempo.
        - BONUS: si ve el objetivo y gira para centrarlo.
        - BONUS: si está centrado y avanza recto hacia él.
        """
        r = -0.01  # pequeño coste por paso

        # 1) Caso éxito (ha encontrado el objetivo rojo bien centrado y grande)
        if success:
            r += 30.0   # subo un poco el premio para que sea más dominante
            return r

        # 2) Colisión
        if collided:
            r -= 8.0    # un poco más duro
            return r

        name, v, w = ACCIONES[a_idx]

        # ===========================
        #   SHAPING DE LABERINTO (LiDAR)
        # ===========================
        FRONT_CLEAR = 10.0   # "pasillo claro"
        FRONT_DANGER = 7.0   # "se empieza a cerrar"
        BACK_DANGER  = 5.5
        if not found:

            # 3) Si delante está muy despejado, avanzar es bueno
            if front > FRONT_CLEAR and name in ("forward", "slow"):
                r += 0.3 if name == "forward" else 0.15

            # 4) Si delante está peligroso, avanzar es mala idea
            if front < FRONT_DANGER and name in ("forward", "slow"):
                r -= 0.6

            # 5) Si delante ya no está claro, queremos girar hacia el lado más abierto
            if front < FRONT_CLEAR:
                if izq - der > 1.0 and name in ("left", "left_soft"):
                    r += 0.4
                if der - izq > 1.0 and name in ("right", "right_soft"):
                    r += 0.4

            # 6) Evitar girar hacia la pared
            if izq < COLLISION_DIST + 1.0 and name in ("left", "left_soft"):
                r -= 0.3
            if der < COLLISION_DIST + 1.0 and name in ("right", "right_soft"):
                r -= 0.3

            # ===========================
            #   NUEVA ACCIÓN: "back"
            # ===========================
            going_back = (name == "back")

            # a) Si estoy muy cerca por delante, recular es bueno
            if going_back and front < BACK_DANGER:
                r += 0.4  # maniobra de escape

            # b) Si estoy encajonado (pared delante y a ambos lados), recular también es bueno
            trapped = front < BACK_DANGER and izq < BACK_DANGER and der < BACK_DANGER
            if going_back and trapped:
                r += 0.3

            # c) Si delante está despejado, recular es mala idea
            if going_back and front > FRONT_CLEAR:
                r -= 0.7  # que no haga el laberinto marcha atrá

        # ===========================
        #   SHAPING CON VISIÓN (OBJETIVO ROJO)
        # ===========================
        # Solo si hay objetivo detectado y bearing no es None
        if found and bearing is not None:
            # mismo umbral que usas en exito()
            centered = abs(bearing) < CENTER_THRESH

            # 7) Si NO está centrado, premiar girar hacia él
            if not centered:
                # bearing > 0  -> objetivo a la derecha
                if bearing > 0.0 and name in ("right", "right_soft"):
                    r += 0.4  # gira en la dirección correcta para centrar
                # bearing < 0 -> objetivo a la izquierda
                if bearing < 0.0 and name in ("left", "left_soft"):
                    r += 0.4

                # Si gira al lado contrario, pequeña penalización
                if bearing > 0.0 and name in ("left", "left_soft"):
                    r -= 0.2
                if bearing < 0.0 and name in ("right", "right_soft"):
                    r -= 0.2

            # 8) Si ya está aproximadamente centrado, premiar ir recto
            else:
                if name in ("forward", "slow"):
                    r += 0.5  # empuja a avanzar hacia el objetivo
                # si estando centrado se pone a girar, lo desincentivamos
                if name in ("left", "left_soft", "right", "right_soft"):
                    r -= 0.2

            # 9) (Opcional) premiar acercarse (aumenta el área respecto al paso anterior)
            if getattr(self, "prev_vision", None) is not None:
                prev_found, prev_bearing, prev_area = self.prev_vision
                if prev_found and area is not None and prev_area is not None:
                    if area > prev_area + 500:  # se ve claramente más grande
                        r += 0.2

        return r


    def recompensa_maze2(self, a_idx, mins, front, izq, der, collided, success):
        """
        Recompensa pensada para:
        - Avanzar cuando el pasillo está libre.
        - Si delante se cierra, girar hacia el lado más despejado.
        - Penalizar colisión y pasar demasiado tiempo.
        """
        r = -0.01  # pequeño coste por paso (para que no vaguee)

        # 1) Caso éxito (ha encontrado el objetivo rojo)
        if success:
            r += 10.0
            return r

        # 2) Colisión
        if collided:
            r -= 5.0
            return r

        name, v, w = ACCIONES[a_idx]

        # Umbrales (ajústalos si ves que el robot se comporta raro)
        FRONT_CLEAR = 15.0   # "pasillo claro"
        FRONT_DANGER = 8.0   # "se empieza a cerrar"

        # 3) Si delante está muy despejado, avanzar es bueno
        if front > FRONT_CLEAR and name in ("forward", "slow"):
            r += 0.3 if name == "forward" else 0.15

        # 4) Si delante está peligroso, avanzar es mala idea
        if front < FRONT_DANGER and name in ("forward", "slow"):
            r -= 0.6

        # 5) Si delante ya no está claro, queremos girar hacia el lado más abierto
        if front < FRONT_CLEAR:
            if izq - der > 1.0 and name in ("left", "left_soft"):
                r += 0.4
            if der - izq > 1.0 and name in ("right", "right_soft"):
                r += 0.4

        # 6) Evitar girar hacia la pared
        if izq < COLLISION_DIST + 1.0 and name in ("left", "left_soft"):
            r -= 0.3
        if der < COLLISION_DIST + 1.0 and name in ("right", "right_soft"):
            r -= 0.3

        return r

    def step(self, action):
        # 1) Ejecutar acción en el robot
        name, v, w = ACCIONES[int(action)]
        self._publicar_twist(v, w)
        self.step_count += 1

        rospy.sleep(1.0 / HZ_CONTROL)

        # 2) Leer estado desde LiDAR + cámara
        state, mins_next, vision_now, front_next, izq, der = self._obtener_estado()
        if state is None:
            # Si por lo que sea no hay observación
            r = -0.1
            done = False
            info = {"no_observation": True, "agent_id": self.agent_id}
            return (
                np.zeros(self.observation_space.shape, dtype=np.float32),
                r,
                done,
                info,
            )

        found, bearing, area = vision_now

        # 3) Colisión / éxito
        #print(self.agent_id, mins_next)
        collided = self.colision(front_next)           # usa todo el LiDAR
        success = self.exito(found, bearing, area,front_next)    # como ya tenías

        # 4) Recompensa de laberinto
        r = self.recompensa_maze(
            int(action),
            mins_next,
            front_next,
            izq,
            der,
            collided,
            success,
            found,bearing,area
        )
        if success: print(self.agent_id,"Objetivoooooooooooooo")

        # 5) Condiciones de final de episodio
        done = False
        if collided or success or self.step_count >= self.max_steps:
            done = True
            self._stop()

        if done:
            # IMPORTANTE: esto es lo que dispara tu reset externo
            self.col_pub.publish(String(data="colision"))
            self._stop()
            rospy.loginfo(
                "Fin de episodio PPO (agente %s), step=%d",
                self.agent_id,
                self.step_count,
            )

        # Guardamos visión actual como "previa" para el siguiente paso, si quieres usarla luego
        self.prev_vision = vision_now

        info = {
            "collided": collided,
            "success": success,
            "front_dist": front_next,
            "step": self.step_count,
            "agent_id": self.agent_id,
        }

        return state, r, done, info



""" metadata = {'render.modes': []}

    def __init__(self, agent_ids):
        super(MultiAgentRLRedTargetEnv, self).__init__()

        self.envs = [RLRedTargetEnv(agent_id=aid) for aid in agent_ids]
        self.n_envs = len(self.envs)
        self.current_idx = -1   # se incrementa en reset()

        # Asumimos que todos tienen mismos espacios
        self.action_space = self.envs[0].action_space
        self.observation_space = self.envs[0].observation_space

    def reset(self):
        # Cambiamos de robot en cada nuevo episodio
        self.current_idx = (self.current_idx + 1) % self.n_envs
        rospy.loginfo("=== Reset Multi-Agent: usando robot con agent_id=%s ===",
                      self.envs[self.current_idx].agent_id)
        return self.envs[self.current_idx].reset()

    def step(self, action):
        # Delegar en el env del robot activo
        return self.envs[self.current_idx].step(action)

    def close(self):
        for e in self.envs:
            e.close()
        rospy.loginfo("Cerrando MultiAgentRLRedTargetEnv con %d robots.", self.n_envs)
"""

# ==========================
# Construcción del modelo DQN
# ==========================

def build_model(state_shape, nb_actions):
    model = Sequential()
    model.add(Flatten(input_shape=(1,) + state_shape))
    model.add(Dense(256, activation="relu"))
    model.add(Dense(128, activation="relu"))
    model.add(Dense(128, activation="relu"))
    model.add(Dense(nb_actions, activation="linear"))
    return model


def run_robot_episode_process(agent_id, base_weights, max_steps,
                              train_episode_idx, results_queue):
    """
    Proceso independiente que entrena un robot (agent_id) durante 'max_steps' pasos
    totales de interacción (sumando varios episodios del entorno si hace falta),
    partiendo de 'base_weights'. Devuelve por 'results_queue' el modelo final,
    la recompensa media por paso y estadísticas del episodio.
    """

    # Nodo ROS propio para este proceso
    node_name = f"rl_red_target_dqn_worker_{agent_id}_ep_{train_episode_idx}"
    try:
        rospy.init_node(node_name, anonymous=True)
    except rospy.ROSException:
        # Si el nodo ya estaba inicializado en este proceso, lo ignoramos
        pass

    # Semillas locales
    np.random.seed(int(time.time()) % (2 ** 32 - 1))
    tf.random.set_seed(int(time.time()) % (2 ** 32 - 1))

    # Entorno propio de este proceso/robot
    env = RLRedTargetEnv(agent_id=str(agent_id))

    nb_actions = env.action_space.n
    state_shape = env.observation_space.shape

    # Modelo + DQN local
    model = build_model(state_shape, nb_actions)
    if base_weights is not None:
        try:
            model.set_weights(base_weights)
        except Exception as e:
            rospy.logwarn("No se pudieron cargar los pesos base para el agente %s: %s",
                          agent_id, e)

    memory = SequentialMemory(limit=100000, window_length=1)
    policy = LinearAnnealedPolicy(
        EpsGreedyQPolicy(),
        attr="eps",
        value_max=0.20,
        value_min=0.05,
        value_test=0.01,
        nb_steps=1,
    )

    dqn_local = DQNAgent(
        model=model,
        nb_actions=nb_actions,
        memory=memory,
        nb_steps_warmup=0,#0
        target_model_update=1e-2,
        policy=policy,
        gamma=GAMMA,
        train_interval=4,
        batch_size=64,
    )
    dqn_local.compile(Adam(learning_rate=5e-4), metrics=["mae"])

    dqn_local.training = True
    dqn_local.step = 0
    dqn_local.reset_states()

    # ==== acumuladores de pasos / recompensas ====
    total_reward = 0.0           # recompensa total en este episodio de entrenamiento
    total_steps = 0              # pasos totales en este episodio de entrenamiento (global)
    steps_since_collision = 0    # contador que se reinicia a 0 en cada colisión
    num_collisions = 0           # nº de colisiones en este episodio de entrenamiento
    num_env_episodes = 0         # cuántos episodios del entorno se han jugado
    last_info = {}

    # Bucle de "episodio de entrenamiento": seguimos hasta max_steps
    while total_steps < max_steps and not rospy.is_shutdown():
        obs = env.reset()
        dqn_local.reset_states()
        done = False
        num_env_episodes += 1

        while (not done) and (total_steps < max_steps) and (not rospy.is_shutdown()):
            action = dqn_local.forward(obs)
            next_obs, reward, done, info = env.step(action)

            total_reward += reward
            total_steps += 1
            steps_since_collision += 1   # contador local

            dqn_local.backward(reward, terminal=done)

            obs = next_obs
            last_info = info

            # Si colisiona, reseteamos el contador local pero NO el total
            if info.get("collided", False):
                num_collisions += 1
                steps_since_collision = 0

        rospy.loginfo(
            "Proceso robot %s, ep_entrenamiento %d: fin de episodio de entorno #%d, pasos_totales=%d",
            agent_id, train_episode_idx, num_env_episodes, total_steps
        )

    mean_reward_per_step = total_reward / max(1, num_collisions)

    # Registro resumido de este episodio de entrenamiento
    episode_record = {
        "train_episode": train_episode_idx,
        "robot_id": str(agent_id),
        "total_steps": total_steps,
        "total_reward": total_reward,
        "mean_reward": mean_reward_per_step,
        "collisions": num_collisions,
        "env_episodes": num_env_episodes,
        "last_success": int(last_info.get("success", False)),
        "last_collided": int(last_info.get("collided", False)),
        "last_env_step": last_info.get("step", 0),
        "final_streak_steps": steps_since_collision,  # pasos desde la última colisión
    }

    final_weights = dqn_local.model.get_weights()

    env.close()

    # Enviamos resultado al proceso padre
    results_queue.put({
        "agent_id": str(agent_id),
        "mean_reward": mean_reward_per_step,
        "weights": final_weights,
        "episode_record": episode_record,
        "steps_run": total_steps,
    })

def robot_worker(agent_id, cmd_queue, result_queue, initial_weights):
    """
    Proceso que vive TODO el entrenamiento.
    - Crea su propio entorno RLRedTargetEnv y su propio DQN una sola vez.
    - Espera órdenes en cmd_queue:
        * {"type": "train", "episode": k, "steps": N, "weights": ...}
        * {"type": "stop"}
    - Para cada orden "train" entrena N pasos (10000) SIN recrear el DQN.
    """

    # Nodo ROS para este proceso
    node_name = f"rl_red_target_dqn_worker_{agent_id}"
    try:
        rospy.init_node(node_name, anonymous=True)
    except rospy.ROSException:
        pass

    # Semillas locales
    np.random.seed(int(time.time()) % (2 ** 32 - 1))
    tf.random.set_seed(int(time.time()) % (2 ** 32 - 1))

    # Entorno propio
    env = RLRedTargetEnv(agent_id=str(agent_id))
    nb_actions = env.action_space.n
    state_shape = env.observation_space.shape

    # --- DQN LOCAL (se crea UNA sola vez) ---
    model = build_model(state_shape, nb_actions)
    if initial_weights is not None:
        model.set_weights(initial_weights)

    memory = SequentialMemory(limit=50000, window_length=1)
    policy = LinearAnnealedPolicy(
        EpsGreedyQPolicy(),
        attr="eps",
        value_max=0.5,
        value_min=0.05,
        value_test=0.01,
        nb_steps=1,
    )

    dqn_local = DQNAgent(
        model=model,
        nb_actions=nb_actions,
        memory=memory,
        nb_steps_warmup=0,#0
        target_model_update=1e-2,
        policy=policy,
        gamma=GAMMA,
        train_interval=4,
        batch_size=16,
    )
    dqn_local.compile(Adam(learning_rate=5e-4), metrics=["mae"])

    dqn_local.training = True
    # ⚠️ IMPORTANTE: NO reiniciamos dqn_local.step entre episodios
    dqn_local.reset_states()  # solo resetea estados internos (RNN) si los hubiera

    while not rospy.is_shutdown():
        cmd = cmd_queue.get()  # bloqueante

        if cmd["type"] == "stop":
            break

        if cmd["type"] != "train":
            continue

        train_episode_idx = cmd["episode"]
        max_steps = cmd["steps"]

        new_weights = cmd.get("weights", None)
        new_weights_path = cmd.get("weights_path", None)

        # Si el padre nos manda una ruta a .h5, cargamos desde ahí
        if new_weights_path is not None:
            try:
                dqn_local.load_weights(new_weights_path)
                rospy.loginfo(
                    "[worker %s] Cargados pesos desde %s para ep %d",
                    agent_id, new_weights_path, train_episode_idx
                )
            except Exception as e:
                rospy.logwarn(
                    "[worker %s] Error al cargar pesos desde %s: %s",
                    agent_id, new_weights_path, e
                )

        # Si no hay ruta pero sí pesos en memoria, usamos los pesos como antes
        elif new_weights is not None:
            try:
                dqn_local.model.set_weights(new_weights)
                rospy.loginfo(
                    "[worker %s] Cargados pesos globales en memoria para ep %d",
                    agent_id, train_episode_idx
                )
            except Exception as e:
                rospy.logwarn(
                    "[worker %s] Error al cargar pesos en memoria: %s",
                    agent_id, e
                )
        # ======= EPISODIO DE ENTRENAMIENTO: max_steps pasos =========
        total_reward = 0.0
        total_steps = 1
        steps_since_collision = 0
        num_collisions = 0
        num_env_episodes = 0
        last_info = {}
        best_mean_reward = None          # mejor media de recompensa/step vista en este episodio
        no_improve_checks = 0

        early_stop = False   # <-- antes del while grande

        while total_steps < max_steps and not rospy.is_shutdown():
            obs = env.reset()
            dqn_local.reset_states()   # reset de estado interno, NO de memory/policy
            done = False
            num_env_episodes += 1

            while not done and total_steps < max_steps and not rospy.is_shutdown():
                action = dqn_local.forward(obs)
                
                next_obs, reward, done, info = env.step(action,total_steps,total_reward/max(1, num_collisions),total_reward,num_collisions)
                

                total_reward += reward
                total_steps += 1
                steps_since_collision += 1

                dqn_local.backward(reward, terminal=done)

                obs = next_obs
                last_info = info

                if info.get("collided", False):
                    num_collisions += 1
                    steps_since_collision = 0   # contador local se resetea
                        # === EARLY STOPPING ===
                if total_steps > 0 and (total_steps % EARLY_STOP_CHECK_EVERY == 0):
                    current_mean = total_reward / float(max(1, num_collisions))

                    if (best_mean_reward is None) or (current_mean > best_mean_reward + EARLY_STOP_MIN_DELTA):
                        best_mean_reward = current_mean
                        no_improve_checks = 0
                    else:
                        no_improve_checks += 1
                        if no_improve_checks >= EARLY_STOP_PATIENCE:
                            early_stop = True     # <--- MARCAMOS FLAG
                            done = True
                            rospy.loginfo(
                                "[EP %d][Robot %s] EARLY STOPPING en paso %d (media=%.4f, mejor=%.4f)",
                                train_episode_idx, agent_id, total_steps, current_mean, best_mean_reward
                            )
                            break   # sale del while interior

            # si se activó early stopping, salimos también del while exterior
            if early_stop:
                break

                

        mean_reward_per_step = total_reward / max(1, num_collisions)

        episode_record = {
            "train_episode": train_episode_idx,
            "robot_id": str(agent_id),
            "total_steps": total_steps,
            "total_reward": total_reward,
            "mean_reward": mean_reward_per_step,
            "collisions": num_collisions,
            "env_episodes": num_env_episodes,
            "last_success": int(last_info.get("success", False)),
            "last_collided": int(last_info.get("collided", False)),
            "last_env_step": last_info.get("step", 0),
            "final_streak_steps": steps_since_collision,
        }

        # === Guardar pesos de este worker en un .h5 propio ===
        weights_path = os.path.join(
            os.getcwd(),
            f"dqn_worker{agent_id}_ep{train_episode_idx}.h5"
        )
        dqn_local.save_weights(weights_path, overwrite=True)
        rospy.loginfo(
            "Worker %s: pesos del episodio %d guardados en %s",
            agent_id, train_episode_idx, weights_path
        )

        # Enviamos resultado al proceso padre (ruta del .h5 en vez de los pesos)
        result_queue.put({
            "agent_id": str(agent_id),
            "mean_reward": mean_reward_per_step,
            "weights_path": weights_path,
            "episode_record": episode_record,
            "steps_run": total_steps,
        })

        env.close()
        rospy.loginfo("Worker %s: terminado.", agent_id)

# ==========================
# Main
# ==========================
if __name__ == "__main__":
    try:
        mp.set_start_method("spawn", force=True)
    except RuntimeError:
        pass

    rospy.init_node("rl_red_target_dqn_multi_agent_training", anonymous=False)

    # Semillas globales
    np.random.seed(int(time.time()) % (2 ** 32 - 1))
    tf.random.set_seed(int(time.time()) % (2 ** 32 - 1))

    # Entorno "dummy" solo para obtener shape de observaciones y nº de acciones
    dummy_env = RLRedTargetEnv(agent_id="0")
    nb_actions = dummy_env.action_space.n
    state_shape = dummy_env.observation_space.shape
    dummy_env.close()

    # Modelo base inicial (solo para pesos iniciales)
    model = build_model(state_shape, nb_actions)
    dqn_dummy = DQNAgent(
        model=model,
        nb_actions=nb_actions,
        memory=SequentialMemory(limit=10, window_length=1),
        nb_steps_warmup=1,
        target_model_update=1e-2,
        policy=EpsGreedyQPolicy(),
    )
    dqn_dummy.compile(Adam(learning_rate=5e-4), metrics=["mae"])
    base_weights = dqn_dummy.model.get_weights()

    # ==== colas y procesos para cada robot ====
    AGENT_IDS = ["0","1","2","3","4","5","6","7"]  # o los que quieras
    cmd_queues = {}
    result_queue = mp.Queue()
    processes = []

    for aid in AGENT_IDS:
        q = mp.Queue()
        cmd_queues[aid] = q
        p = mp.Process(
            target=robot_worker,
            args=(aid, q, result_queue, base_weights)
        )
        p.start()
        processes.append(p)

    # Mejor modelo GLOBAL
    global_best_mean = None
    global_best_weights = base_weights
    global_best_path = None
    no_improve_episodes = 0

    # Contador global de pasos por robot
    global_steps_per_robot = {aid: 0 for aid in AGENT_IDS}

    # CSV
    results_path = os.path.join(os.getcwd(), "training_results.csv")
    with open(results_path, mode="w", newline="") as f_csv:
        writer = csv.writer(f_csv)
        writer.writerow([
            "train_episode",
            "robot_id",
            "steps_in_episode",
            "global_steps_robot",
            "total_reward_episode",
            "mean_reward_per_step",
            "collisions",
            "env_episodes",
            "last_success",
            "last_collided",
            "last_env_step",
            "final_streak_steps",
        ])

        for train_ep in range(1, MAX_EPISODIOS + 1):
            if rospy.is_shutdown():
                break

            rospy.loginfo("===== EPISODIO DE ENTRENAMIENTO %d/%d =====",
                          train_ep, MAX_EPISODIOS)

            # Mandamos orden de entrenar 10000 pasos a cada robot
            for aid in AGENT_IDS:
                cmd_queues[aid].put({
                    "type": "train",
                    "episode": train_ep,
                    "steps": PASOS_EPISODIO,       # 10000
                    "weights": global_best_weights # todos parten del mejor modelo global
                })

            # Recogemos resultados
            robot_results = []
            for _ in AGENT_IDS:
                res = result_queue.get()
                robot_results.append(res)

            # Elegimos mejor modelo del episodio
            best_ep_mean = None
            best_ep_path = None

            for res in robot_results:
                aid = res["agent_id"]
                steps_run = res["steps_run"]
                rec = res["episode_record"]

                global_steps_per_robot[aid] += steps_run

                writer.writerow([
                    rec["train_episode"],
                    rec["robot_id"],
                    rec["total_steps"],
                    global_steps_per_robot[aid],
                    rec["total_reward"],
                    rec["mean_reward"],
                    rec["collisions"],
                    rec["env_episodes"],
                    rec["last_success"],
                    rec["last_collided"],
                    rec["last_env_step"],
                    rec["final_streak_steps"],
                ])

                mean_r = rec["mean_reward"]
                rospy.loginfo(
                    "[EP %d] Robot %s: media recompensa/paso=%.3f, pasos_ep=%d, colisiones=%d, pasos_globales=%d",
                    train_ep, aid, mean_r, rec["total_steps"],
                    rec["collisions"], global_steps_per_robot[aid]
                )

                # Ruta al .h5 de este worker en este episodio
                weights_path = res.get("weights_path", None)

                if (best_ep_mean is None) or (mean_r > best_ep_mean):
                    best_ep_mean = mean_r
                    best_ep_path = weights_path

            # --- Lógica de mejora global: SOLO si mejora, actualizamos ---
            if best_ep_path is not None:
                if (global_best_mean is None) or (best_ep_mean > global_best_mean):
                    global_best_mean = best_ep_mean
                    global_best_path = best_ep_path

                    # Cargamos ese .h5 en el dummy para mantener global_best_weights actualizado
                    try:
                        dqn_dummy.load_weights(global_best_path)
                        global_best_weights = dqn_dummy.model.get_weights()
                    except Exception as e:
                        rospy.logwarn(
                            "Error al cargar pesos globales desde %s: %s",
                            global_best_path, e
                        )
                    no_improve_episodes = 0
                    rospy.loginfo(
                        "[EP %d] NUEVO MEJOR GLOBAL: media=%.3f (pesos en %s)",
                        train_ep, global_best_mean, global_best_path
                    )
                else:
                    no_improve_episodes+=1
                    rospy.loginfo(
                        "[EP %d] El mejor de este episodio (media=%.3f) NO mejora el global (media=%.3f). "
                        "Se mantiene el modelo global anterior (%s).",
                        train_ep, best_ep_mean, global_best_mean,
                        global_best_path if global_best_path is not None else "sin fichero"
                    )
                    # Early stopping global: 3 episodios seguidos sin mejora
                    if no_improve_episodes >= GLOBAL_EARLY_STOP_PATIENCE:
                        rospy.loginfo(
                            "EARLY STOPPING GLOBAL: %d episodios seguidos sin mejora. "
                            "Se termina el entrenamiento.",
                            no_improve_episodes
                        )
                        # Rompemos el bucle de episodios de entrenamiento
                        break

            
    rospy.loginfo("Entrenamiento completo. Pasos finales por robot: %s",
                  str(global_steps_per_robot))

    # Paramos workers
    for aid in AGENT_IDS:
        cmd = {
            "type": "stop",
            "episode": train_ep,
            "steps": PASOS_EPISODIO,
        }

        # Si ya tenemos un .h5 global, lo mandamos como referencia
        if global_best_path is not None:
            cmd["weights_path"] = global_best_path
        else:
            # Primer episodio: todavía no hay fichero, usamos pesos en memoria
            cmd["weights"] = global_best_weights

        cmd_queues[aid].put(cmd)
    for p in processes:
        p.join()

    # Guardamos el mejor modelo global
    dqn_dummy.model.set_weights(global_best_weights)
    weights_path = os.path.join(os.getcwd(), "dqn_red_target_multi_agent_best_weights.h5")
    dqn_dummy.save_weights(weights_path, overwrite=True)
    rospy.loginfo(
        "Pesos DQN (multi-agente, mejor modelo global con media %.3f) guardados en %s",
        global_best_mean if global_best_mean is not None else float("nan"),
        weights_path
    )
