#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Control reactivo para robot móvil usando ROS.

- SIN aprendizaje por refuerzo.
- El movimiento se decide únicamente a partir del LiDAR
  (estrategia de seguir pared izquierda para resolver laberintos).
- La cámara se usa solo para detectar un objetivo rojo.
  Si el objetivo rojo aparece grande y centrado, el robot se detiene.

Parámetros ROS útiles (~param):
  - ~agent_id (str): sufijo de los topics (por defecto "0")
  - ~hz_control (float): frecuencia de control, por defecto 10 Hz
  - ~dist_ahead_clear (float): distancia "segura" de frente
  - ~dist_wall_far (float): distancia a partir de la que buscamos pared izquierda
  - ~dist_wall_close (float): distancia a partir de la que nos separamos de la pared
"""

import rospy
import numpy as np
import math
import cv2
import multiprocessing as mp

from geometry_msgs.msg import Twist, Point
from sensor_msgs.msg import LaserScan, CompressedImage
from std_msgs.msg import String

# ==========================
# Tópicos ROS (prefijo; luego se añade agent_id)
# ==========================
LIDAR_TOPIC = "/lidar"
CAM_TOPIC   = "/camara_robot"   # sensor_msgs/CompressedImage
CMD_TOPIC   = "/cmd_vel"
COLISION_TOPIC = "/aviso_colision"
RED_TOPIC   = "/aviso_rojo"
POS_TOPIC   = "/posiconrobot"

# ==========================
# LiDAR (configuración básica)
# ==========================
NUM_SECTORES   = 180
CLIP_DIST      = 30.0
COLLISION_DIST = 5.0   # a menos de esto consideramos colisión

# ==========================
# Cámara / visión del objetivo rojo
# ==========================
IMG_RESIZE_W = 320
AREA_MIN     = 100    # área mínima para considerar objeto rojo
AREA_GOAL    = 50000   # área a partir de la cual consideramos "muy cerca"
CENTER_THRESH = 0.17   # |bearing_norm| < CENTER_THRESH => centrado

# Rango de rojo en HSV (dos bandas)
LOW1  = (0,   90,  80)
HIGH1 = (10,  255, 255)
LOW2  = (170, 90,  80)
HIGH2 = (180, 255, 255)


# ==========================
# Funciones auxiliares LiDAR / visión
# ==========================

def min_range_at_angle(scan_msg, angle_rad, window_deg=8.0, fallback=np.inf):
    """
    Devuelve la distancia mínima en torno a un ángulo concreto (en radianes),
    promediando dentro de una ventana de 'window_deg' grados.
    """
    ranges = np.asarray(scan_msg.ranges, dtype=np.float32)
    n = ranges.size
    if n == 0:
        return fallback

    angle_min = scan_msg.angle_min
    inc = scan_msg.angle_increment

    rng_max = scan_msg.range_max
    if not np.isfinite(rng_max) or rng_max <= 0:
        rng_max = CLIP_DIST

    # Índice central correspondiente al ángulo que pedimos
    idx_center = int(round((angle_rad - angle_min) / inc))

    # Ancho de la ventana en índices
    half_w = max(1, int(round(np.deg2rad(window_deg) / abs(inc))))

    i0 = max(0, idx_center - half_w)
    i1 = min(n, idx_center + half_w + 1)

    seg = ranges[i0:i1]
    seg = seg[np.isfinite(seg)]
    if seg.size == 0:
        return fallback

    val = float(np.clip(np.min(seg), 0.0, rng_max))
    return val


def sectoriza(scan_msg, num_sectores):
    """
    Divide el LiDAR en 'num_sectores' sectores alrededor del robot,
    y devuelve la distancia mínima en cada sector.
    """
    ranges = np.array(scan_msg.ranges, dtype=np.float32)
    ranges[~np.isfinite(ranges)] = CLIP_DIST

    angle_min = scan_msg.angle_min
    angle_inc = scan_msg.angle_increment
    n = ranges.shape[0]

    # Rotamos para que 0 rad quede en el centro
    zero_idx = int(round((0.0 - angle_min) / angle_inc))
    zero_idx = np.clip(zero_idx, 0, n - 1)
    rotated = np.roll(ranges, -(zero_idx - n // 2))

    step = max(1, n // num_sectores)
    mins = []
    for i in range(num_sectores):
        start = i * step
        end   = (i + 1) * step
        if end <= n:
            seg = rotated[start:end]
        else:
            seg = rotated[start:]
        if seg.size == 0:
            mins.append(CLIP_DIST)
        else:
            mins.append(float(np.clip(np.min(seg), 0.0, CLIP_DIST)))

    return np.array(mins, dtype=np.float32)


def extrae_objetivo_rojo(cv_bgr, agent_id="8"):
    """
    Detecta el mayor blob rojo en la imagen BGR.

    Devuelve:
      found (bool)
      bearing_norm (float en [-1,1], 0 centrado) o None
      area (int)
      bbox (x, y, w, h) o None
    """
    if cv_bgr is None:
        return False, None, 0, None

    h, w = cv_bgr.shape[:2]
    scale = float(IMG_RESIZE_W) / float(w)
    if w > IMG_RESIZE_W:
        cv_small = cv2.resize(cv_bgr, (IMG_RESIZE_W, int(h * scale)))
    else:
        cv_small = cv_bgr

    H, W = cv_small.shape[:2]

    hsv = cv2.cvtColor(cv_small, cv2.COLOR_BGR2HSV)
    mask1 = cv2.inRange(hsv, np.array(LOW1), np.array(HIGH1))
    mask2 = cv2.inRange(hsv, np.array(LOW2), np.array(HIGH2))
    mask = cv2.bitwise_or(mask1, mask2)

    kernel = np.ones((3, 3), np.uint8)
    mask  = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
    mask  = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return False, None, 0, None

    c = max(contours, key=cv2.contourArea)
    area = int(cv2.contourArea(c))
    rospy.logdebug("Agente %s - área roja: %d", agent_id, area)

    if area < AREA_MIN:
        return False, None, area, None

    x, y, wc, hc = cv2.boundingRect(c)
    cx = x + wc / 2.0
    bearing_norm = (cx - (W / 2.0)) / (W / 2.0)  # -1 izq, 0 centro, +1 der

    return True, float(bearing_norm), int(area), (x, y, wc, hc)


# ==========================
# Controlador reactivo
# ==========================

class MazeLidarRedController(object):
    def __init__(self, patat):
        # Parámetros
        self.agent_id = rospy.get_param("~agent_id", patat)
        self.hz       = rospy.get_param("~hz_control", 10.0)

        # Parámetros de navegación (puedes ajustarlos con params)
        self.dist_ahead_clear = rospy.get_param("~dist_ahead_clear", 8.0)
        self.dist_wall_far    = rospy.get_param("~dist_wall_far",   8.0)
        self.dist_wall_close  = rospy.get_param("~dist_wall_close", 6.0)

        self.v_forward = rospy.get_param("~v_forward", 3.0)   # m/s
        self.v_slow    = rospy.get_param("~v_slow",    1.0)
        self.d_turn    = rospy.get_param("~w_turn",    1.0)
        self.d_soft    = rospy.get_param("~w_soft",    0.5)
        self.i_turn    = rospy.get_param("~w_turn",   -1.0)
        self.i_soft    = rospy.get_param("~w_soft",   -0.5)

        ### CAMBIO: ganancias para el control visual hacia el objetivo
        self.k_ang = rospy.get_param("~k_ang", 1.0)   # ganancia proporcional para girar hacia el rojo
        self.w_max = rospy.get_param("~w_max", 1.5)   # saturación de velocidad angular

        # Estado sensores
        self.last_scan = None
        self.scan_ok   = False

        self.last_bgr  = None
        self.image_ok  = False

        # Publishers / Subscribers
        self.cmd_pub = rospy.Publisher(
            CMD_TOPIC + self.agent_id, Twist, queue_size=1
        )
        self.col_pub = rospy.Publisher(
            COLISION_TOPIC + self.agent_id, String, queue_size=1
        )
        self.red_pub = rospy.Publisher(
            RED_TOPIC + self.agent_id, String, queue_size=1
        )

        self.scan_sub = rospy.Subscriber(
            LIDAR_TOPIC + self.agent_id, LaserScan, self.cb_lidar, queue_size=1
        )
        self.img_sub  = rospy.Subscriber(
            CAM_TOPIC + self.agent_id, CompressedImage, self.cb_img, queue_size=1
        )

        rospy.loginfo("MazeLidarRedController para agente %s", self.agent_id)
        rospy.loginfo("Topics LiDAR: %s  Cámara: %s  Cmd_vel: %s",
                      LIDAR_TOPIC + self.agent_id,
                      CAM_TOPIC + self.agent_id,
                      CMD_TOPIC + self.agent_id)

        # Timer de control
        self.timer = rospy.Timer(rospy.Duration(1.0 / self.hz),
                                 self.control_loop)

        rospy.on_shutdown(self._stop_robot)

    # ---------- Callbacks ROS ----------

    def cb_lidar(self, msg):
        self.last_scan = msg
        self.scan_ok   = True

    def cb_img(self, msg):
        np_arr = np.frombuffer(msg.data, np.uint8)
        bgr    = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        self.last_bgr = bgr
        self.image_ok = True

    # ---------- Utilidades ----------

    def _stop_robot(self):
        t = Twist()
        self.cmd_pub.publish(t)

    def _publicar_cmd(self, v, w):
        t = Twist()
        t.linear.x  = v
        t.angular.z = w
        self.cmd_pub.publish(t)

    # ---------- Lógica de decisión ----------

    def control_loop(self, event):
        if not self.scan_ok or self.last_scan is None:
            self._stop_robot()
            return

        # --- 1) Distancias LiDAR ---
        scan = self.last_scan
        front_dist = min_range_at_angle(scan, 0.0,
                                        window_deg=45.0,
                                        fallback=CLIP_DIST)
        left_dist  = min_range_at_angle(scan,  math.pi / 2.0,
                                        window_deg=30.0,
                                        fallback=CLIP_DIST)
        right_dist = min_range_at_angle(scan, -math.pi / 2.0,
                                        window_deg=30.0,
                                        fallback=CLIP_DIST)

        collided = front_dist < COLLISION_DIST

        # Valores por defecto: seguir pared
        v_cmd, w_cmd = self._decide_wall_follow(front_dist, left_dist, right_dist)

        # --- 2) Vision: objetivo rojo ---
                # --- 3) Procesado de cámara: detección de rojo y cambio a modo "ir al objetivo" ---
        if self.image_ok and self.last_bgr is not None and front_dist >= self.dist_wall_close:
            found, bearing, area, bbox = extrae_objetivo_rojo(
                self.last_bgr, self.agent_id
            )

            if found:
                msg = "objetivo_rojo area=%d bearing=%.3f" % (
                    area,
                    bearing if bearing is not None else -999.0
                )
                print(msg)
                #self.red_pub.publish(String(data="colision"))

                # ---- PRIORIDAD 1: evitar obstáculo delante ----
                if front_dist <= self.dist_wall_close:
                    v_cmd = 0.0
                    # Giro hacia el lado más despejado según LiDAR
                    if left_dist > right_dist:
                        w_cmd = self.d_turn
                    else:
                        w_cmd = self.i_turn

                else:
                    # ---- PRIORIDAD 2: ir al objetivo rojo ----
                    if bearing is not None:
                        # usas tu convención: w>0 -> derecha
                        w_cmd = self.k_ang * bearing

                        # Zona muerta para evitar serrucho
                        if abs(bearing) < 0.05:
                            w_cmd = 0.0

                        # Saturación
                        w_cmd = max(-self.w_max, min(self.w_max, w_cmd))

                    # Avanzar hacia el objetivo mientras no esté muy cerca
                    if area < AREA_GOAL:
                        v_cmd = self.v_slow
                    else:
                        # Muy cerca: si además está centrado, parar
                        if bearing is not None and abs(bearing) < CENTER_THRESH:
                            rospy.loginfo(
                                "Agente %s: objetivo rojo alcanzado, deteniendo robot.",
                                self.agent_id
                            )
                            v_cmd = 0.0
                            w_cmd = 0.0
                            self.col_pub.publish(String(data="colision"))
                        else:
                            # Cerca pero descentrado: girar en el sitio para centrar
                            v_cmd = 0.0
                            if bearing is not None:
                                w_cmd = self.k_ang * bearing
                                if abs(bearing) < 0.05:
                                    w_cmd = 0.0
                                w_cmd = max(-self.w_max, min(self.w_max, w_cmd))


        # --- 3) Aviso de colisión muy fuerte ---
        if collided:
            rospy.logwarn("Agente %s: colisión (front=%.2f m) .",
                          self.agent_id, front_dist)
            self.col_pub.publish(String(data="colision"))
            # Si quieres, puedes añadir aquí un frenado de emergencia:
            # v_cmd = 0.0

        # --- 4) Publicar comando final ---
        self._publicar_cmd(v_cmd, w_cmd)

    def _decide_wall_follow(self, front, left, right):
        """
        Algoritmo de seguir pared (actualmente usando right como referencia).
        """
        v = 0.0
        w = 0.0

        if front > self.dist_ahead_clear:
            v = self.v_forward
            if right > self.dist_wall_far:
                #v = 0.0
                w = self.d_soft  # girito suave
            elif self.dist_wall_close < right <= self.dist_wall_far:
                #v = 0.0
                w = 0.0
            else:  # right <= self.dist_wall_close
                #v = 0.0
                w = self.i_soft

        if front <= self.dist_ahead_clear:
            if left > right:
                v = 0.0
                w = self.i_turn
            else:
                v = 0.0
                w = self.i_turn

        return v, w


# ==========================
# Main con multiprocessing
# ==========================

def run_controller(agent_id):
    """
    Código que se ejecuta en CADA proceso.
    Aquí sí podemos llamar a rospy.init_node(), porque será 1 vez por proceso.
    """
    node_name = "maze_lidar_red_controller_" + str(agent_id)
    rospy.init_node(node_name, anonymous=False)

    controller = MazeLidarRedController(patat=str(agent_id))

    rospy.loginfo("Nodo %s inicializado para agente %s",
                  node_name, agent_id)
    rospy.spin()


if __name__ == "__main__":
    # Lista de agentes que quieres lanzar en paralelo
    AGENT_IDS = ["0", "1", "2", "3"]

    # Opcional: en algunos casos va mejor spawn que fork
    # mp.set_start_method("spawn")

    procesos = []

    for aid in AGENT_IDS:
        p = mp.Process(target=run_controller, args=(aid,))
        p.start()
        procesos.append(p)

    # Esperar a que terminen (normalmente ROS se quedará corriendo hasta Ctrl+C)
    for p in procesos:
        p.join()
