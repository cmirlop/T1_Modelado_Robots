#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
import numpy as np
import cv2
from sensor_msgs.msg import CompressedImage
from geometry_msgs.msg import Twist
from math import hypot

class PixelRun200:
    def __init__(self):
        # Parámetros
        self.vel_x = rospy.get_param("~vel_x", 0.5)        # m/s en eje X
        self.target_px = rospy.get_param("~target_px", 200) # píxeles
        self.min_area = rospy.get_param("~min_area", 150)   # área mínima contorno

        # Publicador de velocidad
        self.pub_cmd = rospy.Publisher("/cmd_vel", Twist, queue_size=1)

        # Suscriptor de imagen comprimida
        self.sub_img = rospy.Subscriber("/cenital", CompressedImage, self.img_cb, queue_size=1)

        # Estado
        self.start_center = None
        self.start_time = None
        self.done = False
        self.moving = False

        rospy.loginfo("Nodo listo: escuchando /cenital, publicando /cmd_vel")

    def img_cb(self, msg):
        # Decodificar imagen comprimida
        np_arr = np.frombuffer(msg.data, np.uint8)
        frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        if frame is None:
            rospy.logwarn_throttle(2.0, "No pude decodificar la imagen.")
            return

        center_red = self.find_color_center(frame, color="red")
        center_green = self.find_color_center(frame, color="green")

        if center_red is None or center_green is None:
            # Si no vemos ambos cubos, detenemos por seguridad
            if self.moving and not self.done:
                self.stop_robot()
                self.moving = False
            rospy.logwarn_throttle(2.0, "No veo ambos cubos (rojo y verde).")
            return

        # Centro del robot = punto medio entre los centros detectados
        cx = int(0.5 * (center_red[0] + center_green[0]))
        cy = int(0.5 * (center_red[1] + center_green[1]))
        center_robot = (cx, cy)

        # Inicializar punto de partida y comenzar a mover
        if self.start_center is None:
            self.start_center = center_robot
            self.start_time = rospy.Time.now()
            self.send_velocity(self.vel_x)
            self.moving = True
            rospy.loginfo("Inicio medido en px en {}. Moviendo a vx=%.3f m/s".format(self.start_center) % self.vel_x)
            return

        # Si ya terminamos, nos aseguramos de estar parados
        if self.done:
            self.stop_robot()
            return

        # Desplazamiento en píxeles
        dx = center_robot[0] - self.start_center[0]
        dy = center_robot[1] - self.start_center[1]
        dist_px = hypot(dx, dy)

        # Asegurar que estamos moviendo si aún no hemos llegado
        if not self.moving:
            self.send_velocity(self.vel_x)
            self.moving = True

        # ¿Llegó a 200 px?
        if dist_px >= self.target_px:
            elapsed = (rospy.Time.now() - self.start_time).to_sec()
            self.done = True
            self.stop_robot()
            rospy.loginfo("Recorrido de %.1f px alcanzado en %.3f s (vx=%.3f m/s)."
                          % (self.target_px, elapsed, self.vel_x))

    def send_velocity(self, vx):
        twist = Twist()
        twist.linear.x = vx
        twist.linear.y = 0.0
        twist.linear.z = 0.0
        twist.angular.x = 0.0
        twist.angular.y = 0.0
        twist.angular.z = 0.0
        self.pub_cmd.publish(twist)

    def stop_robot(self):
        self.send_velocity(0.0)

    def find_color_center(self, bgr_img, color="red"):
        """Devuelve (cx, cy) del mayor contorno del color especificado o None."""
        hsv = cv2.cvtColor(bgr_img, cv2.COLOR_BGR2HSV)

        if color == "red":
            # Rojo en HSV: dos rangos por el wrap del tono
            lower1 = np.array([0, 90, 60])
            upper1 = np.array([10, 255, 255])
            lower2 = np.array([160, 90, 60])
            upper2 = np.array([179, 255, 255])
            mask1 = cv2.inRange(hsv, lower1, upper1)
            mask2 = cv2.inRange(hsv, lower2, upper2)
            mask = cv2.bitwise_or(mask1, mask2)
        elif color == "green":
            # Verde típico
            lower = np.array([35, 90, 60])
            upper = np.array([85, 255, 255])
            mask = cv2.inRange(hsv, lower, upper)
        else:
            return None

        # Limpieza
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        # Contornos y centroide del mayor
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return None

        biggest = max(contours, key=cv2.contourArea)
        if cv2.contourArea(biggest) < self.min_area:
            return None

        M = cv2.moments(biggest)
        if M["m00"] == 0:
            return None
        cx = int(M["m10"] / M["m00"])
        cy = int(M["m01"] / M["m00"])
        return (cx, cy)

def main():
    rospy.init_node("pixel_run_200")
    PixelRun200()
    rospy.spin()

if __name__ == "__main__":
    main()
