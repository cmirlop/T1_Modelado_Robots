#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
import numpy as np
import threading
import time
from collections import defaultdict, deque

from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan, CompressedImage
from std_srvs.srv import Empty
from std_msgs.msg import String

import cv2

# ==========================
# Tópicos ROS
# ==========================
LIDAR_TOPIC = "/lidar"
CAM_TOPIC   = "/camara_robot"   # sensor_msgs/CompressedImage
CMD_TOPIC   = "/cmd_vel"
colision_topic = "/aviso_colision"

num_ag = "0"

# ==========================
# LiDAR (discretización)
# ==========================
NUM_SECTORES = 7
BINS_DIST = [6, 10,30]        # cerca / medio / lejos (m)
CLIP_DIST = 30
COLLISION_DIST = 4.5

# Heurística de exploración lateral
OPEN_PROBE_THRESH = 20.0      # si a ±90º hay >10 m, consideramos "abierto"
GUIDE_PROB = 0.8              # prob. de aplicar la guía cuando no se ve objetivo
ANGLE_WINDOW_DEG = 8.0        # ventana alrededor del ángulo (suaviza ruido)


# ==========================
# Cámara / visión del objetivo rojo
# ==========================
IMG_RESIZE_W = 320             # aceleramos el procesamiento
AREA_MIN = 150                 # pix mínimos para aceptar detección
AREA_GOAL = 9000               # si supera esto ~ “muy cerca”
CENTER_THRESH = 0.12           # |bearing_norm| < 0.12 => centrado (~12 % ancho)

# HSV del rojo (dos rangos por envolver 180°)
# Ajusta según tu render de Unity (iluminación/material)
LOW1 = (0,   90,  80)
HIGH1= (10,  255, 255)
LOW2 = (170, 90,  80)
HIGH2= (180, 255, 255)

# ==========================
# Acciones (v,w)
# ==========================
ACCIONES = [
    ("forward",  3.00,  0.0),
    ("left",     0.00,  -1.0),
    ("right",    0.00, 1.0),
    ("slow",     1.00,  0.0),
    ("stop",     0.00,  0.0),
]

# ==========================
# Q-learning
# ==========================
ALPHA = 0.25
GAMMA = 0.95
EPSILON_INI = 0.80
EPSILON_MIN = 0.05
EPSILON_DECAY = 0.995

PASOS_MAX_EPISODIO = 900
ESPERA_INICIO = 1.0
HZ_CONTROL = 10
COOLDOWN_COLISION = 1.0
RESET_SERVICE = "/reset_world"


#Contador veces de giro, si se envian más de 70 ordenes de giro seguidas penalizacion


def min_range_at_angle(scan_msg, angle_rad, window_deg=8.0, fallback=np.inf):
    """
    Devuelve el mínimo de /lidar alrededor de 'angle_rad' (en rad) dentro de ±window_deg.
    Respeta angle_min, angle_increment y range_max del propio LaserScan.
    """
    ranges = np.asarray(scan_msg.ranges, dtype=np.float32)
    n = ranges.size
    if n == 0:
        return fallback

    angle_min = scan_msg.angle_min
    inc = scan_msg.angle_increment
    rng_max = scan_msg.range_max if np.isfinite(scan_msg.range_max) and scan_msg.range_max > 0 else CLIP_DIST

    # Índice del ángulo pedido
    idx_center = int(round((angle_rad - angle_min) / inc))
    # Ancho de la ventana en índices
    half_w = max(1, int(round(np.deg2rad(window_deg) / abs(inc))))

    # Compensar fuera de rango
    i0 = max(0, idx_center - half_w)
    i1 = min(n, idx_center + half_w + 1)

    seg = ranges[i0:i1]
    seg = seg[np.isfinite(seg)]
    if seg.size == 0:
        return fallback

    # Acotar por arriba al rango máximo real del sensor
    val = float(np.clip(np.min(seg), 0.0, rng_max))
    return val


# ==========================
# Utilidades
# ==========================
def discretiza_dist(d):
    if d < BINS_DIST[0]: return 0
    if d < BINS_DIST[1]: return 1
    return 2

def sectoriza(scan_msg, num_sectores):
    """
    Devuelve distancias mínimas por sector ancladas a 0 rad (frente).
    Asume angle_min, angle_max y angle_increment válidos en scan_msg.
    """
    ranges = np.array(scan_msg.ranges, dtype=np.float32)
    # limpia NaN/Inf con un valor grande
    ranges[~np.isfinite(ranges)] = CLIP_DIST

    angle_min = scan_msg.angle_min
    angle_inc = scan_msg.angle_increment
    n = ranges.shape[0]

    # índice del ángulo 0 (frente)
    zero_idx = int(round((0.0 - angle_min) / angle_inc))
    zero_idx = np.clip(zero_idx, 0, n-1)

    # “rotar” el array para que el frente quede en el centro
    rotated = np.roll(ranges, -(zero_idx - n//2))

    # partir en sectores y tomar mínimos
    step = max(1, n // num_sectores)
    mins = []
    for i in range(num_sectores):
        seg = rotated[i*step:(i+1)*step] if (i+1)*step <= n else rotated[i*step:]
        mins.append(float(np.clip(np.min(seg) if seg.size else CLIP_DIST, 0.0, CLIP_DIST)))

    return np.array(mins, dtype=np.float32)

def bins_lidar(mins):
    return [discretiza_dist(d) for d in mins]

def discretiza_bearing(bearing_norm):
    # bearing_norm ~ [-1..1] relativo al centro de la imagen
    if bearing_norm < -0.12: return 0  # izquierda
    if bearing_norm >  0.12: return 2  # derecha
    return 1                            # centrado

def discretiza_area(area):
    if area < 1200: return 0   # pequeño
    if area < 4500: return 1   # mediano
    return 2                   # grande

def extrae_objetivo_rojo(cv_bgr):
    """
    Devuelve: found(bool), bearing_norm(-1..1), area(int), bbox(x,y,w,h)
    """
    if cv_bgr is None:
        return False, None, 0, None

    h, w = cv_bgr.shape[:2]
    scale = float(IMG_RESIZE_W) / float(w)
    cv_small = cv2.resize(cv_bgr, (IMG_RESIZE_W, int(h*scale))) if w > IMG_RESIZE_W else cv_bgr
    H, W = cv_small.shape[:2]

    hsv = cv2.cvtColor(cv_small, cv2.COLOR_BGR2HSV)
    mask1 = cv2.inRange(hsv, np.array(LOW1), np.array(HIGH1))
    mask2 = cv2.inRange(hsv, np.array(LOW2), np.array(HIGH2))
    mask = cv2.bitwise_or(mask1, mask2)

    # Limpieza morfológica
    kernel = np.ones((3,3), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return False, None, 0, None

    c = max(contours, key=cv2.contourArea)
    area = int(cv2.contourArea(c))
    if area < AREA_MIN:
        return False, None, area, None

    x,y,wc,hc = cv2.boundingRect(c)
    cx = x + wc/2.0
    bearing_norm = (cx - (W/2.0)) / (W/2.0)   # -1 izquierda, +1 derecha

    return True, float(bearing_norm), int(area), (x,y,wc,hc)

def observa_estado(lidar_mins, bearing_norm, area):
    lidar_bins = bins_lidar(lidar_mins)
    bearing_bin = 3  # 3 significa “no visto”
    area_bin = 0
    if bearing_norm is not None:
        bearing_bin = discretiza_bearing(bearing_norm)  # 0 izq, 1 centro, 2 der
        area_bin = discretiza_area(area)                # 0 peq, 1 med, 2 gra
    front_blocked = 1 if lidar_mins[len(lidar_mins)//2] < BINS_DIST[0] else 0
    # Estado final: [lidar_bins..., bearing_bin, area_bin, front_blocked]
    return tuple(lidar_bins + [bearing_bin, area_bin, front_blocked])

# ==========================
# Agente RL
# ==========================
class RLRedTargetAgent(object):
    def __init__(self):
        self.lock = threading.Lock()
        self.twist_pub = rospy.Publisher(CMD_TOPIC+num_ag, Twist, queue_size=1)
        self.col_pub = rospy.Publisher(colision_topic+num_ag, String, queue_size=1)
        self.lidar_sub = rospy.Subscriber(LIDAR_TOPIC+num_ag, LaserScan, self.cb_lidar, queue_size=1)
        self.img_sub   = rospy.Subscriber(CAM_TOPIC+num_ag, CompressedImage, self.cb_img, queue_size=1)
        print(num_ag,CMD_TOPIC+num_ag,colision_topic+num_ag,LIDAR_TOPIC+num_ag,CAM_TOPIC+num_ag)

        self.cont_gir = 0
        self.ant_name = None
        self.cont_Rec = 0

        self.last_lidar = None
        self.lidar_ok = False

        self.last_bgr = None
        self.image_ok = False

        # Visión últimos valores
        self.last_found = False
        self.last_bearing = None
        self.last_area = 0

        # Q-table
        self.Q = defaultdict(lambda: np.zeros(len(ACCIONES), dtype=np.float32))
        self.epsilon = EPSILON_INI

        # Historial shaping
        self.area_hist = deque(maxlen=4)

        # Servicio reset (opcional)
        self.reset_srv = None
        try:
            rospy.wait_for_service(RESET_SERVICE, timeout=2.0)
            self.reset_srv = rospy.ServiceProxy(RESET_SERVICE, Empty)
            rospy.loginfo("Servicio de reset disponible: %s", RESET_SERVICE)
        except rospy.ROSException:
            rospy.logwarn("No se encontró servicio %s. Seguimos sin reset mundo.",)

        self.episodio = 0
        self.paso = 0

    # ---- Callbacks ----
    def cb_lidar(self, msg):
        with self.lock:
            self.last_lidar = msg
            
            self.lidar_ok = True

    def cb_img(self, msg):
        # Decodificar CompressedImage (jpeg/png) a cv::Mat
        np_arr = np.frombuffer(msg.data, np.uint8)
        bgr = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        with self.lock:
            self.last_bgr = bgr
            self.image_ok = True

    # ---- Control ----
    def publicar_accion(self, a_idx):
        name, v, w = ACCIONES[a_idx]
        t = Twist()
        t.linear.x = v
        t.angular.z = w
        #print(name)
        self.twist_pub.publish(t)

    def stop(self):
        self.twist_pub.publish(Twist())

    # ---- Observación/Estado ----
    def obtener_estado(self):
        if not self.lidar_ok or self.last_lidar is None:
            return None, None, None, None
        mins = sectoriza(self.last_lidar, NUM_SECTORES)

        bearing = None
        area = 0
        found = False
        if self.image_ok and self.last_bgr is not None:
            found, bearing, area, _ = extrae_objetivo_rojo(self.last_bgr)

        s = observa_estado(mins, bearing, area)
        return s, mins, (found, bearing, area), mins[NUM_SECTORES//2]

    # ---- RL core ----
    def colision(self, front_now):
        
        return front_now is not None and front_now < COLLISION_DIST

    def exito(self, found, bearing, area):
        if not found or bearing is None: 
            return False
        centered = abs(bearing) < CENTER_THRESH
        big = area >= AREA_GOAL
        return centered and big

    def recompensa(self, a_idx, obs_prev, obs_now, collided, success,front_next):
        """
        Shaping:
        + Gran premio por éxito
        + Incremento si el objetivo crece (más cerca)
        + Incremento por reducir |bearing|
        + Pequeño bono por mover hacia delante cuando está centrado
        - Penalización por perder objetivo
        - Penalización por colisión
        - Pequeño coste por paso y por girar mucho
        """
        r = -0.02  # coste por paso

        if success:
            r += 8.0
            return r

        if collided:
            r -= 2.0
            return r

        name, v, w = ACCIONES[a_idx]

        (found_prev, bearing_prev, area_prev) = obs_prev
        (found_now, bearing_now, area_now) = obs_now

        # Si antes lo veía y ahora no => mala señal
        if found_prev and not found_now:
            r -= 0.5

        
        #global cont_gir , ant_name,cont_Rec

        if self.ant_name is None : self.ant_name = name
        if name in ("left", "right") and self.ant_name == name: self.cont_gir += 1
        if name != self.ant_name : self.cont_gir = 0
        if name in ("forward"): 
            self.cont_gir = 0
            self.cont_Rec += 1

        self.ant_name = name
        # Si no lo veo aún, pequeño shaping con LiDAR (dejar espacio al frente)
        if not found_now:
            # favorecer despeje frontal si avanzamos
            if name in ("forward", "slow") and self.cont_Rec < 15:
                r += 0.03
            if name in ("forward", "slow") and self.cont_Rec >= 15 :
                r += 0.00
            if name in ("left", "right") and self.cont_gir < 5:
                self.cont_Rec = 0
                r += 0.02
            if name in ("left", "right") and self.cont_gir > 5:
                r -= 0.01
            if front_next < 10.0:
                r -= 0.04
            return r

        # Lo veo: premiar acercamiento y centrado
        if bearing_prev is not None and bearing_now is not None:
            delta_b = abs(bearing_prev) - abs(bearing_now)
            r += np.clip(delta_b * 1.2, -0.3, 0.3)  # reducir error angular

        if area_prev is not None:
            delta_a = (area_now - area_prev) / float(max(area_prev, 1))
            r += np.clip(delta_a * 0.6, -0.4, 0.6)  # crecer en imagen

        # Bonus por avanzar cuando está casi centrado
        if name in ("forward", "slow") and abs(bearing_now) < 0.2:
            r += 0.08 if name == "forward" else 0.04

        # Pequeña penalización por girar sin avance
        #if name in ("left", "right"):
            #r -= 0.02

        return r

    def elegir_accion(self, s):
        if np.random.rand() < self.epsilon:
            return np.random.randint(len(ACCIONES))
        qvals = self.Q[s]
        return int(np.argmax(qvals))

    def actualizar_q(self, s, a, r, s_next, terminal):
        q = self.Q[s][a]
        target = r if (terminal or s_next is None) else (r + GAMMA * np.max(self.Q[s_next]))
        self.Q[s][a] = (1 - ALPHA) * q + ALPHA * target

    def intentar_reset_mundo(self):
        if self.reset_srv is not None:
            try:
                self.reset_srv()
                rospy.loginfo("Reset del mundo solicitado.")
            except rospy.ServiceException as e:
                rospy.logwarn("Fallo reset mundo: %s", e)

    def entrenar(self):
        rate = rospy.Rate(HZ_CONTROL)
        rospy.sleep(ESPERA_INICIO)
        rospy.loginfo("Inicio entrenamiento RL con objetivo rojo…")

        while not rospy.is_shutdown():
            # Nuevo episodio
            self.episodio += 1
            self.paso = 0
            self.intentar_reset_mundo()
            self.stop()
            self.area_hist.clear()
            prev_vision = (False, None, 0)
            rospy.loginfo("== Episodio %d ==", self.episodio)

            for _ in range(PASOS_MAX_EPISODIO):
                self.paso += 1
                s, mins, (found, bearing, area), front_now = self.obtener_estado()
                if s is None:
                    self.stop()
                    rate.sleep()
                    continue
                # ---- Guía heurística de exploración lateral ----
                # Solo si no vemos el objetivo o el frente se ve comprometido
                use_guide = (not found) and (np.random.rand() < GUIDE_PROB)

                if use_guide:
                    left90  = min_range_at_angle(self.last_lidar,  +np.pi/2, ANGLE_WINDOW_DEG, fallback=0.0)
                    right90 = min_range_at_angle(self.last_lidar,  -np.pi/2, ANGLE_WINDOW_DEG, fallback=0.0)
                    # (Opcional) también puedes mirar ±60º si tu laberinto es estrecho:
                    # left60  = min_range_at_angle(self.last_lidar,  +np.pi/3, ANGLE_WINDOW_DEG, fallback=0.0)
                    # right60 = min_range_at_angle(self.last_lidar,  -np.pi/3, ANGLE_WINDOW_DEG, fallback=0.0)

                    choose_left = (left90  > OPEN_PROBE_THRESH) and (left90  > right90)
                    choose_right= (right90 > OPEN_PROBE_THRESH) and (right90 > left90)

                    if choose_left or choose_right:
                        # Fuerza acción de prueba (prioridad sobre la política RL en este tick)
                        if choose_left:
                            print("Comprobamos izq")
                            a = [i for i,(n,_,_) in enumerate(ACCIONES) if n == "left"][0]
                        else:
                            print("Comprobamos der")
                            a = [i for i,(n,_,_) in enumerate(ACCIONES) if n == "right"][0]
                    else:
                        # Si no está muy claro, deja que el RL decida
                        a = self.elegir_accion(s)
                else:
                    a = self.elegir_accion(s)
                # -----------------------------------------------

                # Selección acción
                #a = self.elegir_accion(s)
                self.publicar_accion(a)

                rate.sleep()

                # Nueva observación
                s_next, mins_next, (found2, bearing2, area2), front_next = self.obtener_estado()
                collided = self.colision(front_next)
                #print("Distancia",front_next)
                success = self.exito(found2, bearing2, area2)

                r = self.recompensa(a,
                                    prev_vision,
                                    (found2, bearing2, area2),
                                    collided,
                                    success,front_next)
                #print("recompensa",r)
                self.actualizar_q(s, a, r, s_next, terminal=(collided or success))

                # Decaimiento epsilon
                self.epsilon = max(EPSILON_MIN, self.epsilon * EPSILON_DECAY)

                # Avanzar estado
                prev_vision = (found2, bearing2, area2)
                s = s_next

                if collided:
                    rospy.loginfo("Colisión en paso %d. eps=%.3f", self.paso, self.epsilon)
                    self.stop()
                    rospy.sleep(COOLDOWN_COLISION)
                    self.col_pub.publish(data="colision")
                    break

                if success:
                    rospy.loginfo("¡Objetivo rojo alcanzado! Paso %d. eps=%.3f", self.paso, self.epsilon)
                    self.stop()
                    rospy.sleep(0.7)
                    break

            self.stop()

# ==========================
# Main
# ==========================


if __name__ == "__main__":
    
    rospy.init_node("rl_red_target_agent", anonymous=False)
    np.random.seed(int(time.time()) % (2**32 - 1))
    agent = RLRedTargetAgent()
    num_ag = "1"
    agent2 = RLRedTargetAgent()

    num_ag = "2"
    agent3 = RLRedTargetAgent()
      
    try:
        import threading
        t1 = threading.Thread(target=agent.entrenar)
        t2 = threading.Thread(target=agent2.entrenar)
        t3 = threading.Thread(target=agent3.entrenar)

        t1.start()
        t2.start()
        t3.start()

        t1.join()
        t2.join()
        t3.join()

        #agent.entrenar()
        #agent2.entrenar()
    except rospy.ROSInterruptException:
        pass
    finally:
        agent.stop()
        agent2.stop()
        agent3.stop()
