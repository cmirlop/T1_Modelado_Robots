#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import numpy as np
import math
from sensor_msgs.msg import LaserScan

NUM_SECTORES = 180          # igual que en tu código grande
CLIP_DIST    = 30.0         # distancia máxima que consideramos (m)


def sectoriza(scan_msg, num_sectores):
    """Devuelve un array de 'num_sectores' con la distancia mínima en cada sector."""
    ranges = np.array(scan_msg.ranges, dtype=np.float32)

    # Reemplazar inf/NaN por CLIP_DIST
    ranges[~np.isfinite(ranges)] = CLIP_DIST
    ranges = np.clip(ranges, 0.0, CLIP_DIST)

    n = len(ranges)
    angle_min = scan_msg.angle_min
    angle_inc = scan_msg.angle_increment

    # Índice del rayo en ángulo 0.0 (frente del láser)
    zero_idx = int(round((0.0 - angle_min) / angle_inc))
    zero_idx = int(np.clip(zero_idx, 0, n - 1))

    # Colocar el rayo de 0 rad en el centro del array
    rotated = np.roll(ranges, -(zero_idx - n // 2))

    # Partir en sectores y coger la distancia mínima de cada uno
    step = max(1, n // num_sectores)
    mins = []
    for i in range(num_sectores):
        seg = rotated[i * step:(i + 1) * step]
        if len(seg) == 0:
            mins.append(CLIP_DIST)
        else:
            mins.append(float(np.min(seg)))
    return np.array(mins, dtype=np.float32)


def lateral_sector_indices(scan_msg, num_sectores):
    """Devuelve índices aproximados de los sectores a +90° (left) y -90° (right)."""
    angle_min = scan_msg.angle_min
    angle_inc = scan_msg.angle_increment
    n = len(scan_msg.ranges)

    angle_max = angle_min + (n - 1) * angle_inc
    fov = angle_max - angle_min           # campo de visión total del LIDAR (rad)

    sectors_per_rad = float(num_sectores) / float(fov)

    center = num_sectores // 2           # sector que mira a 0 rad
    offset_90 = int(round((math.pi / 2.0) * sectors_per_rad))

    idx_left  = int(np.clip(center + offset_90, 0, num_sectores - 1))   # +90°
    idx_right = int(np.clip(center - offset_90, 0, num_sectores - 1))   # -90°

    return idx_left, idx_right


class LidarTester(object):
    def __init__(self):
        rospy.Subscriber("/lidar0", LaserScan, self.lidar_cb)
        rospy.loginfo("Nodo LidarTester escuchando en /lidar0...")

    def lidar_cb(self, msg):
        mins = sectoriza(msg, NUM_SECTORES)

        center = NUM_SECTORES // 2
        idx_left, idx_right = lateral_sector_indices(msg, NUM_SECTORES)

        dist_front = mins[center]
        dist_left  = mins[idx_left]
        dist_right = mins[idx_right]

        rospy.loginfo("front = %.2f m | left = %.2f m | right = %.2f m",
                      dist_front, dist_left, dist_right)


if __name__ == "__main__":
    rospy.init_node("lidar_test_front_left_right")
    tester = LidarTester()
    rospy.spin()
