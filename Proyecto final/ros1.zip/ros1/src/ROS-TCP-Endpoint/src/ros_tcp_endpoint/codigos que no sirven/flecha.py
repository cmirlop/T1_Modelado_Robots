#!/usr/bin/env python3
import rospy
import cv2
import numpy as np
from sensor_msgs.msg import CompressedImage
from cv_bridge import CvBridge
from geometry_msgs.msg import Twist
import math

bridge = CvBridge()
cmd_pub = None
prev_dist = None  # distancia previa al objetivo

def get_centroid(mask):
    M = cv2.moments(mask)
    if M["m00"] > 0:
        cx = int(M["m10"]/M["m00"])
        cy = int(M["m01"]/M["m00"])
        return (cx, cy)
    return None

def callback(msg):
    global cmd_pub, prev_dist
    frame = bridge.compressed_imgmsg_to_cv2(msg, desired_encoding="bgr8")
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # --- Verde ---
    lower_green = np.array([40, 50, 50])
    upper_green = np.array([80, 255, 255])
    mask_green = cv2.inRange(hsv, lower_green, upper_green)

    # --- Rojo ---
    lower_red1 = np.array([0, 100, 100])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([160, 100, 100])
    upper_red2 = np.array([179, 255, 255])
    mask_red = cv2.inRange(hsv, lower_red1, upper_red1) | cv2.inRange(hsv, lower_red2, upper_red2)

    # --- Amarillo ---
    lower_yellow = np.array([20, 100, 100])
    upper_yellow = np.array([30, 255, 255])
    mask_yellow = cv2.inRange(hsv, lower_yellow, upper_yellow)

    # Centroides
    green_centroid = get_centroid(mask_green)
    red_centroid   = get_centroid(mask_red)
    yellow_centroid = get_centroid(mask_yellow)

    twist = Twist()

    if green_centroid and red_centroid and yellow_centroid:
        # Dibujar flecha (rojo -> verde)
        cv2.arrowedLine(frame, red_centroid, green_centroid, (255, 0, 0), 3, tipLength=0.3)
        cv2.circle(frame, yellow_centroid, 5, (0, 255, 255), -1)

        # Vector orientación (rojo → verde)
        dir_vec = (green_centroid[0] - red_centroid[0],
                   green_centroid[1] - red_centroid[1])

        # Vector hacia el objetivo (rojo → amarillo)
        goal_vec = (yellow_centroid[0] - red_centroid[0],
                    yellow_centroid[1] - red_centroid[1])

        # Ángulo entre ambos vectores
        dot = dir_vec[0]*goal_vec[0] + dir_vec[1]*goal_vec[1]
        norm_dir = math.sqrt(dir_vec[0]**2 + dir_vec[1]**2)
        norm_goal = math.sqrt(goal_vec[0]**2 + goal_vec[1]**2)
        dist = norm_goal  # distancia al objetivo

        if norm_dir > 0 and norm_goal > 0:
            cos_angle = dot / (norm_dir * norm_goal)
            cos_angle = max(-1.0, min(1.0, cos_angle))
            angle = math.acos(cos_angle)

            # Producto cruzado para saber hacia dónde girar
            cross = dir_vec[0]*goal_vec[1] - dir_vec[1]*goal_vec[0]

            if abs(angle) < 0.2:  # casi alineado
                if prev_dist is not None and dist > prev_dist:
                    # si al avanzar la distancia aumenta → ir hacia atrás
                    twist.linear.x = -0.2
                else:
                    twist.linear.x = 0.2  # avanzar hacia adelante
            else:
                twist.angular.z = 0.3 if cross > 0 else -0.3

        # Guardar distancia previa
        prev_dist = dist

    # Publicar en cmd_vel
    cmd_pub.publish(twist)

    # Mostrar imagen
    cv2.imshow("Torito con flecha", frame)
    cv2.waitKey(1)

def main():
    global cmd_pub
    rospy.init_node("torito_visualizer")
    rospy.Subscriber("/cenital", CompressedImage, callback)
    cmd_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=1)
    rospy.spin()

if __name__ == "__main__":
    main()
