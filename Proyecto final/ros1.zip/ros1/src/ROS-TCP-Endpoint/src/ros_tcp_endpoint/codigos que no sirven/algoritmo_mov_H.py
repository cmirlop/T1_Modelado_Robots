import cv2
import numpy as np
import json
import time
import math


frame_global = None


# ----------------------
# Funciones auxiliares
# ----------------------
def es_blanca(region):
    """Verifica si toda la región es blanca (valor 255 en una imagen binaria)."""
    return np.all(region == 255)

def crear_rectangulo_rotado(cx, cy, size, angulo):
    rect = ((cx, cy), (size, size), angulo)
    return rect     

def es_blanca_rotada(img, rect ):
    
    box = cv2.boxPoints(rect)
    box = box.astype(int)

    mask = np.zeros_like(img, dtype=np.uint8)
    cv2.fillPoly(mask, [box], 255)

    inside = cv2.bitwise_and(img, mask)
    return np.all(inside[mask == 255] == 255)


"""def objetivo_dentro(objetivo, centro, lado=50):
    
    #Comprueba si el punto 'objetivo' está dentro de un cuadrado
    #centrado en 'centro' con tamaño 'lado'.
    
    px, py = objetivo
    cx, cy = centro
    
    # límites del cuadrado
    half = lado // 2
    x1, x2 = px - half, px + half
    y1, y2 = py - half, py + half

    # comprobación
    if x1 <= cx <= x2 and y1 <= cy <= y2:
        print("✅ El punto está dentro")
        return True
    else:
        print("❌ El punto está fuera")
        return False"""


def calcular_distancia(objetivo, centro):
    """
    Comprueba si el objetivo está a una distancia menor o igual
    que 'umbral' del centro del rectángulo.
    """
    px, py = objetivo
    cx, cy = centro

    # distancia euclidiana
    dist = math.sqrt((px - cx) ** 2 + (py - cy) ** 2)
    return dist

def comprobar_distancia(dist,umbral):
    if dist <= umbral:
        print(f"✅ El objetivo está dentro del rango (distancia={dist:.2f})")
        return True
    else:
        print(f"❌ El objetivo está fuera del rango (distancia={dist:.2f})")
        return False



def mov_horizontal(img,nx,ny,w_r,high_r,w,h,ang):
    x1 = nx - w_r // 2
    y1 = ny - high_r // 2
    x2 = nx + w_r // 2
    y2 = ny + high_r // 2
    region = img[y1:y2, x1:x2]
    coor_region = ((nx,ny),(w_r,high_r),ang)
    return region,coor_region, True
    




def movimientos_validos(img, x, y, size, visitado,objetivo,pixeles):
    global frame_global
    """Genera posiciones vecinas válidas."""
    w_r ,high_r = size #Anchura y altura del robot
    h, w = img.shape #Altura y anchura de la imageb

    #El robot se puede mover en horizontal, en vertical, o en diagonal
    acciones_posibles = ["Horizontal"]
    """posibles = [(x+pixeles, y), (x-pixeles, y), (x, y+pixeles), (x, y-pixeles),
                (x+pixeles,y+pixeles),(x-pixeles,y+pixeles),
                (x+pixeles,y-pixeles),(x-pixeles,y-pixeles)]"""
    posibles_hor = [(x+pixeles, y,0), (x-pixeles, y,0)]
    #posibless_ver = [(x, y+pixeles,-90), (x, y-pixeles,90)]
    #Comprobar los movimientos siguientes
    """posibles_incli = [(x+pixeles,y+pixeles,45),(x-pixeles,y+pixeles,135),
                (x+pixeles,y-pixeles,-45),(x-pixeles,y-pixeles,-135)]"""
    
    #Acciones validas
    validos = []
    print("Tamaño del robot")
    print(size)
    posi,region,coor_region,mov_valido = None,None,None, False

    #Bucle que recorre todas las acciones que puede hacer el robot
    for acciones in acciones_posibles:
        print(acciones)
        #Depende de que accion escogamos del for, escogeremos un conjunto y otro de acciones posibles
        if acciones == "Horizontal": posi = posibles_hor
        #elif acciones == "Vertical" : posi = posibless_ver
        #elif acciones == "Diagonal" : posi = posibles_incli

        #Bucle que comprueba coordenada a coordenada, todas las acciones posibles
        for nx, ny ,ang in posi:
            print("Coordenadas a probar")
            print((nx,ny)),print((w-w_r,h-high_r))
            #if 0 <= nx < w-(w_r/2) and 0 <= ny < h-(high_r/2) and not visitado[ny, nx]:
            if ((nx - w_r//2 >= 0 and nx + w_r//2 < w and ny - high_r//2 >= 0 and ny + high_r//2 < h ) 
                and acciones == "Horizontal" and not visitado[ny, nx]):
                region, coor_region, mov_valido =  mov_horizontal(img,nx,ny,w_r,high_r,w,h,ang)
            else:
                mov_valido = False
                print("Movimiento no valido")
                print("Coordenadas:"),print(nx - w_r//2 >= 0),print(nx + w_r//2 < w),print(ny - high_r//2 >= 0)
                print(ny + high_r//2 < h),print(acciones),print(visitado[ny, nx])
                time.sleep(10)

            if  mov_valido :
                print(coor_region)
                box = cv2.boxPoints(coor_region)   # devuelve 4 puntos flotantes
                box = box.astype(int)
                cv2.polylines(frame_global, [box], isClosed=True, color=(0, 255, 0), thickness=2)
                cv2.imshow("Rectángulo rotado", frame_global)

                cv2.imshow("DFS progresoss", region)
                print(coor_region)
                # espera 300 ms en lugar de 3000 ms, y repite muchos pasos
                if cv2.waitKey(300) & 0xFF == 27:  # si presionas ESC, se sale
                    break
                time.sleep(1)

                dist = calcular_distancia(objetivo,(nx,ny))

                if comprobar_distancia(dist,50):
                    print("OBJETIVO ENC Objetivo encontrado")
                    validos.append((nx, ny,ang,dist))
                    break
                #elif es_blanca(region) and acciones != "Diagonal" :
                #    validos.append((nx, ny))
                elif es_blanca_rotada(region,coor_region): # and acciones == "Diagonal":
                    print("Movimiento valido")
                    validos.append((nx, ny,ang,dist))
                else:
                    print("No es blanco, ni objetivo")

            time.sleep(3)
    print(validos)
    return validos

def dfs(img, inicio, objetivo,inicio_cen, objetivo_cen, size, visualizar=False):
    global frame_global
    """DFS para encontrar un camino válido."""
    h, w = img.shape[:2]
    visitado = np.zeros((h, w), dtype=bool)
    #pila = [(inicio, [inicio])] if h < w else  [(inicio_cen, [inicio_cen])]
    pila = [(inicio_cen, [inicio_cen])]

    img_color = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)

    # x e y son las coordenadas de Incio, de donde empieza el robot
    paso = 0
    while pila:
        print("1")
        (x, y,ang), camino = pila.pop()
        
        if visitado[y, x]:
            continue
        visitado[y, x] = True

        # Visualización del intento
        if visualizar:
            paso += 1
            temp = img_color.copy()
            frame_global = temp
            #cv2.rectangle(temp, (x, y), (x+size[0], y+size[1]), (0, 255, 0), 2)
            #cv2.imshow("DFS progreso", temp)
            # espera 300 ms en lugar de 3000 ms, y repite muchos pasos
            #if cv2.waitKey(300) & 0xFF == 27:  # si presionas ESC, se sale
            #    break  

        # ¿Se alcanzó el objetivo?
        if x == objetivo[0] and y == objetivo[1]:
            print("Objetivo alcanzado")
            cv2.destroyAllWindows()
            return camino
        else:
            print("No se ha alcanzado el objetivo aun")
        print("Vamos a ver vecinos")
        for vecino in movimientos_validos(img, x, y, size, visitado,objetivo,50):
            pila.append((vecino, camino + [vecino]))

    cv2.destroyAllWindows()
    return None  # No hay camino


#----Funcion que carga de un JSON las zonas a donde tiene 
# que ir el robot
def cargar_zonas(filename="zonas.json"):
    """Cargar las zonas desde un JSON"""
    with open(filename, "r") as f:
        data = json.load(f)
    return tuple(data["zone1"]), tuple(data["zone2"]), tuple(data["robot1"])

# ----------------------
# Ejemplo de uso
# ----------------------
if __name__ == "__main__":

    # Cargar imagen en escala de grises
    zone1, zone2, robot1 = cargar_zonas("zonas_4_Esquinas.json")
    img = cv2.imread("mask.png", cv2.IMREAD_GRAYSCALE)
    mask_copy = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    #cv2.rectangle(mask_copy, robot1[0], robot1[1], (0, 155, 155), -1)
    #cv2.rectangle(mask_copy, zone1[0], zone1[1], (255, 0, 0), -1)
    cv2.circle(mask_copy, zone1[2], 6, (255, 0, 0), -1)
    #cv2.circle(mask_copy, robot1[0], 1, (255, 0, 0), -1)
    
    mask_copy = cv2.cvtColor(mask_copy, cv2.COLOR_BGR2GRAY)
    # Binarizar: píxeles blancos = 255, obstáculos = 0
    _, binaria = cv2.threshold(mask_copy, 200, 255, cv2.THRESH_BINARY)

    size = (robot1[1][0] - robot1[0][0] , robot1[1][1] - robot1[0][1])
    
    (j,k) = robot1[2]      # Centro                       
    objetivo_cen = zone1[2]     # Centro
    inicio = robot1[0]      # esquina superior izq del rectángulo inicial
    objetivo = zone1[0]     # esquina sup izq del rectángulo objetivo

    camino = dfs(binaria, inicio, objetivo,(j,k,0), objetivo_cen, size, visualizar=True)

    if camino:
        print("Camino encontrado con", len(camino), "pasos")
        # Dibujar el camino en la imagen
        img_color = cv2.cvtColor(binaria, cv2.COLOR_GRAY2BGR)
        for (x, y) in camino:
            cv2.rectangle(img_color, (x, y), (x+100, y+100), (0, 0, 255), 1)
        cv2.imwrite("resultado.png", img_color)
    else:
        print("No se encontró camino")
