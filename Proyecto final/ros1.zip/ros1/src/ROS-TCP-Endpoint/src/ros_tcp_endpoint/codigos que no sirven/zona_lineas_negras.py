#!/usr/bin/env python3
import rospy
import cv2
import numpy as np
from sensor_msgs.msg import CompressedImage
from cv_bridge import CvBridge

bridge = CvBridge()

def clamp_pt(pt, w, h):
    x = int(max(0, min(w-1, pt[0])))
    y = int(max(0, min(h-1, pt[1])))
    return (x, y)

def line_endpoints_from_fit(vx, vy, x0, y0, w, h):
    # devolvemos dos puntos (x,y) sobre el borde superior/inferior o izquierdo/derecho
    eps = 1e-6
    if abs(vy) > abs(vx) and abs(vy) > eps:
        # mejor intersectar con y=0 y y=h-1
        x_top = x0 + vx * (0 - y0) / vy
        x_bot = x0 + vx * ((h - 1) - y0) / vy
        p_top = clamp_pt((x_top, 0), w, h)
        p_bot = clamp_pt((x_bot, h - 1), w, h)
    elif abs(vx) > eps:
        # intersectar con x=0 y x=w-1
        y_left = y0 + vy * (0 - x0) / vx
        y_right = y0 + vy * ((w - 1) - x0) / vx
        p_top = clamp_pt((0, y_left), w, h)
        p_bot = clamp_pt((w - 1, y_right), w, h)
    else:
        # línea degenerada: usar punto y dirección para proyectar
        p_top = clamp_pt((x0 - vx * 1000, y0 - vy * 1000), w, h)
        p_bot = clamp_pt((x0 + vx * 1000, y0 + vy * 1000), w, h)
    return p_top, p_bot

def callback(msg):
    # convertir ROS -> OpenCV
    frame = bridge.compressed_imgmsg_to_cv2(msg, desired_encoding="bgr8")
    h, w = frame.shape[:2]

    # ===== parámetros que puedes ajustar =====
    lower_black = np.array([0, 0, 0])
    upper_black = np.array([180, 255, 60])   # si fallan líneas, intenta subir este V (ej 80)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (9,9))  # cerrar huecos
    min_contour_area = 200  # área mínima para considerar un contorno "línea"
    # ==========================================

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    mask_black = cv2.inRange(hsv, lower_black, upper_black)

    # limpieza morfológica para unir segmentos discontinuos
    mask_clean = cv2.morphologyEx(mask_black, cv2.MORPH_CLOSE, kernel)
    mask_clean = cv2.morphologyEx(mask_clean, cv2.MORPH_OPEN, kernel)

    # 1) intentar por contornos (si hay dos contornos grandes separados)
    contours, _ = cv2.findContours(mask_clean, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    large_cnts = [c for c in contours if cv2.contourArea(c) >= min_contour_area]
    large_cnts = sorted(large_cnts, key=cv2.contourArea, reverse=True)

    line_pts = []  # aquí guardaremos pares de puntos (p_top, p_bot) para dos líneas

    if len(large_cnts) >= 2:
        # Tenemos dos contornos grandes: ajustamos una línea a cada contorno
        for cnt in large_cnts[:2]:
            # fitLine para obtener dirección
            [vx, vy, x0, y0] = cv2.fitLine(cnt, cv2.DIST_L2, 0, 0.01, 0.01).flatten()
            p_top, p_bot = line_endpoints_from_fit(vx, vy, x0, y0, w, h)
            line_pts.append((p_top, p_bot))
        method_used = "contours"
    else:
        # 2) Fallback: proyección horizontal + kmeans para detectar dos columnas centrales
        proj = mask_clean.sum(axis=0).astype(np.float32)  # suma por columnas
        # suavizar la proyección para evitar picos débiles
        proj_smooth = cv2.GaussianBlur(proj.reshape(1, -1), (1, 21), 0).reshape(-1)

        # columnas con algo de presencia negra
        cols = np.where(proj_smooth > 5)[0]  # umbral pequeño
        method_used = "projection_kmeans"
        if len(cols) >= 2:
            # KMeans sobre las columnas para hallar 2 clusters (centros de línea)
            data = cols.reshape(-1,1).astype(np.float32)
            criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
            flags = cv2.KMEANS_PP_CENTERS
            try:
                compactness, labels, centers = cv2.kmeans(data, 2, None, criteria, 10, flags)
                centers = sorted([int(c[0]) for c in centers])
                # para cada centro construimos una línea vertical entre top y bottom
                for cx in centers:
                    p_top = clamp_pt((cx, 0), w, h)
                    p_bot = clamp_pt((cx, h-1), w, h)
                    line_pts.append((p_top, p_bot))
            except Exception as e:
                # si falla kmeans (raro), tomamos las dos columnas con mayor proyección
                idxs = np.argsort(proj_smooth)[-2:]
                centers = sorted(idxs)
                for cx in centers:
                    p_top = clamp_pt((cx, 0), w, h)
                    p_bot = clamp_pt((cx, h-1), w, h)
                    line_pts.append((p_top, p_bot))
        else:
            # No se detectan columnas suficientes: intentar HoughLinesP sobre bordes
            edges = cv2.Canny(mask_clean, 50, 150, apertureSize=3)
            lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=50, minLineLength=50, maxLineGap=20)
            if lines is not None and len(lines) >= 2:
                # agrupar por pendiente y quedarse con dos representantes
                slopes = []
                pts_lines = []
                for l in lines[:,0]:
                    x1,y1,x2,y2 = l
                    if x2==x1:
                        slope = 1e6
                    else:
                        slope = (y2-y1)/(x2-x1)
                    slopes.append(slope)
                    pts_lines.append(( (x1,y1), (x2,y2) ))
                # tomar las dos líneas más largas
                lengths = [np.hypot(x2-x1, y2-y1) for (x1,y1),(x2,y2) in pts_lines]
                idxs = np.argsort(lengths)[-2:]
                for i in idxs:
                    line_pts.append(pts_lines[i])
                method_used = "hough"
            else:
                method_used = "none"

    # Si hemos conseguido dos líneas, rellenamos polígono entre sus intersecciones
    mask_zone = np.zeros_like(mask_clean)
    info_text = ""
    if len(line_pts) >= 2:
        # Garantizar orden consistente: tomamos líneas l1,l2 y calculamos puntos top/bot
        (l1_top, l1_bot) = line_pts[0]
        (l2_top, l2_bot) = line_pts[1]

        # Construir polígono (p1_top, p2_top, p2_bot, p1_bot)
        poly = np.array([l1_top, l2_top, l2_bot, l1_bot], dtype=np.int32)
        # rellenar polígono en la máscara
        cv2.fillPoly(mask_zone, [poly], 255)

        # overlay visual
        overlay = frame.copy()
        cv2.fillPoly(overlay, [poly], (0, 200, 0))
        frame = cv2.addWeighted(frame, 0.7, overlay, 0.3, 0)

        # dibujar contornos/lineas detectadas
        cv2.line(frame, l1_top, l1_bot, (255,0,255), 3)
        cv2.line(frame, l2_top, l2_bot, (255,0,255), 3)

        info_text = "Zona detectada (metodo: {})".format(method_used)
    else:
        info_text = "No se encontraron 2 lineas (metodo: {})".format(method_used)

    # Dibujar texto y mostrar ventanas
    cv2.putText(frame, info_text, (10, h-10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 2)
    cv2.imshow("Original - Zona detectada", frame)
    cv2.imshow("Mascara negra (limpia)", mask_clean)
    cv2.imshow("Zona rellenada", mask_zone)

    # Mostrar la proyección para debug (opcional)
    proj_vis = np.zeros((100, w, 3), dtype=np.uint8)
    proj = mask_clean.sum(axis=0).astype(np.float32)
    maxv = proj.max() if proj.max() > 0 else 1.0
    for x in range(w):
        hbar = int((proj[x] / maxv) * (proj_vis.shape[0]-1))
        cv2.line(proj_vis, (x, proj_vis.shape[0]-1), (x, proj_vis.shape[0]-1 - hbar), (200,200,200))
    cv2.imshow("Proyeccion horizontal", proj_vis)

    cv2.waitKey(1)

def main():
    rospy.init_node("zona_entre_lineas_detector")
    rospy.Subscriber("/cenital", CompressedImage, callback)
    rospy.loginfo("Nodo iniciado: detectando zona entre 2 lineas negras en /cenital")
    rospy.spin()

if __name__ == "__main__":
    main()
