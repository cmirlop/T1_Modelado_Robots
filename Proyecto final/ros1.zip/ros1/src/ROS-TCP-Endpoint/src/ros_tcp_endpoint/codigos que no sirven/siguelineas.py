#!/usr/bin/env python
import rospy
import cv2
import numpy as np
from sensor_msgs.msg import CompressedImage
from geometry_msgs.msg import Twist

class LineFollowerBackwards:
    def __init__(self):
        rospy.init_node("line_follower_backwards", anonymous=True)

        # Publicador de comandos de velocidad
        self.cmd_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=1)

        # Subscriptor a la cámara
        rospy.Subscriber("/unity_camera/compressed", CompressedImage, self.image_callback)

        rospy.loginfo("Line follower (backwards) for GREEN line with RED stop signal started.")
        rospy.spin()

    def image_callback(self, msg):
        # Decodificar imagen
        np_arr = np.frombuffer(msg.data, np.uint8)
        image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

        # ---- Filtro para línea verde ----
        lower_green = np.array([40, 40, 40])
        upper_green = np.array([80, 255, 255])
        mask_green = cv2.inRange(hsv, lower_green, upper_green)

        # ---- Filtro para zona roja (fin del trayecto) ----
        lower_red1 = np.array([0, 120, 70])
        upper_red1 = np.array([10, 255, 255])
        lower_red2 = np.array([170, 120, 70])
        upper_red2 = np.array([180, 255, 255])
        mask_red = cv2.inRange(hsv, lower_red1, upper_red1) | cv2.inRange(hsv, lower_red2, upper_red2)

        twist = Twist()

        # ---- Si hay bastante rojo, detener robot ----
        red_area = cv2.countNonZero(mask_red)
        if red_area > 5000:
            rospy.loginfo("🔴 Red area detected (pixels=%d) → STOP" % red_area)
            self.cmd_pub.publish(Twist())  # publicar velocidad 0
        else:
            # Detectar línea verde
            contours, _ = cv2.findContours(mask_green, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            if contours:
                c = max(contours, key=cv2.contourArea)
                M = cv2.moments(c)
                if M["m00"] > 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])

                    # Dibujar centroide
                    cv2.circle(image, (cx, cy), 5, (0, 0, 255), -1)

                    # Error respecto al centro de la imagen
                    err = cx - image.shape[1] // 2

                    # Control proporcional para retroceso
                    twist.linear.x = -0.2  # retroceso
                    k_p = 0.003            # ajuste fino para giro
                    twist.angular.z = float(err) * k_p  # signo ajustado para retroceso

                    # Feedback en consola
                    rospy.loginfo("🟢 Green line detected at x=%d, error=%d → "
                                  "Publishing linear=%.2f angular=%.2f" %
                                  (cx, err, twist.linear.x, twist.angular.z))

                    self.cmd_pub.publish(twist)
            else:
                rospy.logwarn("⚠️ No green line detected! Stopping robot.")
                self.cmd_pub.publish(Twist())  # detener si pierde la línea

        # Mostrar para debug
        cv2.imshow("Camera", image)
        cv2.imshow("Green mask", mask_green)
        cv2.imshow("Red mask", mask_red)
        cv2.waitKey(1)

if __name__ == "__main__":
    try:
        LineFollowerBackwards()
    except rospy.ROSInterruptException:
        pass
    finally:
        cv2.destroyAllWindows()
