#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import Image,CompressedImage
from cv_bridge import CvBridge
import cv2
import json

# Variable global para almacenar la imagen
image_gray = None

def nothing(x):
    pass

def callback(msg):
    global image_gray
    bridge = CvBridge()
    cv_img = bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
    image_gray = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)


def cargar_zonas(filename="zonas.json"):
    """Cargar las zonas desde un JSON"""
    with open(filename, "r") as f:
        data = json.load(f)
    return tuple(data["zone1"]), tuple(data["zone2"]),tuple(data["robot1"])

if __name__ == "__main__":
    rospy.init_node("gray_image_viewer", anonymous=True)
    rospy.Subscriber("/cenital", CompressedImage, callback)
    zone1, zone2, robot1 = cargar_zonas("zonas_4_Esquinas.json")
    # Crear ventana y slider
    cv2.namedWindow("Escala de Grises")
    cv2.createTrackbar("Threshold", "Escala de Grises", 0, 255, nothing)

    rate = rospy.Rate(30)  # 30 Hz
    while not rospy.is_shutdown():
        if image_gray is not None:
            thresh_val = cv2.getTrackbarPos("Threshold", "Escala de Grises")
            _, thresh_img = cv2.threshold(image_gray, thresh_val, 255, cv2.THRESH_BINARY)
            cv2.imshow("Escala de Grises", thresh_img)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        rate.sleep()

    cv2.destroyAllWindows()
