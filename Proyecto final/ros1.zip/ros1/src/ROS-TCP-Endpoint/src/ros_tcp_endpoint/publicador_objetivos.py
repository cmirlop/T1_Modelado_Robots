#!/usr/bin/env python
import rospy
from std_msgs.msg import String
import json



def cargar_zonas(filename="zonas.json"):
    """Cargar las zonas desde un JSON"""
    with open(filename, "r") as f:
        data = json.load(f)
    return tuple(data["zone1"]), tuple(data["zone2"]),tuple(data["robot1"])


rospy.init_node('puntos_json_pub', anonymous=True)
rate = rospy.Rate(1)  # 1 Hz
zone1, zone2, robot1 = cargar_zonas("zonas_4_Esquinas.json")
pub = rospy.Publisher('/ruta', String, queue_size=10)
print(zone1,zone2)
puntos = [
            {"x": zone1[2][0], "y": zone1[2][1],"color":"azul"},
            {"x": zone2[2][0], "y": zone2[2][1],"color":"amarillo"}
            
        ]
while not rospy.is_shutdown():

        msg = json.dumps(puntos)
        rospy.loginfo("Publicando: %s", msg)
        pub.publish(msg)
        rate.sleep()


