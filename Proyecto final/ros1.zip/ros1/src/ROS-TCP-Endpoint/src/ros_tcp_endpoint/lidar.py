#!/usr/bin/env python3
import math
import rospy
from sensor_msgs.msg import LaserScan

TARGET_DEGS = [0.0, 90.0, -90.0, 180.0]

def angle_to_index(angle_rad, angle_min, angle_increment, count):
    # índice ideal redondeado
    i = int(round((angle_rad - angle_min) / angle_increment))
    # clamp a [0, count-1]
    if i < 0: i = 0
    if i >= count: i = count - 1
    return i

def fmt(v):
    # mostrar 'inf' si no hay retorno
    return "inf" if math.isinf(v) else f"{v:.3f} m"

def cb(msg: LaserScan):
    n = len(msg.ranges)
    if n == 0:
        rospy.loginfo("LaserScan vacío")
        return

    vals = {}
    for deg in TARGET_DEGS:
        # normaliza 180° → π (evita -π/+π ambigüedad)
        ang = math.radians(deg)
        if deg == 180.0:
            ang = math.pi
        idx = angle_to_index(ang, msg.angle_min, msg.angle_increment, n)
        r = msg.ranges[idx]
        # clamp a [range_min, range_max] si viene fuera
        if r < msg.range_min: r = msg.range_min
        if r > msg.range_max and not math.isinf(r): r = float('inf')
        vals[int(deg)] = r

    print(
        f"0°={fmt(vals[0])} | +90°={fmt(vals[90])} | -90°={fmt(vals[-90])} | 180°={fmt(vals[180])}"
    )

def main():
    rospy.init_node("lidar_angles_reader")
    rospy.Subscriber("/lidar", LaserScan, cb, queue_size=1)
    rospy.loginfo("Escuchando /lidar (0°, ±90°, 180°)")
    rospy.spin()

if __name__ == "__main__":
    main()
