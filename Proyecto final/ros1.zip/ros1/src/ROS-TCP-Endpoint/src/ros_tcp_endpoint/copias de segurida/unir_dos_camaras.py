#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import CompressedImage
import numpy as np
import cv2
from cv_bridge import CvBridge
from std_msgs.msg import Header

# ========= Globals =========
img_izq = None
img_der = None
bridge = CvBridge()
H_GLOBAL = None
SEAM_X = None  # corte vertical fijo

# BG subtractors
mog_left  = cv2.createBackgroundSubtractorMOG2(history=500, varThreshold=16, detectShadows=False)
mog_right = cv2.createBackgroundSubtractorMOG2(history=500, varThreshold=16, detectShadows=False)

# Estado para suavizado temporal del bbox del robot
prev_bbox = None   # (x1,y1,x2,y2)
ema_alpha = 0.4

# ========= Callbacks =========
def callback_izq(msg):
    global img_izq
    img_izq = bridge.compressed_imgmsg_to_cv2(msg, desired_encoding="bgr8")

def callback_der(msg):
    global img_der
    img_der = bridge.compressed_imgmsg_to_cv2(msg, desired_encoding="bgr8")

# ========= Homografía (una vez) =========
def compute_homography_once(img_left, img_right):
    g1 = cv2.cvtColor(img_left,  cv2.COLOR_BGR2GRAY)
    g2 = cv2.cvtColor(img_right, cv2.COLOR_BGR2GRAY)
    orb = cv2.ORB_create(nfeatures=3000)
    kp1, des1 = orb.detectAndCompute(g1, None)
    kp2, des2 = orb.detectAndCompute(g2, None)
    if des1 is None or des2 is None: return None
    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = sorted(bf.match(des1, des2), key=lambda m:m.distance)[:500]
    if len(matches) < 20: return None
    pts1 = np.float32([kp1[m.queryIdx].pt for m in matches]).reshape(-1,1,2)
    pts2 = np.float32([kp2[m.trainIdx].pt for m in matches]).reshape(-1,1,2)
    H, inl = cv2.findHomography(pts2, pts1, cv2.RANSAC, 3.0)
    if H is None or inl is None or inl.sum() < 15: return None
    return H

# ========= Canvas =========
def compose_canvas(img_left, img_right, H, canvas_extra=400):
    h1, w1 = img_left.shape[:2]
    width  = w1 + max(img_right.shape[1], canvas_extra)
    height = max(h1, img_right.shape[0])
    warped_right = cv2.warpPerspective(img_right, H, (width, height))
    canvas = np.zeros_like(warped_right)
    canvas[0:h1, 0:w1] = img_left
    return canvas, warped_right

# ========= Utilidades =========
def to_compressed_msg(img_bgr, fmt='.jpg'):
    ok, buf = cv2.imencode(fmt, img_bgr)
    msg = CompressedImage()
    msg.header = Header(stamp=rospy.Time.now(), frame_id="camera")
    msg.format = 'jpeg' if fmt=='.jpg' else 'png'
    msg.data = np.array(buf).tobytes()
    return msg

def clamp_bbox(x1,y1,x2,y2, W,H):
    x1 = max(0,min(W-1,x1)); x2 = max(0,min(W-1,x2))
    y1 = max(0,min(H-1,y1)); y2 = max(0,min(H-1,y2))
    if x2<x1: x1,x2 = x2,x1
    if y2<y1: y1,y2 = y2,y1
    return x1,y1,x2,y2

def expand_bbox(b, expand, W,H):
    x1,y1,x2,y2 = b
    return clamp_bbox(x1-expand, y1-expand, x2+expand, y2+expand, W,H)

def ema_bbox(prev, cur, alpha, W,H):
    if prev is None: return cur
    px1,py1,px2,py2 = prev
    cx1,cy1,cx2,cy2 = cur
    x1 = int(alpha*cx1 + (1-alpha)*px1)
    y1 = int(alpha*cy1 + (1-alpha)*py1)
    x2 = int(alpha*cx2 + (1-alpha)*px2)
    y2 = int(alpha*cy2 + (1-alpha)*py2)
    return clamp_bbox(x1,y1,x2,y2,W,H)

# ========= Detectar seam vertical óptimo (una vez) =========
def compute_static_vertical_seam(canvas, warped_right, search_px=120, band_px=5):
    """
    Busca un corte vertical (x) alrededor del borde de la izquierda que minimiza
    la diferencia |L-R| en una banda delgada (band_px). Devuelve SEAM_X.
    """
    h1, w1 = img_izq.shape[:2]
    Hc, Wc = canvas.shape[:2]

    # Solape válido (donde hay píxeles de derecha)
    right_valid = np.any(warped_right > 0, axis=2)
    # rango de búsqueda
    x_min = max(0, w1 - search_px)
    x_max = min(Wc-1, w1 + search_px)
    if x_max <= x_min + 2:
        return w1  # sin rango, corta justo al borde

    # asegúrate de no salirte
    best_x = w1
    best_cost = 1e18
    half = max(1, band_px//2)

    for x in range(x_min+half, x_max-half):
        # tomar banda vertical [x-half, x+half]
        l_band = canvas[:, x-half:x+half+1, :]
        r_band = warped_right[:, x-half:x+half+1, :]
        valid  = right_valid[:, x-half:x+half+1]

        if np.count_nonzero(valid) < 100:  # muy pocos píxeles válidos
            continue

        diff = cv2.absdiff(l_band, r_band)
        cost = float(np.sum(diff[valid]))
        # penaliza huecos inválidos para evitar pasar por zonas sin info
        cost += 1e6 * float(np.size(valid) - np.count_nonzero(valid))

        if cost < best_cost:
            best_cost = cost
            best_x = x

    return int(best_x)

# ========= Detección dinámica de robot + parche atómico =========
def detect_robot_bbox(img_left, img_right, H, canvas_shape, lr=0.02, dilate_px=15, min_area=400):
    Hc,Wc = canvas_shape[:2]

    # Primer plano por cámara
    fgL = mog_left.apply(img_left,  learningRate=lr)
    fgR = mog_right.apply(img_right, learningRate=lr)
    _, fgL = cv2.threshold(fgL, 200, 255, cv2.THRESH_BINARY)
    _, fgR = cv2.threshold(fgR, 200, 255, cv2.THRESH_BINARY)

    if dilate_px>0:
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2*dilate_px+1, 2*dilate_px+1))
        fgL = cv2.morphologyEx(fgL, cv2.MORPH_CLOSE, k)
        fgR = cv2.morphologyEx(fgR, cv2.MORPH_CLOSE, k)

    # Llevar derecha al canvas
    fgR_canvas = cv2.warpPerspective(fgR, H, (Wc,Hc))
    # Izquierda en su ROI
    fgL_canvas = np.zeros((Hc,Wc), dtype=np.uint8)
    h1,w1 = img_left.shape[:2]
    fgL_canvas[0:h1, 0:w1] = fgL

    # Unión de primer plano
    fg_union = cv2.bitwise_or(fgL_canvas, fgR_canvas)
    cnts,_ = cv2.findContours(fg_union, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts: return None, fgL_canvas, fgR_canvas
    c = max(cnts, key=cv2.contourArea)
    if cv2.contourArea(c) < min_area: return None, fgL_canvas, fgR_canvas
    x,y,w,h = cv2.boundingRect(c)
    return (x,y,x+w,y+h), fgL_canvas, fgR_canvas

def choose_source_for_bbox(bbox, fgL_canvas, fgR_canvas):
    x1,y1,x2,y2 = bbox
    sumL = int(fgL_canvas[y1:y2, x1:x2].sum())
    sumR = int(fgR_canvas[y1:y2, x1:x2].sum())
    # elegimos la cámara con MENOS primer plano (más fondo);
    # en empate, preferimos derecha (para “borrar” robot de la izq).
    if sumR*0.9 <= sumL:
        return 'R'
    else:
        return 'L'

# ========= Imagen base con corte duro en SEAM_X =========
def hard_cut_with_fixed_seam(canvas, warped_right, seam_x, clean_kernel=3, seam_margin_px=2):
    Hc, Wc = canvas.shape[:2]
    h1, w1 = img_izq.shape[:2]

    # válidos en derecha
    right_valid = np.any(warped_right > 0, axis=2).astype(np.uint8)
    if clean_kernel and clean_kernel >= 3 and clean_kernel % 2 == 1:
        k = cv2.getStructuringElement(cv2.MORPH_RECT, (clean_kernel, clean_kernel))
        right_valid = cv2.erode(right_valid, k)

    # por defecto: izquierda
    out = canvas.copy()

    # usar derecha solo a partir del seam fijo (margen a la derecha)
    cut_x = min(Wc, int(seam_x) + max(0, seam_margin_px))
    use_right = np.zeros((Hc,Wc), dtype=bool)
    use_right[:, cut_x:] = True
    use_right = use_right & (right_valid == 1)

    out[use_right] = warped_right[use_right]
    return out

# ========= Main =========
def main():
    global H_GLOBAL, SEAM_X, prev_bbox, ema_alpha
    rospy.init_node('fusionador_cenital', anonymous=True)

    # Parámetros
    seam_search_px = rospy.get_param("~seam_search_px", 120)  # rango de búsqueda del seam
    seam_band_px   = rospy.get_param("~seam_band_px", 5)      # ancho banda para coste
    seam_margin_px = rospy.get_param("~seam_margin_px", 2)    # empuja el corte un pelín a la dcha
    clean_kernel   = rospy.get_param("~clean_kernel", 3)

    fg_lr          = rospy.get_param("~fg_learning_rate", 0.02)
    fg_dilate_px   = rospy.get_param("~fg_dilate_px", 15)
    bbox_expand_px = rospy.get_param("~bbox_expand_px", 60)
    ema_alpha      = rospy.get_param("~bbox_ema_alpha", 0.4)

    rospy.Subscriber("/cenital_izq", CompressedImage, callback_izq)
    rospy.Subscriber("/cenital_der", CompressedImage, callback_der)
    pub = rospy.Publisher("/cenital", CompressedImage, queue_size=1)

    rate = rospy.Rate(30)
    # Esperar imágenes
    while not rospy.is_shutdown() and (img_izq is None or img_der is None):
        rospy.loginfo_throttle(2.0, "Esperando imágenes…")
        rate.sleep()

    # Homografía fija
    while not rospy.is_shutdown() and H_GLOBAL is None:
        H_GLOBAL = compute_homography_once(img_izq, img_der)
        if H_GLOBAL is None:
            rospy.logwarn_throttle(2.0, "Aún sin H válida; reintentando…")
            rate.sleep()

    # Calcular seam fijo una sola vez (con el frame actual)
    canvas, warped_right = compose_canvas(img_izq, img_der, H_GLOBAL)
    if SEAM_X is None:
        SEAM_X = compute_static_vertical_seam(canvas, warped_right,
                                              search_px=seam_search_px,
                                              band_px=seam_band_px)
        rospy.loginfo("SEAM_X fijado en x=%d", SEAM_X)

    rospy.loginfo("H fija y seam fijo OK. Ejecutando…")
    while not rospy.is_shutdown():
        if img_izq is None or img_der is None:
            rate.sleep(); continue

        canvas, warped_right = compose_canvas(img_izq, img_der, H_GLOBAL)

        # 1) base con seam fijo
        out = hard_cut_with_fixed_seam(canvas, warped_right, SEAM_X,
                                       clean_kernel=clean_kernel,
                                       seam_margin_px=seam_margin_px)

        # 2) detectar robot y pegar un parche atómico de UNA cámara
        Hc,Wc = out.shape[:2]
        bbox, fgL_canvas, fgR_canvas = detect_robot_bbox(
            img_izq, img_der, H_GLOBAL, out.shape,
            lr=fg_lr, dilate_px=fg_dilate_px, min_area=400
        )

        if bbox is not None:
            bbox = expand_bbox(bbox, bbox_expand_px, Wc, Hc)
            prev_bbox = ema_bbox(prev_bbox, bbox, ema_alpha, Wc, Hc)
            bx1,by1,bx2,by2 = prev_bbox

            src = choose_source_for_bbox(prev_bbox, fgL_canvas, fgR_canvas)

            if src == 'R':
                # Parche derecho: warpeado desde la imagen original derecha (sin recortar directo)
                H_INV = np.linalg.inv(H_GLOBAL)
                patch_size = (bx2 - bx1, by2 - by1)

                # Coordenadas del bbox en canvas
                pts_canvas = np.float32([[bx1, by1], [bx2, by1], [bx2, by2], [bx1, by2]]).reshape(-1, 1, 2)
                # Proyectar al espacio de la imagen derecha
                pts_right = cv2.perspectiveTransform(pts_canvas, H_INV)
                x_min, y_min = np.int32(pts_right.min(axis=0).ravel() - 0.5)
                x_max, y_max = np.int32(pts_right.max(axis=0).ravel() + 0.5)

                # Recorta esa región en la derecha original (clamp)
                x_min = max(0, x_min)
                y_min = max(0, y_min)
                x_max = min(img_der.shape[1]-1, x_max)
                y_max = min(img_der.shape[0]-1, y_max)

                roi_right = img_der[y_min:y_max, x_min:x_max]

                # Warpear el parche recortado al canvas
                H_local = np.eye(3)
                H_local[:2, 2] = [bx1 - x_min, by1 - y_min]  # traslación local
                patch = cv2.warpPerspective(roi_right, H_GLOBAL @ H_local, patch_size)

                valid = np.any(patch > 10, axis=2)
                if np.any(valid):
                    out_patch = out[by1:by2, bx1:bx2]
                    out_patch[valid] = patch[valid]
                    out[by1:by2, bx1:bx2] = out_patch
            else:  # 'L'
                left_only = np.zeros_like(canvas)
                h1,w1 = img_izq.shape[:2]
                left_only[0:h1, 0:w1] = img_izq
                patch = left_only[by1:by2, bx1:bx2]
                valid = np.any(patch > 10, axis=2)
                if np.any(valid):
                    out_patch = out[by1:by2, bx1:bx2]
                    out_patch[valid] = patch[valid]
                    out[by1:by2, bx1:bx2] = out_patch

        pub.publish(to_compressed_msg(out, fmt='.jpg'))

        # Debug opcional:
        cv2.imshow("mosaico", out)
        if cv2.waitKey(1) & 0xFF == ord('q'): break

        rate.sleep()

    cv2.destroyAllWindows()
    rospy.spin()

if __name__ == "__main__":
    main()
