#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import CompressedImage
import numpy as np
import cv2
from cv_bridge import CvBridge
import time
from std_msgs.msg import Header

# Variables globales para las imágenes
img_izq = None
img_der = None

bridge = CvBridge()

def callback_izq(msg):
    global img_izq
    img_izq = bridge.compressed_imgmsg_to_cv2(msg, desired_encoding="bgr8")



def callback_der(msg):
    global img_der
    try:
        img_der = bridge.compressed_imgmsg_to_cv2(msg, desired_encoding="bgr8")
        if img_der is None:
            rospy.logwarn("img_der es None")
    except Exception as e:
        rospy.logerr(f"Error al convertir img_der: {e}")



def mz_sift_stitch_blend(img_izq, img_der, nfeatures=5000):
    # Convertir a gris y mejorar contraste
    img1_gray = cv2.cvtColor(img_izq, cv2.COLOR_BGR2GRAY)
    img2_gray = cv2.cvtColor(img_der, cv2.COLOR_BGR2GRAY)
    img1_gray = cv2.equalizeHist(img1_gray)
    img2_gray = cv2.equalizeHist(img2_gray)

    # Detector SIFT
    sift = cv2.SIFT_create(nfeatures=nfeatures)
    kp1, des1 = sift.detectAndCompute(img1_gray, None)
    kp2, des2 = sift.detectAndCompute(img2_gray, None)

    # Matcher FLANN + ratio test
    FLANN_INDEX_KDTREE = 1
    index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
    search_params = dict(checks=50)
    flann = cv2.FlannBasedMatcher(index_params, search_params)

    matches = flann.knnMatch(des1, des2, k=2)
    good_matches = []
    for m, n in matches:
        if m.distance < 0.75 * n.distance:
            good_matches.append(m)

    if len(good_matches) < 4:
        print("No hay suficientes matches fiables, devolviendo concatenación simple.")
        alto_min = min(img_izq.shape[0], img_der.shape[0])
        img_izq_resized = cv2.resize(img_izq, (int(img_izq.shape[1]*alto_min/img_izq.shape[0]), alto_min))
        img_der_resized = cv2.resize(img_der, (int(img_der.shape[1]*alto_min/img_der.shape[0]), alto_min))
        imagen_unida = np.hstack((img_izq_resized, img_der_resized))
        return imagen_unida, imagen_unida, good_matches

    # Homografía con RANSAC
    src_pts = np.float32([kp1[m.queryIdx].pt for m in good_matches]).reshape(-1,1,2)
    dst_pts = np.float32([kp2[m.trainIdx].pt for m in good_matches]).reshape(-1,1,2)
    M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
    inliers = [good_matches[i] for i in range(len(good_matches)) if mask[i]]

    # Calcular tamaño del lienzo
    h1, w1 = img_izq.shape[:2]
    h2, w2 = img_der.shape[:2]
    pts_img1 = np.float32([[0,0],[0,h1],[w1,h1],[w1,0]]).reshape(-1,1,2)
    pts_img1_trans = cv2.perspectiveTransform(pts_img1, M)
    pts_img2 = np.float32([[0,0],[0,h2],[w2,h2],[w2,0]]).reshape(-1,1,2)
    pts = np.concatenate((pts_img1_trans, pts_img2), axis=0)
    [x_min, y_min] = np.int32(pts.min(axis=0).ravel() - 0.5)
    [x_max, y_max] = np.int32(pts.max(axis=0).ravel() + 0.5)
    offset = [-x_min, -y_min]
    nuevo_ancho = x_max - x_min
    nuevo_alto = y_max - y_min

    # Warp de la izquierda
    T = np.array([[1, 0, offset[0]], [0, 1, offset[1]], [0,0,1]])
    result = cv2.warpPerspective(img_izq, T @ M, (nuevo_ancho, nuevo_alto))

    # Blending: pegar la derecha sin sobrescribir la izquierda
    mask_der = np.zeros((nuevo_alto, nuevo_ancho, 3), dtype=np.uint8)
    mask_der[offset[1]:h2+offset[1], offset[0]:w2+offset[0]] = img_der
    # Mezcla simple: si el pixel en result está vacío (negro), poner el de img_der
    mask = np.all(result == 0, axis=2)
    result[mask] = mask_der[mask]

    # Dibujar matches filtrados
    inliers_sorted = sorted(inliers, key=lambda x: x.distance)[:50]
    img_matches = cv2.drawMatches(img_izq, kp1, img_der, kp2, inliers_sorted, None,
                                  flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)

    return result, img_matches


def g(img1,img2):
    # Convierte a escala de grises
    gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

    # Detecta características y descriptores con ORB
    orb = cv2.ORB_create()
    kp1, des1 = orb.detectAndCompute(gray1, None)
    kp2, des2 = orb.detectAndCompute(gray2, None)

    # Empareja puntos entre ambas imágenes
    matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = matcher.match(des1, des2)
    matches = sorted(matches, key=lambda x: x.distance)

    # Usa los mejores emparejamientos para calcular la homografía
    pts1 = np.float32([kp1[m.queryIdx].pt for m in matches]).reshape(-1, 1, 2)
    pts2 = np.float32([kp2[m.trainIdx].pt for m in matches]).reshape(-1, 1, 2)
    H, mask = cv2.findHomography(pts2, pts1, cv2.RANSAC)

    # Une las imágenes
    result = cv2.warpPerspective(img2, H, (img1.shape[1] + img2.shape[1], img1.shape[0]))
    result[0:img1.shape[0], 0:img1.shape[1]] = img1
    return result

def to_compressed_msg(img_bgr, fmt='.jpg'):
    # fmt puede ser '.jpg' o '.png'
    ok, buf = cv2.imencode(fmt, img_bgr)
    if not ok:
        raise RuntimeError('Fallo al comprimir la imagen')
    msg = CompressedImage()
    msg.header = Header()
    msg.header.stamp = rospy.Time.now()
    msg.header.frame_id = "camera"  # opcional: ajusta si necesitas un frame
    msg.format = 'jpeg' if fmt == '.jpg' else 'png'
    msg.data = np.array(buf).tobytes()
    return msg


def main():
    rospy.init_node('fusionador_cenital', anonymous=True)
    rospy.Subscriber("/cenital_izq", CompressedImage, callback_izq)
    rospy.Subscriber("/cenital_der", CompressedImage, callback_der)
    pub = rospy.Publisher("/cenital",CompressedImage, queue_size=1)
    rospy.loginfo("Esperando imágenes de /cenital_izq y /cenital_der ...")
    while img_izq is None or img_der is  None:
        if img_izq is None : print("img izq none")
        if img_der is None : print("img der none")
        
    print("Roto")
    while img_izq is not None and img_der is not None:
        # Ajustar a la misma altura mínima
        #img1_warped,img_matches  = mz_sift_stitch_blend(img_izq,img_der)
        ih = g(img_izq,img_der)
        #cv2.imshow("Imagen izq", img_izq)
        #cv2.imshow("Imagen der", img_der)
        cv2.imshow("Imager", ih)
        msg = to_compressed_msg(ih, fmt='.jpg')
        pub.publish(msg)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    rospy.spin()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
