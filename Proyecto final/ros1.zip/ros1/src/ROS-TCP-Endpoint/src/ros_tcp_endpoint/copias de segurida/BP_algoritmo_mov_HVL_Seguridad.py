import cv2
import numpy as np
import json
import time
import math
import heapq

#---- Este codigo por ahora encuentra un camino que sea en horizontal

frame_global = None


# ----------------------
# Funciones auxiliares
# ----------------------
def es_blanca(region):
    """Verifica si toda la región es blanca (valor 255 en una imagen binaria)."""
    print(np.mean(region))
    if np.mean(region) < 250:
        print("No es blanco")
        return False
    return True

def crear_rectangulo_rotado(cx, cy, size, angulo):
    rect = ((cx, cy), (size, size), angulo)
    return rect     

def es_blanca_rotada(img, rect ):
    
    box = cv2.boxPoints(rect)
    box = box.astype(int)

    mask = np.zeros_like(img, dtype=np.uint8)
    cv2.fillPoly(mask, [box], 255)

    inside = cv2.bitwise_and(img, mask)
    return np.all(inside[mask == 255] == 255)


def calcular_distancia(objetivo, centro):
    """
    Comprueba si el objetivo está a una distancia menor o igual
    que 'umbral' del centro del rectángulo.
    """
    px, py = objetivo
    cx, cy = centro

    # distancia euclidiana
    dist = math.sqrt((px - cx) ** 2 + (py - cy) ** 2)
    return dist

def comprobar_distancia(dist,umbral):
    if dist <= umbral:
        print(f"✅ El objetivo está dentro del rango (distancia={dist:.2f})")
        return True
    else:
        print(f"❌ El objetivo está fuera del rango (distancia={dist:.2f})")
        return False



def mov_horizontal(img,nx,ny,w_r,high_r,w,h,ang):
    x1 = nx - w_r // 2
    y1 = ny - high_r // 2
    x2 = nx + w_r // 2
    y2 = ny + high_r // 2
    region = img[y1:y2, x1:x2]
    coor_region = ((nx,ny),(w_r,high_r),ang)
    return region,coor_region, True


"""def mov_vertical(img,nx,ny,w_r,high_r,w,h,ang):
    x1 = nx - high_r // 2
    y1 = ny - w_r // 2
    x2 = nx + high_r // 2
    y2 = ny + w_r // 2
    region = img[y1:y2, x1:x2]
    coor_region = ((nx,ny),(high_r,w_r),ang)
    return region,coor_region, True"""
def mov_vertical_diagonal(img, nx, ny, w_r, h_r, w, h, ang=90):
    rect = ((nx, ny), (w_r, h_r), ang)  # centro, (ancho, alto), ángulo
    box = cv2.boxPoints(rect).astype(int)

    mask = np.zeros_like(img, dtype=np.uint8)
    cv2.fillPoly(mask, [box], 255)

    region = cv2.bitwise_and(img, mask)
    return region, rect, True
    


def movimientos_validos(img, x, y, size, visitado,objetivo,pixeles):
    global frame_global
    """Genera posiciones vecinas válidas."""
    w_r ,high_r = size #Anchura y altura del robot
    h, w = img.shape[:2] #Altura y anchura de la imageb

    #El robot se puede mover en horizontal, en vertical, o en diagonal
    acciones_posibles = ["Horizontal","Vertical","Diagonal"]
    """posibles = [(x+pixeles, y), (x-pixeles, y), (x, y+pixeles), (x, y-pixeles),
                (x+pixeles,y+pixeles),(x-pixeles,y+pixeles),
                (x+pixeles,y-pixeles),(x-pixeles,y-pixeles)]"""
    posibles_hor = [(x+pixeles, y,0), (x-pixeles, y,0)]
    posibless_ver = [(x, y+pixeles,-90), (x, y-pixeles,90)]
    #Comprobar los movimientos siguientes
    posibles_incli = [(x+pixeles,y+pixeles,45),(x-pixeles,y+pixeles,135),
                (x+pixeles,y-pixeles,-45),(x-pixeles,y-pixeles,-135)]
    
    #Acciones validas
    validos = []
    #print("Tamaño del robot")
    #print(size)
    posi,region,coor_region,mov_valido = None,None,None, False

    #Bucle que recorre todas las acciones que puede hacer el robot
    for acciones in acciones_posibles:
        print(acciones)
        #Depende de que accion escogamos del for, escogeremos un conjunto y otro de acciones posibles
        if acciones == "Horizontal": posi = posibles_hor
        elif acciones == "Vertical" : posi = posibless_ver
        elif acciones == "Diagonal" : posi = posibles_incli

        #Bucle que comprueba coordenada a coordenada, todas las acciones posibles
        for nx, ny ,ang in posi:
            print("Coordenadas a probar")
            print((nx,ny)),print((w-w_r,h-high_r)),print(ang)
            #if 0 <= nx < w-(w_r/2) and 0 <= ny < h-(high_r/2) and not visitado[ny, nx]:
            if ((nx - w_r//2 >= 0 and nx + w_r//2 < w and ny - high_r//2 >= 0 and ny + high_r//2 < h ) 
                and acciones == "Horizontal" and not visitado[ny, nx]):
                region, coor_region, mov_valido =  mov_horizontal(img,nx,ny,w_r,high_r,w,h,ang)

            elif ((nx - high_r//2 >= 0 and nx + high_r//2 < w and ny - w_r//2 >= 0 and ny + w_r//2 < h ) 
                and acciones == "Vertical" and not visitado[ny, nx]):
                region, coor_region, mov_valido =  mov_vertical_diagonal(img,nx,ny,w_r,high_r,w,h,ang)
            elif (acciones == "Diagonal" and not visitado[ny, nx]):
                rect = ((nx, ny), (w_r, high_r), ang)   # rectángulo rotado
                box = cv2.boxPoints(rect).astype(int)
                # Comprobar que todas las esquinas del rectángulo están dentro de la imagen
                if (box[:,0] >= 0).all() and (box[:,0] < w).all() and \
                (box[:,1] >= 0).all() and (box[:,1] < h).all():
                    region, coor_region, mov_valido = mov_vertical_diagonal(img, nx, ny, w_r, high_r, w, h, ang)
            else:
                mov_valido = False
                print("Movimiento no valido")
                #print("Coordenadas:"),print(nx - w_r//2 >= 0),print(nx + w_r//2 < w),print(ny - high_r//2 >= 0)
                #print(ny + high_r//2 < h),print(acciones),print(visitado[ny, nx])
                #time.sleep(10)

            if  mov_valido :
                print(coor_region)
                box = cv2.boxPoints(coor_region)   # devuelve 4 puntos flotantes
                box = box.astype(int)
                cv2.polylines(frame_global, [box], isClosed=True, color=(0, 255, 0), thickness=2)
                cv2.imshow("Rectangulo rotado", frame_global)

                cv2.imshow("DFS progresoss", region)
                print(coor_region)
                # espera 300 ms en lugar de 3000 ms, y repite muchos pasos
                if cv2.waitKey(300) & 0xFF == 27:  # si presionas ESC, se sale
                    break
                #time.sleep(1)

                dist = calcular_distancia(objetivo,(nx,ny))

                if comprobar_distancia(dist,50):
                    print("OBJETIVO ENC Objetivo encontrado")
                    validos.append((nx, ny,ang,dist))
                    return validos
                    break
                elif es_blanca(region) and acciones == "Horizontal" :
                   print("Movimiento valido horizontal")
                   validos.append((nx, ny,ang,dist))
                elif es_blanca_rotada(region,coor_region) and acciones != "Horizontal" : # and acciones == "Diagonal":
                    print("Movimiento valido: ", acciones)
                    validos.append((nx, ny,ang,dist))
                else:
                    print("No es blanco, ni objetivo")
    print(validos)
    return validos

def busqueda_prioridad(img, inicio, objetivo, size=50):
    global frame_global
    h, w = img.shape[:2]
    visitado = np.zeros((h, w), dtype=bool)

    # Cola de prioridad (distancia, (x, y), camino)
    cola = []
    heapq.heappush(cola, (0, inicio, [inicio]))

    img_color = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR) #GRAY2BGR sin utilizar el codigo de Mover_torito
    while cola:
        _, (x, y,ang,d), camino = heapq.heappop(cola)

        if visitado[y, x]:
            continue
        visitado[y, x] = True

        # ¿Se alcanzó el objetivo?
        w_r, h_r = size
        """radio = ((w_r ** 2 + h_r ** 2) ** 0.5) / 2
        print("radio",radio)"""
        if calcular_distancia( (x, y),objetivo) <= 15:
            return camino

        temp = img_color.copy()
        frame_global = temp

        # Explorar vecinos
        for vecino in movimientos_validos(img, x, y, size, visitado, objetivo, 10):
            (nx, ny, ang, d) = vecino
            d = calcular_distancia(objetivo,(nx, ny))
            heapq.heappush(cola, (d, (nx, ny,ang, d), camino + [(nx, ny,ang,d)]))

    return None  # No hay camino

#----Funcion que carga de un JSON las zonas a donde tiene 
# que ir el robot
def cargar_zonas(filename="zonas.json"):
    """Cargar las zonas desde un JSON"""
    with open(filename, "r") as f:
        data = json.load(f)
    return tuple(data["zone1"]), tuple(data["zone2"]), tuple(data["robot1"])

# ----------------------
# Ejemplo de uso
# ----------------------

def main():
    # Cargar imagen en escala de grises
    zone1, zone2, robot1 = cargar_zonas("zonas_4_Esquinas.json")
    img = cv2.imread("mask.png", cv2.IMREAD_GRAYSCALE)
    mask_copy = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    #cv2.rectangle(mask_copy, robot1[0], robot1[1], (0, 155, 155), -1)
    #cv2.rectangle(mask_copy, zone1[0], zone1[1], (255, 0, 0), -1)
    cv2.circle(mask_copy, zone1[2], 6, (255, 0, 0), -1)
    #cv2.circle(mask_copy, robot1[0], 1, (255, 0, 0), -1)
    
    mask_copy = cv2.cvtColor(mask_copy, cv2.COLOR_BGR2GRAY)
    # Binarizar: píxeles blancos = 255, obstáculos = 0
    _, binaria = cv2.threshold(mask_copy, 200, 255, cv2.THRESH_BINARY)

    size = (robot1[1][0] - robot1[0][0] , robot1[1][1] - robot1[0][1])
    
    (j,k) = zone2[2]      # Centro                       
    objetivo_cen = zone1[2]     # Centro
    inicio = zone2[0]      # esquina superior izq del rectángulo inicial
    objetivo = zone1[0]     # esquina sup izq del rectángulo objetivo

    #camino = dfs(binaria, inicio, objetivo,(j,k,0), objetivo_cen, size, visualizar=True)
    camino =  busqueda_prioridad(img, (j,k,0,math.inf), objetivo_cen, size)

    if camino:
        print("Objetivo:",objetivo_cen,"Camino encontrado con", len(camino), "pasos",camino)
        # Dibujar el camino en la imagen
        img_color = cv2.cvtColor(binaria, cv2.COLOR_GRAY2BGR)
        for (x, y,ang,d) in camino:
            cv2.rectangle(img_color, (x, y), (x+100, y+100), (0, 0, 255), 1)
        cv2.imwrite("resultado.png", img_color)
    else:
        print("No se encontró camino")


if __name__ == "__main__":
    main()
    
