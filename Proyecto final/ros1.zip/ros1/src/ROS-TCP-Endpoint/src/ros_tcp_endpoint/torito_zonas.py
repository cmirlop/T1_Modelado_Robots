#!/usr/bin/env python3
import rospy
import cv2
import json
import math
import numpy as np
from sensor_msgs.msg import CompressedImage
from cv_bridge import CvBridge
from geometry_msgs.msg import Twist

bridge = CvBridge()
cmd_pub = None
prev_dist = None

state = "zone1"
zone1, zone2 = None, None

def cargar_zonas(filename="zonas.json"):
    """Cargar las zonas desde un JSON"""
    with open(filename, "r") as f:
        data = json.load(f)
    return tuple(data["zone1"]), tuple(data["zone2"])

def get_centroid(mask):
    M = cv2.moments(mask)
    if M["m00"] > 0:
        cx = int(M["m10"]/M["m00"])
        cy = int(M["m01"]/M["m00"])
        return (cx, cy)
    return None

def callback(msg):
    global cmd_pub, prev_dist, state, zone1, zone2
    frame = bridge.compressed_imgmsg_to_cv2(msg, desired_encoding="bgr8")
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # --- Verde ---
    lower_green = np.array([40, 50, 50])
    upper_green = np.array([80, 255, 255])
    mask_green = cv2.inRange(hsv, lower_green, upper_green)

    # --- Rojo ---
    lower_red1 = np.array([0, 100, 100])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([160, 100, 100])
    upper_red2 = np.array([179, 255, 255])
    mask_red = cv2.inRange(hsv, lower_red1, upper_red1) | cv2.inRange(hsv, lower_red2, upper_red2)

    green_centroid = get_centroid(mask_green)
    red_centroid   = get_centroid(mask_red)

    twist = Twist()

    if green_centroid and red_centroid:
        # Dibujar orientación (rojo -> verde)
        cv2.arrowedLine(frame, red_centroid, green_centroid, (255, 0, 0), 3, tipLength=0.3)

        # Selección de target
        if state == "zone1":
            target = zone1
            cv2.circle(frame, target, 6, (255, 0, 0), -1)
        elif state == "zone2":
            target = zone2
            cv2.circle(frame, target, 6, (0, 255, 255), -1)
        else:
            target = None

        if target:
            # Vector orientación (rojo → verde)
            dir_vec = (green_centroid[0] - red_centroid[0],
                       green_centroid[1] - red_centroid[1])
            # Vector hacia objetivo
            goal_vec = (target[0] - red_centroid[0],
                        target[1] - red_centroid[1])

            dot = dir_vec[0]*goal_vec[0] + dir_vec[1]*goal_vec[1]
            norm_dir = math.sqrt(dir_vec[0]**2 + dir_vec[1]**2)
            norm_goal = math.sqrt(goal_vec[0]**2 + goal_vec[1]**2)
            dist = norm_goal

            if norm_dir > 0 and norm_goal > 0:
                cos_angle = dot / (norm_dir * norm_goal)
                cos_angle = max(-1.0, min(1.0, cos_angle))
                angle = math.acos(cos_angle)
                cross = dir_vec[0]*goal_vec[1] - dir_vec[1]*goal_vec[0]

                if abs(angle) < 0.2:  # alineado
                    if prev_dist is not None and dist > prev_dist:
                        twist.linear.x = -0.2
                    else:
                        twist.linear.x = 0.2
                else:
                    twist.angular.z = 0.3 if cross > 0 else -0.3

            prev_dist = dist

            # Llegada
            if dist < 50:
                if state == "zone1":
                    rospy.loginfo("✅ Llegamos a ZONA 1, yendo a ZONA 2")
                    state = "zone2"
                    prev_dist = None
                elif state == "zone2":
                    rospy.loginfo("🏁 Llegamos a ZONA 2, misión completada")
                    state = "done"

    if state == "done":
        twist = Twist()

    cmd_pub.publish(twist)
    cv2.imshow("Torito con zonas", frame)
    cv2.waitKey(1)

def main():
    global cmd_pub, zone1, zone2
    rospy.init_node("torito_zonas")
    zone1, zone2 = cargar_zonas("zonas.json")
    rospy.loginfo(f"Zonas cargadas: Z1={zone1}, Z2={zone2}")
    rospy.Subscriber("/cenital", CompressedImage, callback)
    cmd_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=1)
    rospy.spin()

if __name__ == "__main__":
    main()
