import rospy

from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv , VecMonitor # seguimos con DummyVecEnv
import numpy as np
from reinforce_Keras_4 import RobotMazeEnvPPO

from stable_baselines3.common.callbacks import BaseCallback, CheckpointCallback, CallbackList
import time
N_ENVS = 8  # número de robots / entornos

class EarlyStoppingNoImprovement(BaseCallback):
    """
    Para el entrenamiento cuando la recompensa media de los últimos N episodios
    deja de mejorar durante `patience` evaluaciones seguidas.

    Usa info["episode"]["r"] que añade VecMonitor/Monitor.
    """
    def __init__(self, n_episodes: int = 50, patience: int = 5, min_delta: float = 0.0, verbose: int = 1):
        """
        :param n_episodes: nº de episodios usados para calcular la media (ventana).
        :param patience: nº de veces consecutivas que permitimos "no mejora".
        :param min_delta: mejora mínima para considerar que ha mejorado (por ruido).
        """
        super().__init__(verbose)
        self.n_episodes = n_episodes
        self.patience = patience
        self.min_delta = min_delta
        self.ep_rewards = []
        self.best_mean = -np.inf
        self.no_improve_count = 0

    def _on_step(self) -> bool:
        infos = self.locals.get("infos", [])

        # 1) Recoger rewards de episodios que terminan
        for info in infos:
            if "episode" in info.keys():
                ep_rew = info["episode"]["r"]
                self.ep_rewards.append(ep_rew)
                if self.verbose:
                    print(f"[EarlyStop] Episodio terminado con reward = {ep_rew:.2f}")

        # 2) Cuando tenemos suficientes episodios, miramos la media de la ventana
        if len(self.ep_rewards) >= self.n_episodes:
            window = self.ep_rewards[-self.n_episodes:]
            mean_rew = float(np.mean(window))

            if self.verbose:
                print(
                    f"[EarlyStop] Media últimos {self.n_episodes} episodios = {mean_rew:.2f} "
                    f"(best_mean = {self.best_mean:.2f}, no_improve = {self.no_improve_count})"
                )

            # ¿Ha mejorado lo suficiente?
            if mean_rew > self.best_mean + self.min_delta:
                self.best_mean = mean_rew
                self.no_improve_count = 0
            else:
                self.no_improve_count += 1

            # 3) Si llevamos demasiadas evaluaciones sin mejora, paramos
            if self.no_improve_count >= self.patience:
                if self.verbose:
                    print(
                        f"[EarlyStop] Sin mejora en {self.no_improve_count} evaluaciones, "
                        f"parando entrenamiento. best_mean = {self.best_mean:.2f}"
                    )
                self.model._stop_training = True
                return False

        return True


def make_env(agent_id):
    def _init():
        # Cada entorno usa un agent_id distinto -> topics distintos
        return RobotMazeEnvPPO(agent_id=str(agent_id))
    return _init


if __name__ == "__main__":
    rospy.init_node("ppo_robot_maze_training", anonymous=False)

    # Creamos entornos
    env_fns = [make_env(i) for i in range(N_ENVS)]
    env = DummyVecEnv(env_fns)
    env = VecMonitor(env)

    # Ajustamos n_steps pensando que ahora hay 8 entornos
    # Total muestras por update = n_steps * N_ENVS
    model = PPO(
        "MlpPolicy",
        env,
        verbose=1,
        n_steps=256,       # 256 * 8 = 2048 pasos por actualización (típico en PPO)
        batch_size=16,
        gamma=0.99,
        learning_rate=2e-4,
        clip_range=0.2,
        tensorboard_log="./ppo_maze_tb/",
    )

   
    
    checkpoint_callback = CheckpointCallback(
    save_freq=500,                  # cada 500 pasos de entrenamiento
    save_path="./checkpoints/",        # carpeta donde guardar
    name_prefix="ppo_robot_maze",      # nombre del archivo
    )

    # Early stop
    early_stop_callback = EarlyStoppingNoImprovement(
        n_episodes=500,   # tamaño de la ventana para la media
        patience=5,      # nº de veces seguidas que permites "no mejora"
        min_delta=0.0,   # pon >0 si quieres exigir que suba al menos X
        verbose=1,
    )  

    # Combinamos ambos callbacks
    callback = CallbackList([checkpoint_callback, early_stop_callback])


    model.learn(
    total_timesteps=50000,
    callback=callback,
    )

    model.save("ppo_robot_maze_8envs")
    print("Fin del entrenamiento")
    
